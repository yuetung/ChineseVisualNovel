﻿using UnityEngine;
using UnityEditor;
using UnityEditorInternal;


namespace VinomaEditor
{
	public class SceneListPopup : PopupWindowContent
	{
		public GUIContent[] labels { get; set; }
		public int currIdx { get; set; }
		public System.Action<int> onSelected { get; set; }

		private static readonly Vector2 popupSz = new Vector2(200f, 300f);
		private Vector2 scroll = Vector2.zero;
		private Rect contentRect;
		private GUIContent l = new GUIContent();

		private class StyleDefs
		{
			public GUIStyle ListElement;
			public GUIStyle SelectedElement;

			public StyleDefs()
			{
				ListElement = new GUIStyle(GUI.skin.FindStyle("PreferencesSection")) { fontSize = 12, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(5, 5, 3, 3), fixedWidth = 0, fixedHeight = 0, stretchWidth = true };
				//SelectedElement = new GUIStyle(GUI.skin.FindStyle("ServerUpdateChangesetOn")) { fontSize = 12, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(5, 5, 3, 3), fixedWidth = 0, fixedHeight = 0, stretchWidth = true };
				SelectedElement = new GUIStyle(GUI.skin.FindStyle("OL SelectedRow")) { fontSize = 12, alignment = TextAnchor.MiddleLeft, padding = new RectOffset(5, 5, 3, 3), fixedWidth = 0, fixedHeight = 0, stretchWidth = true }; 
			}
		}

		private static StyleDefs _style = null;
		private static StyleDefs Style
		{
			get
			{
				return _style ?? (_style = new StyleDefs());
			}
		}

		// ----------------------------------------------------------------------------------------------------------------

		public override void OnOpen()
		{
			contentRect = new Rect(0, 0, popupSz.x - 20f, labels.Length * EditorGUIUtility.singleLineHeight);
			editorWindow.wantsMouseMove = true;
		}

		public override void OnClose()
		{
			labels = null;
			onSelected = null;
			editorWindow.wantsMouseMove = false;
		}

		public override Vector2 GetWindowSize()
		{
			return popupSz;
		}

		public override void OnGUI(Rect r)
		{
			bool didSelect = false;
			scroll = GUI.BeginScrollView(r, scroll, contentRect, false, true);
			{
				r.height = EditorGUIUtility.singleLineHeight;
				for (int i = 0; i < labels.Length; i++)
				{
					if (DrawElement(r, labels[i], currIdx == i))
					{
						didSelect = true;
						onSelected(i);
					}

					r.y += EditorGUIUtility.singleLineHeight;
				}
			}
			GUI.EndScrollView();

			if (Event.current.type == EventType.Repaint)
			{
				editorWindow.Repaint();
			}

			if (didSelect) editorWindow.Close();
		}

		private bool DrawElement(Rect r, GUIContent label, bool selected)
		{
			l.text = (selected ? "✔ " : "") + label.text;
			if (GUI.Button(r, l, (r.Contains(Event.current.mousePosition) ? Style.SelectedElement : Style.ListElement)))
			{
				return true;
			}
			return false;
		}

		// ----------------------------------------------------------------------------------------------------------------
	}
}