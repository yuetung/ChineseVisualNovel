﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[InitializeOnLoad]
	public class VinomaEdGlobal
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public static readonly string MAIN_SCENE = plyEdUtil.DataRoot + "vinoma/MainScene.unity";

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public static VinomaDataAsset asset;

		public static bool ManageBuildList = true;

		private static int playTestingMode = 0; // 0:not initialised, 1:initialised, 2:game started by vinoma play

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		static VinomaEdGlobal()
		{
			EditorApplication.delayCall += DelayCall;
			EditorApplication.update += OnUpdate;
		}

		private static void DelayCall()
		{
			//EditorApplication.update -= DelayCall;
			ManageBuildList = EditorPrefs.GetBool("Vinoma.ManageBuildList", ManageBuildList);
			LanguageEditor.RegisterStringsProvider(OnStringsRequest);
		}

		private static void OnUpdate()
		{
			if (playTestingMode != 1)
			{
				if (Application.isPlaying)
				{
					if (playTestingMode == 0)
					{
						// find if this is vinoma play mode
						playTestingMode = EditorPrefs.GetInt("Vinoma.CurrentPlayTestingMode", 1);
					}
					else if (playTestingMode == 2)
					{
						// is vinoma play mode, wait for play to be active and then change to vinoma scene
						playTestingMode = 1;
						EditorPrefs.SetInt("Vinoma.CurrentPlayTestingMode", 1);
						GameObject go = GameObject.Find("VinomaGameGlobal");
						if (go != null) go.GetComponent<VinomaGameGlobal>().PlayTestScene(EditorPrefs.GetInt("Vinoma.CurrentPlayTestScene", 0));
						else Debug.LogError("The Vinoma main scene is broken. VinomaGameGlobal not found");
					}
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region menus

		[MenuItem("Window/Vinoma/Scene Editor", priority = 1)]
		public static void Show_VinomaEditor()
		{
			LoadAsset(true);
			VinomaEditorWindow.Show_VinomaEditor();
		}

		[MenuItem("Window/Vinoma/Settings", priority = 2)]
		public static void Show_Settings()
		{
			LoadAsset(true);
			VinomaSettingsWindow.Show_VinomaSettingsWindow();
		}

		[MenuItem("Window/Vinoma/Hotspots Overlays", priority = 3)]
		public static void Show_HotspotsOverlayEditor()
		{
			LoadAsset(true);
			VinomaHotspotsEd.Show_VinomaHotspotsEd();
		}

		[MenuItem("Window/Vinoma/Languages", priority = 4)]
		public static void Show_LanguagesEditor()
		{
			LoadAsset(true);
			LanguageEditor.Show_LanguageEditor();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region init/ create data

		public static void LoadAsset(bool force)
		{
			if (asset == null)
			{
				CheckData();
				
				if (force && EditorApplication.isPlayingOrWillChangePlaymode == false && EditorSceneManager.GetActiveScene().path != MAIN_SCENE)
				{
					if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
					{
						EditorSceneManager.OpenScene(MAIN_SCENE, OpenSceneMode.Single);
					}
				}

				if (EditorSceneManager.GetActiveScene().path == MAIN_SCENE)
				{
					asset = Object.FindObjectOfType<VinomaDataAsset>();
					if (asset == null)
					{
						GameObject go = GameObject.Find("VinomaGameGlobal");
						if (go != null)
						{
							asset = go.AddComponent<VinomaDataAsset>();
							EditorUtility.SetDirty(go);
							EditorSceneManager.MarkAllScenesDirty();
							EditorSceneManager.SaveOpenScenes();
						}
						else
						{
							if (!EditorApplication.isPlayingOrWillChangePlaymode)
							{
								Debug.LogError("The Vinoma main scene is broken. VinomaGameGlobal not found");
							}
						}
					}
				}
			}

		}

		public static void CheckData()
		{
			// check if the DataRoot exist
			plyEdUtil.CheckPath(plyEdUtil.DataRoot + "vinoma");

			// check if main scene is present, else create
			if (!plyEdUtil.RelativeFileExist(MAIN_SCENE))
			{
				AssetDatabase.CopyAsset(plyEdUtil.PackageRoot + "vinoma/Scenes/Template.unity", MAIN_SCENE);
				AssetDatabase.Refresh();
			}

			// make sure the main scene is in Build Settings
			if (ManageBuildList)
			{
				plyEdUtil.AddSceneToBuildSettings(MAIN_SCENE, true);
			}

			// check the sorting layers
			List<string> sortLayerNames = new List<string>();
			System.Reflection.FieldInfo[] fields = typeof(VinomaGameGlobal.SortLayer).GetFields();
			foreach (System.Reflection.FieldInfo f in fields) sortLayerNames.Add(f.GetRawConstantValue().ToString());
			plyEdUtil.CheckSortLayers(sortLayerNames.ToArray());
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public static void PlayTestScene(int sceneIdx)
		{
			if (!EditorApplication.isPlayingOrWillChangePlaymode)
			{
				EditorPrefs.SetInt("Vinoma.CurrentPlayTestScene", sceneIdx);
				EditorPrefs.SetInt("Vinoma.CurrentPlayTestingMode", 2);
				EditorApplication.isPlaying = true;
			}
		}

		public static int GetSceneId(string name)
		{
			for (int i = 0; i < asset.scenes.Length; i++)
			{
				if (name.Equals(asset.scenes[i].name)) return i;
			}
			return -1;
		}

		public static string[] GetCharacterNamesUsedInScene()
		{
			VinomaScene sc = VinomaEditorWindow.Instance.currScene;
			List<string> res = new List<string>();
			for (int i = 0; i < sc.actions.Length; i++)
			{
				VA_CharaEnter ac = sc.actions[i] as VA_CharaEnter;
				if (ac != null && !string.IsNullOrEmpty(ac.characterName) && !res.Contains(ac.characterName)) res.Add(ac.characterName);
			}
			return res.ToArray();
		}

		public static GameObject GetPrefabForCharacterInScene(string name)
		{
			VinomaScene sc = VinomaEditorWindow.Instance.currScene;
			for (int i = 0; i < sc.actions.Length; i++)
			{
				VA_CharaEnter ac = sc.actions[i] as VA_CharaEnter;
				if (ac != null && ac.characterName.Equals(name))
				{
					return ac.characterFab;
				}
			}
			return null;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region callbacks

		private static List<LanguageString> OnStringsRequest(LanguagesAsset languagesAsset)
		{
			List<LanguageString> strings = new List<LanguageString>();
			VinomaEdGlobal.asset = null; // force a reload
			LoadAsset(true);

			if (asset != null)
			{
				foreach (VinomaScene sc in asset.scenes)
				{
					for (int i = 0; i < sc.actions.Length; i++)
					{
						List<LanguageString> s = sc.actions[i].GetStrings(languagesAsset);
						if (s != null) strings.AddRange(s);
						EditorUtility.SetDirty(sc.actions[i]); // since IDs might have changed
					}

					EditorUtility.SetDirty(sc);
				}
				EditorUtility.SetDirty(asset);
				EditorUtility.SetDirty(languagesAsset);
				EditorSceneManager.MarkAllScenesDirty();
				AssetDatabase.SaveAssets();
			}
			else
			{
				Debug.LogError("Vinoma Data not loaded. The Vinoma main scene must be opened to continue.");
			}

			return strings;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
