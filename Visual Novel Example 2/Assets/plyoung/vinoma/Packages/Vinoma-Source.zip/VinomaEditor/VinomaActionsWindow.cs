﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public class VinomaActionsWindow : EditorWindow
	{
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		private bool[] actionGroupFolds = new bool[0];
		private Vector2 scroll = Vector2.zero;
		private int activePanel = 0;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region init

		public static void Show_VinomaActions()
		{
			EditorWindow.GetWindow<VinomaActionsWindow>("VActions", false);
		}

		protected void OnEnable()
		{
			VinomaEditorWindow.Reflect();
			UpdateWindowIcon();
			actionGroupFolds = new bool[(int)VinomaActionGroup.MAX];
			for (int i = 0; i < (int)VinomaActionGroup.MAX; i++) actionGroupFolds[i] = 1 == EditorPrefs.GetInt("VinomaEd.ActionGroupFold." + i, 1);
		}

		protected void OnDestroy()
		{
		}

		protected void OnFocus()
		{
			VinomaEditorWindow.Reflect();
			//UpdateWindowIcon();
			//wantsMouseMove = true;
			//LoadAsset();
		}

		protected void OnLostFocus()
		{
			//wantsMouseMove = false;
		}

		private void UpdateWindowIcon()
		{
#if !UNITY_4
			if (VinomaEdGUI.Texture_WinIcon == null) VinomaEdGUI.Texture_WinIcon = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.ico_vinoma" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEditorWindow).Assembly);
			//plyEdUtil.SetWindowTitle(this, VinomaEdGUI.Texture_WinIcon, "VActions");
			titleContent = new GUIContent("VActions", VinomaEdGUI.Texture_WinIcon);
#endif
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void OnGUI()
		{
			VinomaEdGUI.UseSkin();

			GUI.enabled = !EditorApplication.isPlayingOrWillChangePlaymode;
			//EditorGUILayout.BeginVertical(VinomaEdGUI.LeftPanelBack_Style);
			{
				scroll = EditorGUILayout.BeginScrollView(scroll);//, false, false, GUIStyle.none, GUI.skin.verticalScrollbar, GUI.skin.scrollView);
				{
					if (activePanel == 0) DrawActionsPanel();
					else DrawResourcesPanel();
					GUILayout.Space(100);
				}
				EditorGUILayout.EndScrollView();
			}
			//EditorGUILayout.EndVertical();
			GUI.enabled = true;
		}

		private void DrawActionsPanel()
		{
			for (int i = 0; i < (int)VinomaActionGroup.MAX; i++)
			{
				// render the group label
				EditorGUILayout.Space();
				GUI.backgroundColor = VinomaEdGUI.ActionGroup_Colors[i];
				if (GUILayout.Button(((VinomaActionGroup)i).ToString(), VinomaEdGUI.ActionGroup_Style, GUILayout.ExpandWidth(true)))
				{
					actionGroupFolds[i] = !actionGroupFolds[i];
					EditorPrefs.SetInt("VinomaEd.ActionGroupFold." + i, actionGroupFolds[i] ? 1 : 0);
				}
				GUI.backgroundColor = Color.white;

				Rect r = GUILayoutUtility.GetLastRect();
				r.x += 2; r.y += 2; r.width = 25;
				GUI.Label(r, actionGroupFolds[i] ? Ico._arrow_down : Ico._arrow_up, VinomaEdGUI.ActionGroupCollapseIcon_Style);

				if (actionGroupFolds[i])
				{
					// render the group's actions
					EditorGUILayout.BeginVertical(VinomaEdGUI.ActionListContainer_Style);
					for (int j = 0; j < VinomaEditorWindow.actions.Count; j++)
					{
						if ((int)VinomaEditorWindow.actions[j].att.Group == i)
						{
							r = VinomaEditorWindow.DrawActionLabel(VinomaEditorWindow.actions[j], true);
							if (Event.current.button == 0 && Event.current.type == EventType.MouseDrag)
							{
								if (r.Contains(Event.current.mousePosition))
								{
									plyEdGUI.ClearFocus();
									DragAndDrop.PrepareStartDrag();
									DragAndDrop.objectReferences = new UnityEngine.Object[0];
									DragAndDrop.paths = null;
									DragAndDrop.SetGenericData("VinomaActionNfo", VinomaEditorWindow.actions[j]);
									DragAndDrop.StartDrag(VinomaEditorWindow.actions[j].att.Name);
									Event.current.Use();
								}
							}

						}
					}
					EditorGUILayout.EndVertical();
				}
			}
			GUILayout.FlexibleSpace();
		}

		private void DrawResourcesPanel()
		{
			GUILayout.FlexibleSpace();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
