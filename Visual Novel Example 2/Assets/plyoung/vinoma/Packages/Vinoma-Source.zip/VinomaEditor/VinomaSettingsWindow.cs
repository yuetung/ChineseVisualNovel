﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public class VinomaSettingsWindow : EditorWindow
	{
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		private static readonly GUIContent GC_Refresh = new GUIContent(Ico._refresh + " Update", "Refresh and update build settings.");
		private static readonly GUIContent GC_ClearSaves = new GUIContent(Ico._bin + " Clear Saves", "Remove all old saved runtime game data.");
		private static readonly GUIContent GC_Languages = new GUIContent(Ico._book + " Languages", "Open the language and translations editor.");
		private static readonly GUIContent GC_Hotspots = new GUIContent(Ico._grid + " Hotspots", "Open the hotspots editor.");

		private static readonly GUIContent GC_DesignWidth = new GUIContent("Design Width", "This will normally be the same as the width your background images are using.");
		private static readonly GUIContent GC_DesignHeight = new GUIContent("Design Height", "This will normally be the same as the height your background images are using.");
		private static readonly GUIContent GC_Pixels = new GUIContent("Pixels per Unit", "This should be the same as the value used with imported sprites. The Unity default is 100.");
		private static readonly GUIContent GC_Border = new GUIContent("Scene Border", "Determine what the characters will consider as the scene border/ edge when being repositioned in the scene.");
		private static readonly GUIContent GC_ClearChange = new GUIContent("Clear on Change", "Should a change of scene clear the scene or leave the background and characters that might have been added by the previous scene?");
		private static readonly GUIContent GC_ClearObjects = new GUIContent("GameObjects too", "Should objects in GameObjects also be deactivated on scene change?");

		private static readonly GUIContent GC_MenuMusic = new GUIContent("Music", "Music to play when not in a game scene. When the main menu is shown.");

		private static readonly GUIContent GC_ResSettings = new GUIContent("Resolution Options", "Should Resolution and Fullscreen options be applied when the player clicks on 'Apply' in the settings window? You probably want this turned off for mobile devices.");
		private static readonly GUIContent GC_AutoDialogueSpeed = new GUIContent("Auto Dialogue Delay", "How long to display dialogue text, in seconds, before moving on when auto-mode is on.");

		private static readonly GUIContent GC_ManageBuild = new GUIContent("Manage Build settings", "This should always be on except if you have a good reason to turn it off. It makes sure Vinoma's main scene is present in the correct location of build settings when you build the game.");
		private static readonly GUIContent GC_ManageSettings = new GUIContent("Manage Game settings", "Turn this off if you do not want Vinoma to restore screen resolution, quality settings and sound volume in the game.");

		private Vector2 scroll = Vector2.zero;

		private Camera cam;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region init

		public static void Show_VinomaSettingsWindow()
		{
			EditorWindow.GetWindow<VinomaSettingsWindow>("VSettings");
		}

		protected void OnEnable()
		{
			UpdateWindowIcon();
		}

		protected void OnDestroy()
		{
		}

		protected void OnFocus()
		{
			//UpdateWindowIcon();
		}

		protected void OnLostFocus()
		{
		}

		private void UpdateWindowIcon()
		{
#if !UNITY_4
			if (VinomaEdGUI.Texture_WinIcon == null) VinomaEdGUI.Texture_WinIcon = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.ico_vinoma" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEditorWindow).Assembly);
			//plyEdUtil.SetWindowTitle(this, VinomaEdGUI.Texture_WinIcon, "VSettings");
			titleContent = new GUIContent("VSettings", VinomaEdGUI.Texture_WinIcon);
#endif
		}

		private void LoadAsset()
		{
			// I do the asset load call here since it opens a scene and that seems to crash unity
			// when unity starts and scene load was done in focus or enable

			if (cam == null)
			{
				VinomaEdGlobal.LoadAsset(false);
				if (VinomaEdGlobal.asset != null)
				{
					GameObject go = GameObject.Find("VinomaGameGlobal/Main Camera");
					if (go != null)
					{
						cam = go.GetComponent<Camera>();
						if (cam == null) Debug.LogError("The Vinoma main scene is broken. Could not find VinomaGameGlobal/Main Camera<Camera>.");
					}
					else Debug.LogError("The Vinoma main scene is broken. Could not find VinomaGameGlobal/Main Camera.");
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void OnGUI()
		{
			LoadAsset();
			VinomaEdGUI.UseSkin();

			if (VinomaEdGlobal.asset == null)
			{
				ShowNotification(new GUIContent("The Vinoma main scene must be open before settings can be edited."));
				return;
			}
			else RemoveNotification();

			EditorGUILayout.BeginHorizontal(VinomaEdGUI.LogoContainer_Style, GUILayout.ExpandHeight(true), GUILayout.ExpandWidth(true));
			{
				Rect r = GUILayoutUtility.GetRect(377, 377, 123, 123, GUILayout.Width(377), GUILayout.Height(123));
				GUI.DrawTexture(r, VinomaEdGUI.Texture_Logo);
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
			{
				EditorGUILayout.Space();
				if (GUILayout.Button(GC_Refresh, plyEdGUI.Style_ToolbarIcoButton))
				{
					VinomaEdGlobal.CheckData();
					EditorUtility.DisplayDialog("Vinoma", "The build settings have been updated.", "OK");
				}
				if (GUILayout.Button(GC_ClearSaves, plyEdGUI.Style_ToolbarIcoButton))
				{
					PlayerPrefs.DeleteAll();
					EditorUtility.DisplayDialog("Vinoma", "The old runtime save data was deleted.", "OK");
				}
				if (GUILayout.Button(GC_Hotspots, plyEdGUI.Style_ToolbarIcoButton))
				{
					VinomaHotspotsEd.Show_VinomaHotspotsEd();
				} 				
				if (GUILayout.Button(GC_Languages, plyEdGUI.Style_ToolbarIcoButton))
				{
					LanguageEditor.Show_LanguageEditor();
				} 
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			scroll = EditorGUILayout.BeginScrollView(scroll);
			{
				GUILayout.Label("Design", EditorStyles.largeLabel);
				EditorGUI.indentLevel++;
				EditorGUI.BeginChangeCheck();
				VinomaEdGlobal.asset.designWidth = EditorGUILayout.IntField(GC_DesignWidth, VinomaEdGlobal.asset.designWidth);
				VinomaEdGlobal.asset.designHeight = EditorGUILayout.IntField(GC_DesignHeight, VinomaEdGlobal.asset.designHeight);
				VinomaEdGlobal.asset.pixelsPerUnit = EditorGUILayout.FloatField(GC_Pixels, VinomaEdGlobal.asset.pixelsPerUnit);
				if (EditorGUI.EndChangeCheck()) ApplyDesignSizes();
				EditorGUI.indentLevel--;

				EditorGUILayout.Space();
				GUILayout.Label("Startup & Menu", EditorStyles.largeLabel);
				EditorGUI.indentLevel++;
				VinomaEdGlobal.asset.menuMusic = (AudioClip)EditorGUILayout.ObjectField(GC_MenuMusic, VinomaEdGlobal.asset.menuMusic, typeof(AudioClip), false);
				EditorGUI.indentLevel--;				

				EditorGUILayout.Space();
				GUILayout.Label("Game Scenes", EditorStyles.largeLabel);
				EditorGUI.indentLevel++;
				VinomaEdGlobal.asset.sceneBorder = (VinomaWidthAdapt)EditorGUILayout.EnumPopup(GC_Border, VinomaEdGlobal.asset.sceneBorder);
				VinomaEdGlobal.asset.clearOnSceneChange = EditorGUILayout.Toggle(GC_ClearChange, VinomaEdGlobal.asset.clearOnSceneChange);
				if (VinomaEdGlobal.asset.clearOnSceneChange)
				{
					VinomaEdGlobal.asset.gameObjectsToo = EditorGUILayout.Toggle(GC_ClearObjects, VinomaEdGlobal.asset.gameObjectsToo);
				}
				EditorGUI.indentLevel--;

				EditorGUILayout.Space();
				GUILayout.Label("Misc", EditorStyles.largeLabel);
				EditorGUI.indentLevel++;

				EditorGUI.BeginChangeCheck();
				VinomaEdGlobal.ManageBuildList = EditorGUILayout.Toggle(GC_ManageBuild, VinomaEdGlobal.ManageBuildList);
				if (EditorGUI.EndChangeCheck())	EditorPrefs.SetBool("Vinoma.ManageBuildList", VinomaEdGlobal.ManageBuildList);

				VinomaEdGlobal.asset.manageGameSettings = EditorGUILayout.Toggle(GC_ManageSettings, VinomaEdGlobal.asset.manageGameSettings);
				VinomaEdGlobal.asset.resolutionSettingsActive = EditorGUILayout.Toggle(GC_ResSettings, VinomaEdGlobal.asset.resolutionSettingsActive);
				VinomaEdGlobal.asset.autoDialogueSpeed = EditorGUILayout.FloatField(GC_AutoDialogueSpeed, VinomaEdGlobal.asset.autoDialogueSpeed);
				EditorGUI.indentLevel--;


				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndScrollView();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(VinomaEdGlobal.asset);
			}
		}

		private void ApplyDesignSizes()
		{
			//// apply changes onto the GameGlobalFab. This should also update the main scene's game global.
			//VinomaEdGlobal.LoadGlobalFab();
			//if (VinomaEdGlobal.GameGlobalFab != null)
			//{
			//	Transform tr = VinomaEdGlobal.GameGlobalFab.transform.FindChild("Main Camera");
			//	if (tr != null)
			//	{
			//		Camera cam = tr.GetComponent<Camera>();
			//		if (cam != null)
			//		{
			//			cam.orthographic = true;
			//			cam.orthographicSize = VinomaEdGlobal.asset.designHeight / 2f / VinomaEdGlobal.asset.pixelsPerUnit;
			//			EditorUtility.SetDirty(cam);

			//			//// update information in scene too if scene is open
			//			//if (EditorApplication.currentScene == VinomaEdGlobal.MAIN_SCENE)
			//			//{
			//			//	cam = null;
			//			//	GameObject go = GameObject.Find("GameGlobal/Main Camera");
			//			//	if (go != null)
			//			//	{
			//			//		cam = go.GetComponent<Camera>();
			//			//		cam.orthographic = true;
			//			//		cam.orthographicSize = VinomaEdGlobal.asset.screenHeight / 2f / VinomaEdGlobal.asset.pixelsPerUnit;
			//			//	}

			//			//	go = GameObject.Find("GameScene/SizeGuide");
			//			//	if (go != null)
			//			//	{
			//			//		SizeGuide sg = go.GetComponent<SizeGuide>();
			//			//		if (sg != null)
			//			//		{
			//			//			sg.UpdateSize(VinomaEdGlobal.asset.screenWidth, VinomaEdGlobal.asset.screenHeight);
			//			//			EditorUtility.SetDirty(sg.transform);
			//			//		}
			//			//	}
			//			//}

			//			return;
			//		}
			//	}
			//}

			//Debug.LogError("Could not update the GameGlobal Prefab. Your installation of Vinoma might be broken.");

			if (cam != null)
			{
				cam.orthographic = true;
				cam.orthographicSize = VinomaEdGlobal.asset.designHeight / 2f / VinomaEdGlobal.asset.pixelsPerUnit;
				EditorUtility.SetDirty(cam);
				EditorSceneManager.SaveOpenScenes();
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
