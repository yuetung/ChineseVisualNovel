﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[CustomEditor(typeof(VinomaDataAsset))]
	public class VinomaDataAssetInspector : Editor
	{
		public override void OnInspectorGUI()
		{
			//GUILayout.Label("Do not move or edit this asset.");
			GUILayout.Space(10);

#if !ASSET_HIDEFLAGS_ON
			DrawDefaultInspector();
#endif
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
