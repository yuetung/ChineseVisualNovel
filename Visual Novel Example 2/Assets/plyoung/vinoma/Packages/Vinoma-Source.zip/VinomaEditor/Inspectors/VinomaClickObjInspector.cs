﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[CustomEditor(typeof(VinomaClickObj))]
	public class VinomaClickObjInspector : Editor
	{
		private static readonly GUIContent GC_Actions = new GUIContent("Actions", "Actions to perform when this hotspot is clicked.");
		private static readonly GUIContent gc_Add2 = new GUIContent("+", "Add an action to perform.");
		private static readonly GUIContent gc_Rem2 = new GUIContent("-", "Remove last action.");
		private static readonly GUIContent gc_To = new GUIContent("<>");

		public override void OnInspectorGUI()
		{
			VinomaEdGUI.UseSkin();
			VinomaClickObj currHotspot = (VinomaClickObj)target;

			EditorGUILayout.Space();
			EditorGUIUtility.labelWidth = 60;
			if (currHotspot.actions == null) currHotspot.actions = new VinomaActionOptDef[0];
			if (currHotspot.actions.Length == 0)
			{
				EditorGUILayout.BeginHorizontal();
				EditorGUILayout.PrefixLabel(GC_Actions);
			}
			else
			{
				for (int j = 0; j < currHotspot.actions.Length; j++)
				{
					EditorGUILayout.BeginHorizontal();
					if (j == 0) EditorGUILayout.PrefixLabel(GC_Actions);
					else EditorGUILayout.PrefixLabel(" ");

					currHotspot.actions[j].act = (VinomaActionOptDef.Action)EditorGUILayout.EnumPopup(currHotspot.actions[j].act);

					if (currHotspot.actions[j].act == VinomaActionOptDef.Action.Switch)
					{
						currHotspot.actions[j].s_opt1 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt1);
						currHotspot.actions[j].swOpt = (VinomaSwitchOperation)EditorGUILayout.EnumPopup(currHotspot.actions[j].swOpt);
					}
					else if (currHotspot.actions[j].act == VinomaActionOptDef.Action.Variable)
					{
						currHotspot.actions[j].s_opt1 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt1);
						currHotspot.actions[j].varOpt = (VinomaVarOperation)EditorGUILayout.EnumPopup(currHotspot.actions[j].varOpt, GUILayout.Width(70));
						currHotspot.actions[j].s_opt2 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt2);
						if (currHotspot.actions[j].varOpt == VinomaVarOperation.Random)
						{
							GUILayout.Label(gc_To);
							currHotspot.actions[j].s_opt3 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt3);
						}
					}
					else if (currHotspot.actions[j].act == VinomaActionOptDef.Action.Goto)
					{
						currHotspot.actions[j].goOpt = (VinomaGotoOption)EditorGUILayout.EnumPopup(currHotspot.actions[j].goOpt);
						if (currHotspot.actions[j].goOpt == VinomaGotoOption.Label)
						{
							currHotspot.actions[j].s_opt2 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt2);
						}
						else if (currHotspot.actions[j].goOpt == VinomaGotoOption.Scene)
						{
							currHotspot.actions[j].s_opt1 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt1);
							currHotspot.actions[j].s_opt2 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt2);
						}
					}
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.BeginHorizontal();
			}

			GUILayout.FlexibleSpace();
			if (GUILayout.Button(gc_Add2, EditorStyles.miniButtonLeft))
			{
				ArrayUtility.Add<VinomaActionOptDef>(ref currHotspot.actions, new VinomaActionOptDef());
				GUI.changed = true;
			}
			GUI.enabled = currHotspot.actions.Length > 0;
			if (GUILayout.Button(gc_Rem2, EditorStyles.miniButtonRight))
			{
				ArrayUtility.RemoveAt<VinomaActionOptDef>(ref currHotspot.actions, currHotspot.actions.Length - 1);
				GUI.changed = true;
			}
			GUI.enabled = true;
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
