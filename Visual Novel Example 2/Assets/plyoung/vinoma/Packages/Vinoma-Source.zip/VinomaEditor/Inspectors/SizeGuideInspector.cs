﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[CustomEditor(typeof(SizeGuide))]
	public class SizeGuideInspector : Editor
	{
		public override void OnInspectorGUI()
		{
			EditorGUILayout.Space();

			SizeGuide Target = (SizeGuide)target;

			Target.scaleType = (ply2D.ScaleType)EditorGUILayout.EnumPopup("Scale Type", Target.scaleType);

			if (GUILayout.Button("Update"))
			{
				//VinomaEdGlobal.LoadGlobalFab();
				Target.UpdateSize(VinomaEdGlobal.asset.designWidth, VinomaEdGlobal.asset.designHeight);
				EditorUtility.SetDirty(Target.transform);
			}

			if (GUI.changed)
			{
				EditorUtility.SetDirty(target);
				GUI.changed = false;
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
