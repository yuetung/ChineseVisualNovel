﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[CustomEditor(typeof(SpritePadding))]
	public class SpritePaddingInspector : Editor
	{
		private SerializedProperty paddingProp;
		private SpritePadding Target;
		private SpriteRenderer ren;
		private Vector3[] bounds;
		private Vector3[] padding;

		protected void OnEnable()
		{
			paddingProp = serializedObject.FindProperty("padding");
			Target = (SpritePadding)target;
			ren = Target.GetComponent<SpriteRenderer>();
			bounds = new Vector3[]
			{
				ren.bounds.min,
				new Vector3(ren.bounds.max.x, ren.bounds.min.y, 0f),
				ren.bounds.max,
				new Vector3(ren.bounds.min.x, ren.bounds.max.y, 0f),
				ren.bounds.min,
			};

			padding = new Vector3[5];
			UpdatePaddingLines();
		}

		public override void OnInspectorGUI()
		{
			EditorGUI.BeginChangeCheck();
			EditorGUILayout.Space();
			serializedObject.Update();
			EditorGUILayout.PropertyField(paddingProp, true);
			serializedObject.ApplyModifiedProperties();
			if (EditorGUI.EndChangeCheck())
			{
				UpdatePaddingLines();
				SceneView.RepaintAll();
			}
		}

		protected void OnSceneGUI()
		{
			if (ren == null || Target == null) return;

			// draw outline
			Handles.DrawPolyLine(bounds);
			
			// padding lines
			Handles.color = Color.green;
			Handles.DrawPolyLine(padding);
		}

		private void UpdatePaddingLines()
		{
			padding[0] = bounds[0] + new Vector3(Target.padding.left, Target.padding.bottom, 0f);
			padding[1] = bounds[1] + new Vector3(-Target.padding.right, Target.padding.bottom, 0f);
			padding[2] = bounds[2] + new Vector3(-Target.padding.right, -Target.padding.top, 0f);
			padding[3] = bounds[3] + new Vector3(Target.padding.left, -Target.padding.top, 0f);
			padding[4] = padding[0];
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
