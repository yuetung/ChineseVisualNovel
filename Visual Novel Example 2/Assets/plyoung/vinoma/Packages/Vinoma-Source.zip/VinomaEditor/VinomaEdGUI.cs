﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public class VinomaEdGUI
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public static int PropertyPanelWidth = 400;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region colours

		public static readonly Color[] ActionGroup_Colors = // this must be exactly same amount of entries as VinomaActionGroup enum
		{
			plyUtil.Color(71, 165, 227),	// story
			plyUtil.Color(33, 189, 29),		// characters
			plyUtil.Color(228, 129, 70),	// images
			plyUtil.Color(231, 68, 69),		// media
			plyUtil.Color(195, 68, 231),	// effects
			plyUtil.Color(170, 170, 170),	// other
		};

		public static readonly Color ActionPropLabelColor = new Color(0.3f, 0.3f, 0.3f, 1f);

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region styles

		public static GUIStyle LeftPanelBack_Style;
		public static GUIStyle ActionGroup_Style;
		public static GUIStyle ActionGroupCollapseIcon_Style;
		public static GUIStyle ActionListContainer_Style;

		public static GUIStyle MainPanelBack_Style;
		public static GUIStyle MainPanelContent_Style;
		public static GUIStyle Notification_Style;
		
		public static GUIStyle[] Action_Style = new GUIStyle[(int)VinomaActionGroup.MAX];
		public static GUIStyle ActionPropertiesContainer_Style;
		public static GUIStyle ActionNote_Style;
		public static GUIStyle ActionCollapseButton_Style;
		public static GUIStyle ActionRemoveButton_Style;
		public static GUIStyle ActionActiveButton_Style;

		public static GUIStyle Frame_Style;
		public static GUIStyle FrameFill_Style;
		public static GUIStyle Label_Style;
		public static GUIStyle ObjectField_Style;

		public static GUIStyle LogoContainer_Style;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region textures

		public static Texture2D Texture_WinIcon;
		public static Texture2D Texture_Logo;

		public static Dictionary<string, Texture2D> Action_Icons = new Dictionary<string, Texture2D>();
		public static Texture2D Texture_VinomaIcon;
		public static Texture2D Texture_Timeline;
		public static Texture2D Texture_TimelineDot;
		public static Texture2D Texture_ActionActive;

		private static Texture2D[] Texture_Action = new Texture2D[(int)VinomaActionGroup.MAX];
		private static Texture2D Texture_LeftPanelBack;
		private static Texture2D Texture_MainPanelBack;
		private static Texture2D Texture_ActionPropsContainer;
		private static Texture2D Texture_ActionNode;

		private static Texture2D Texture_Frame;
		private static Texture2D Texture_FrameFill;

		private static Texture2D Texture_LogoConainerBack;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region init

		public static void UseSkin()
		{
			plyEdGUI.UseSkin();
			LoadResources();
			DefineStyles();
		}

		private static void DefineStyles()
		{
			if (ActionGroup_Style != null) return;
			GUIStyle[] customStyles = GUI.skin.customStyles;

			#region Left Panel Styles

			LeftPanelBack_Style = new GUIStyle()
			{
				normal = { background = Texture_LeftPanelBack }
			};

			ActionGroup_Style = new GUIStyle(GUI.skin.label)
			{	
				// the background texture will be tinted
				normal = { background = EditorGUIUtility.whiteTexture, textColor = Color.white },
				padding = new RectOffset(35, 5, 5, 5),
				margin = new RectOffset(2, 2, 0, 5),
				stretchWidth = true,
				font = plyEdGUI.sansRegularFont,
				fontSize = 15,
				fontStyle = FontStyle.Bold,
			};

			ActionGroupCollapseIcon_Style = new GUIStyle(plyEdGUI.Style_IcoLabel)
			{
				normal = { textColor = Color.white },
				fontSize = 20,
				fontStyle = FontStyle.Bold,
			};

			ActionListContainer_Style = new GUIStyle()
			{
				padding = new RectOffset(7, 0, 0, 0),
			};

			#endregion
			#region Main Panel Styles

			MainPanelBack_Style = new GUIStyle()
			{
				normal = { background = Texture_MainPanelBack }
			};

			MainPanelContent_Style = new GUIStyle()
			{
				padding = new RectOffset(20, 0, 0, 0)
			};

			Notification_Style = new GUIStyle(GUI.skin.label)
			{
				fontSize = 25, fontStyle = FontStyle.Bold,
				normal = { textColor = new Color(0f, 0f, 0f, 0.2f) },
				margin = new RectOffset(30, 20, 20, 20)
			};

			#endregion
			#region Action Styles

			for (int i = 0; i < Action_Style.Length; i++)
			{
				Action_Style[i] = new GUIStyle()
				{
					normal = { background = Texture_Action[i], textColor = new Color(1f, 1f, 1f, 0.85f) },
					padding = new RectOffset(35, 0, 3, 0),
					margin = new RectOffset(2, 0, 0, -22),
					font = plyEdGUI.sansRegularFont,
					fontSize = 14, fontStyle = FontStyle.Normal,
				};
			}

			ActionPropertiesContainer_Style = new GUIStyle()
			{
				normal = { background = Texture_ActionPropsContainer },
				margin = new RectOffset(40, 0, -22, 5),
				padding = new RectOffset(10, 10, 15, 5),
				border = new RectOffset(164, 3, 13, 6),
				stretchWidth = false,
			};

			ActionNote_Style = new GUIStyle()
			{
				richText = false,
				font = plyEdGUI.sansRegularFont,
				fontSize = 11, fontStyle = FontStyle.Normal,
				clipping = TextClipping.Clip, wordWrap = false,
				padding = new RectOffset(5, 0, 5, 0),
				border = new RectOffset(0, 0, 1, 1),
				normal = { textColor = EditorGUIUtility.isProSkin ? new Color(1f, 1f, 1f, 0.4f) : new Color(0f, 0f, 0f, 0.6f), background = Texture_ActionNode },
			};

			ActionCollapseButton_Style = new GUIStyle(plyEdGUI.Style_IcoLabel)
			{
				normal = { textColor = Color.white },
				fontSize = 16,
				fontStyle = FontStyle.Bold,
			};

			ActionRemoveButton_Style = new GUIStyle(plyEdGUI.Style_IcoLabel)
			{
				normal = { textColor = EditorGUIUtility.isProSkin ? new Color(0.9f, 0f, 0f, 0.5f) : new Color(0.6f, 0f, 0f, 0.35f) },
				fontSize = 14,
				fontStyle = FontStyle.Normal,
			};

			ActionActiveButton_Style = new GUIStyle(plyEdGUI.Style_IcoLabel)
			{
				normal = { textColor = EditorGUIUtility.isProSkin ? new Color(0.3f, 0.7f, 1.0f, 0.5f) : new Color(0f, 0.4f, 0.6f, 0.4f) },
				fontSize = 14,
				fontStyle = FontStyle.Normal,
			};
			
			#endregion
			#region GUI Styles

			Frame_Style = new GUIStyle(GUI.skin.box)
			{
				normal = { background = Texture_Frame },
				border = new RectOffset(2, 2, 2, 2),
			};

			FrameFill_Style = new GUIStyle(GUI.skin.box);
			if (!EditorGUIUtility.isProSkin)
			{
				FrameFill_Style = new GUIStyle(Frame_Style)
				{
					normal = { background = Texture_FrameFill },
				};
			}

			Label_Style = new GUIStyle(GUI.skin.label)
			{
				normal = { textColor = ActionPropLabelColor }
			};

			ObjectField_Style = new GUIStyle(EditorStyles.objectField)
			{
				normal = { textColor = ActionPropLabelColor }
			};

			LogoContainer_Style = new GUIStyle(GUI.skin.box)
			{
				stretchWidth = true,
				margin = new RectOffset(0, 0, 0, 0),
				padding = new RectOffset(5, 5, 5, 5),
				border = new RectOffset(0, 0, 0, 2),
				normal = { background = Texture_LogoConainerBack },
			}; 

			#endregion

			GUI.skin.customStyles = customStyles;
		}

		private static void LoadResources()
		{
			if (Texture_VinomaIcon != null) return;

			Action_Icons.Add("empty", LoadIcon("empty"));
			
			// story
			Action_Icons.Add("Dialogue", LoadIcon("dialogue"));
			Action_Icons.Add("Label", LoadIcon("label"));
			Action_Icons.Add("Goto", LoadIcon("goto"));
			Action_Icons.Add("Branch", LoadIcon("branch"));
			Action_Icons.Add("Buttons", LoadIcon("buttons"));
			Action_Icons.Add("Pages", LoadIcon("pages"));
			Action_Icons.Add("Hotspots", LoadIcon("hotspots"));

			// character
			Action_Icons.Add("Enter Scene", LoadIcon("chara_enter"));
			Action_Icons.Add("Exit Scene", LoadIcon("chara_exit"));
			Action_Icons.Add("Change Pose", LoadIcon("chara_face"));

			// visual
			Action_Icons.Add("Change Background", LoadIcon("change_image"));
			Action_Icons.Add("Panel", LoadIcon("panel"));
			Action_Icons.Add("Text", LoadIcon("text"));
			Action_Icons.Add("Image", LoadIcon("image"));
			
			// media
			Action_Icons.Add("Start Music", LoadIcon("start_music"));
			Action_Icons.Add("Stop Music", LoadIcon("stop_music"));
			Action_Icons.Add("Play Sound", LoadIcon("play_sound"));
			Action_Icons.Add("Stop Sound", LoadIcon("stop_sound"));

			// effects
			Action_Icons.Add("Wait", LoadIcon("wait"));
			Action_Icons.Add("Animation", LoadIcon("animation"));
			Action_Icons.Add("Move Object", LoadIcon("move_obj"));

			// other
			Action_Icons.Add("Script", LoadIcon("code"));
			Action_Icons.Add("GameObject", LoadIcon("gameobject"));
			Action_Icons.Add("Console", LoadIcon("console"));
			Action_Icons.Add("Variable", LoadIcon("variable"));
			Action_Icons.Add("Switch", LoadIcon("switch"));
			Action_Icons.Add("Blox Event", LoadIcon("blox"));

			// ...
			for (int i = 0; i < Texture_Action.Length; i++)
			{
				Texture_Action[i] = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.action_" + i + ".png", typeof(VinomaEdGUI).Assembly, FilterMode.Trilinear);
			}

			Texture_ActionActive = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.action_a.png", typeof(VinomaEdGUI).Assembly, FilterMode.Trilinear);
			Texture_VinomaIcon = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.icon.png", typeof(VinomaEdGUI).Assembly, FilterMode.Trilinear);
			Texture_LeftPanelBack = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.left_panel" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEdGUI).Assembly);
			Texture_MainPanelBack = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.main_panel" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEdGUI).Assembly);
			Texture_ActionPropsContainer = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.action_props_container" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEdGUI).Assembly, FilterMode.Trilinear);
			Texture_ActionNode = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.action_note.png", typeof(VinomaEdGUI).Assembly);
			Texture_Timeline = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.timeline" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEdGUI).Assembly, FilterMode.Point, TextureWrapMode.Repeat);
			Texture_TimelineDot = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.timeline_dot" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEdGUI).Assembly);

			Texture_Frame = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.gui.frame" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEdGUI).Assembly);
			Texture_FrameFill = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.gui.framefill.png", typeof(VinomaEdGUI).Assembly);

			Texture_Logo = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.logo.png", typeof(VinomaEdGUI).Assembly, FilterMode.Trilinear);
			Texture_LogoConainerBack = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.logo_back.png", typeof(VinomaEdGUI).Assembly);
		}

		private static Texture2D LoadIcon(string name)
		{
			Texture2D t = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.icons."+name+".png", typeof(VinomaEdGUI).Assembly, FilterMode.Trilinear);
			return t;
		}

		public static Texture2D ActionIcon(string name)
		{
			if (Action_Icons.ContainsKey(name)) return Action_Icons[name];
			return Action_Icons["empty"];
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region fields

		public static plyEasing EasingField(GUIContent label, plyEasing easing, params GUILayoutOption[] layoutOptions)
		{
			if (easing == null) { easing = new plyEasing(); GUI.changed = true; }
			EditorGUILayout.BeginHorizontal(layoutOptions);
			EditorGUILayout.PrefixLabel(label);
			easing.time = EditorGUILayout.FloatField(easing.time, GUILayout.MaxWidth(40));
			easing.ease = (DG.Tweening.Ease)EditorGUILayout.EnumPopup(easing.ease);
			EditorGUILayout.EndHorizontal();
			return easing;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}

