﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditorInternal;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public class VinomaHotspotsEd : EditorWindow
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		private static readonly Color BackgroundColor = new Color(0.2f, 0.2f, 0.2f, 1f);
		private const int PropsWidth = 300;
		private const int PropsHeight = 200;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region styles

		private class Styles
		{
			public readonly GUIStyle dragdot = "U2D.dragDot";
			public readonly GUIStyle dragdotactive = "U2D.dragDotActive";
			public readonly GUIStyle preBackground = "preBackground";
			public readonly GUIStyle createRect = "U2D.createRect";
			public readonly GUIStyle dragBorderdot = new GUIStyle();

			public Styles()
			{
				dragBorderdot.fixedHeight = 5f;
				dragBorderdot.fixedWidth = 5f;
				dragBorderdot.normal.background = EditorGUIUtility.whiteTexture;
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region GUIContent

		private static readonly GUIContent GC_Add = new GUIContent(Ico._add, "Add new hotspots overlay");
		private static readonly GUIContent GC_Remove = new GUIContent(Ico._remove, "Remove current hotspots overlay");
		private static readonly GUIContent GC_Rename = new GUIContent(Ico._edit, "Rename current hotspots overlay");
		private static readonly GUIContent GC_ResetView = new GUIContent(Ico._center, "Reset zoom and pan");
		private static readonly GUIContent GC_RefTexture = new GUIContent("ref", "Reference texture");
		private static readonly GUIContent GC_Sprites_Visible = new GUIContent("Sprites " + Ico._visible, "Toggle the hover sprites");
		private static readonly GUIContent GC_Sprites_Hidden = new GUIContent("Sprites " + Ico._hidden, "Toggle the hover sprites");

		private static readonly GUIContent GC_Hotspot = new GUIContent("Hotspot");
		private static readonly GUIContent GC_Position = new GUIContent("Position", "Position of the hotspot");
		private static readonly GUIContent GC_Sprite = new GUIContent("Hover Sprite", "Sprite to show when the mouse is over the hotspot");
		private static readonly GUIContent GC_Actions = new GUIContent("Actions", "Actions to perform when this hotspot is clicked.");
		private static readonly GUIContent gc_Add2 = new GUIContent("+", "Add an action to perform.");
		private static readonly GUIContent gc_Rem2 = new GUIContent("-", "Remove last action.");
		private static readonly GUIContent gc_To = new GUIContent("<>");

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		private static Styles styles;
		private Rect mainRect;
		private Rect texRect;
		private Vector2 refWH;
		private Vector2 scroll = Vector2.zero;
		private Vector2 scroll2 = Vector2.zero;
		private Texture2D refTexture = null;
		private float zoom = 1f;
		private bool spritesVisible = false;

		private GUIContent[] GC_OverlaysPopup = new GUIContent[0];
		private VinomaHotspotsOverlay currOverlay = null;
		private int _currOverlayIdx = -1;
		private int currOverlayIdx 
		{ 
			get { return _currOverlayIdx; } 
			set 
			{
				if (_currOverlayIdx != value)
				{
					currHotspotIdx = -1;
					_currOverlayIdx = value;
					currOverlay = _currOverlayIdx < 0 ? null : VinomaEdGlobal.asset.hotspotOverlays[_currOverlayIdx];
				}
				
			} 
		}

		private VinomaHotspot currHotspot = null;
		private int _currHotspotIdx = -1;
		private int currHotspotIdx { get { return _currHotspotIdx; } set { _currHotspotIdx = value; currHotspot = currOverlay == null || _currHotspotIdx < 0 ? null : currOverlay.hotspots[_currHotspotIdx]; } }

		private static int HASH_ID_NewRect = -1;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region init

		public static void Show_VinomaHotspotsEd()
		{
			EditorWindow.GetWindow<VinomaHotspotsEd>("VHotspots");
		}

		protected void OnEnable()
		{
			UpdateWindowIcon();

			spritesVisible = EditorPrefs.GetBool("VinomaHotspots.SpritesViz", spritesVisible);
		}

		protected void OnDestroy()
		{
		}

		protected void OnFocus()
		{
			//UpdateWindowIcon();
			wantsMouseMove = true;
		}

		protected void OnLostFocus()
		{
			wantsMouseMove = false;
		}

		private void UpdateWindowIcon()
		{
#if !UNITY_4
			if (VinomaEdGUI.Texture_WinIcon == null) VinomaEdGUI.Texture_WinIcon = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.ico_vinoma" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEditorWindow).Assembly);
			//plyEdUtil.SetWindowTitle(this, VinomaEdGUI.Texture_WinIcon, "VHotspots");
			titleContent = new GUIContent("VHotspots", VinomaEdGUI.Texture_WinIcon);
#endif
		}

		private void LoadAsset()
		{
			VinomaEdGlobal.LoadAsset(false);

			if (VinomaEdGlobal.asset != null)
			{
				RefreshOverlaysPopup();

				if (refTexture == null) refWH = new Vector2(VinomaEdGlobal.asset.designWidth, VinomaEdGlobal.asset.designHeight);
				else refWH = new Vector2(refTexture.width, refTexture.height);

				if (currOverlay == null || currOverlayIdx < 0 || currOverlayIdx >= VinomaEdGlobal.asset.hotspotOverlays.Length)
				{
					currOverlayIdx = -1; // force reset
					if (VinomaEdGlobal.asset.hotspotOverlays.Length > 0) currOverlayIdx = 0;
					else currOverlayIdx = -1;
					currHotspotIdx = -1;
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		private void InitGUI()
		{
			VinomaEdGUI.UseSkin();
			if (styles == null)
			{
				styles = new Styles();
			}

			if (HASH_ID_NewRect == -1)
			{
				HASH_ID_NewRect = "VinomaNewRect".GetHashCode(); 
			}
		}

		protected void OnGUI()
		{
			LoadAsset();
			InitGUI();

			if (VinomaEdGlobal.asset == null)
			{
				ShowNotification(new GUIContent("The Vinoma main scene must be open before hotspots overlays can be edited."));
				return;
			}

			Rect r = EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
			DoToolbar();
			EditorGUILayout.EndHorizontal();

			EditorGUILayout.BeginHorizontal();
			mainRect = new Rect(0f, r.yMax, position.width - 16f, position.height - 16f - r.height);
			GUILayout.FlexibleSpace();
			DoMainRect();
			EditorGUILayout.EndHorizontal();

			DoSelectedProperties();

			if (GUI.changed)
			{
				GUI.changed = false;
				if (currOverlay != null) EditorUtility.SetDirty(currOverlay);
				EditorUtility.SetDirty(VinomaEdGlobal.asset);
				EditorSceneManager.MarkAllScenesDirty();
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region toolbar

		private void DoToolbar()
		{
			EditorGUILayout.Space();
			currOverlayIdx = EditorGUILayout.Popup(currOverlayIdx, GC_OverlaysPopup, EditorStyles.toolbarPopup);

			if (GUILayout.Button(GC_Add, plyEdGUI.Style_ToolbarIcoButton))
			{
				plyTextInputWiz.ShowWiz("Add Hotspots Overlay", "Enter a unique name", "Overlay " + (VinomaEdGlobal.asset.hotspotOverlays.Length + 1), OnCreateOverlay, null);
			}

			GUI.enabled = currOverlay != null;

			if (GUILayout.Button(GC_Remove, plyEdGUI.Style_ToolbarIcoButton)) 
			{
				if (EditorUtility.DisplayDialog("Remove Hotspots Overlay", "Removing the Hotspots Overlay can't be undone. Are you sure?", "Yes", "Cancel"))
				{
					RemoveOverlay();
				}

			}
			if (GUILayout.Button(GC_Rename, plyEdGUI.Style_ToolbarIcoButton)) 
			{
				plyTextInputWiz.ShowWiz("Rename Hotspots Overlay", "Enter a unique name", currOverlay.name, OnRenameOverlay, null);
			}

			GUILayout.FlexibleSpace();
			if (GUILayout.Button(GC_ResetView, plyEdGUI.Style_ToolbarIcoButton)) ResetView();

			if (GUILayout.Button(spritesVisible ? GC_Sprites_Visible : GC_Sprites_Hidden, plyEdGUI.Style_ToolbarIcoButton))
			{
				spritesVisible = !spritesVisible;
				EditorPrefs.SetBool("VinomaHotspots.SpritesViz", spritesVisible);
				Repaint();
			}

			EditorGUILayout.Space();
			GUILayout.Label(GC_RefTexture);
			EditorGUI.BeginChangeCheck();
			refTexture = (Texture2D)EditorGUILayout.ObjectField(refTexture, typeof(Texture2D), false);
			if (EditorGUI.EndChangeCheck()) ResetView();
			EditorGUILayout.Space();
			GUI.enabled = true;
		}

		private void ResetView()
		{
			if (refTexture == null) refWH = new Vector2(VinomaEdGlobal.asset.designWidth, VinomaEdGlobal.asset.designHeight);
			else refWH = new Vector2(refTexture.width, refTexture.height);

			plyEdGUI.ClearFocus();
			zoom = GetMinZoom();
			scroll = Vector2.zero;
			Repaint();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region main

		private void DoMainRect()
		{
			if (currOverlay == null)
			{
				plyEdGUI.DrawFilled(mainRect, BackgroundColor);
				plyEdGUI.DrawInnerShadow(mainRect);
				return;
			}

			if (zoom < 0f)
			{
				zoom = this.GetMinZoom();
			}

			texRect = new Rect(mainRect.width / 2f - refWH.x * zoom / 2f, mainRect.height / 2f - refWH.y * zoom / 2f, refWH.x * zoom, refWH.y * zoom);
			plyEdGUI.DrawFilled(mainRect, BackgroundColor);
			Matrix4x4 matrix = Handles.matrix;

			HandleScrollbars();

			SetupMatrix();
			HandleZoom();
			HandlePanning();

			GUI.BeginClip(mainRect);
			if (Event.current.type == EventType.Repaint)
			{
				DrawTexture();
				DrawHotspots();
			}
			HandleMainRectEvents();
			GUI.EndClip();

			Handles.matrix = matrix;
			plyEdGUI.DrawInnerShadow(mainRect);
		}

		private void DrawTexture()
		{
			Rect r = new Rect(texRect.x - scroll.x, texRect.y - scroll.y, texRect.width, texRect.height);
			if (refTexture == null) plyEdGUI.DrawFilled(r, Color.black);
			else EditorGUI.DrawTextureTransparent(r, refTexture);
		}

		private float GetMinZoom()
		{
			return Mathf.Min(mainRect.width / refWH.x, mainRect.height / refWH.y) * 0.9f;
		}

		private void HandleScrollbars()
		{
			float w = refWH.x * 0.5f * zoom;
			float h = refWH.y * 0.5f * zoom;
			Rect maxScrollRect = new Rect(-w, -h, mainRect.width + w * 2f, mainRect.height + h * 2f);
			Rect position1 = new Rect(mainRect.xMin, mainRect.yMax, mainRect.width, 16f);
			scroll.x = GUI.HorizontalScrollbar(position1, scroll.x, mainRect.width, maxScrollRect.xMin, maxScrollRect.xMax);
			Rect position2 = new Rect(mainRect.xMax, mainRect.yMin, 16f, mainRect.height);
			scroll.y = GUI.VerticalScrollbar(position2, scroll.y, mainRect.height, maxScrollRect.yMin, maxScrollRect.yMax);
		}

		private void SetupMatrix()
		{
			Vector3 pos = new Vector3(texRect.x, texRect.yMax, 0f);
			Vector3 s = new Vector3(zoom, -zoom, 1f);
			Handles.matrix = Matrix4x4.TRS(pos, Quaternion.identity, s);
		}

		private void HandleZoom()
		{
			bool flag = Event.current.alt && Event.current.button == 1;
			if (flag)
			{
				EditorGUIUtility.AddCursorRect(mainRect, MouseCursor.Zoom);
			}
			if (((Event.current.type == EventType.MouseUp || Event.current.type == EventType.MouseDown) && flag) || ((Event.current.type == EventType.KeyUp || Event.current.type == EventType.KeyDown) && Event.current.keyCode == KeyCode.LeftAlt))
			{
				base.Repaint();
			}
			if (Event.current.type == EventType.ScrollWheel || (Event.current.type == EventType.MouseDrag && Event.current.alt && Event.current.button == 1))
			{
				float num = 1f - Event.current.delta.y * ((Event.current.type != EventType.ScrollWheel) ? -0.005f : 0.03f);
				float num2 = zoom * num;
				float num3 = Mathf.Clamp(num2, this.GetMinZoom(), 10f);
				if (num3 != zoom)
				{
					zoom = num3;
					if (num2 != num3) num /= num2 / num3;
					scroll *= num;
					Event.current.Use();
				}
			}
		}

		private void HandlePanning()
		{
			bool flag = (!Event.current.alt && Event.current.button > 0) || (Event.current.alt && Event.current.button <= 0);
			if (flag && GUIUtility.hotControl == 0)
			{
				EditorGUIUtility.AddCursorRect(mainRect, MouseCursor.Pan);
				if (Event.current.type == EventType.MouseDrag)
				{
					scroll -= Event.current.delta;
					Event.current.Use();
				}
			}
			if (((Event.current.type == EventType.MouseUp || Event.current.type == EventType.MouseDown) && flag) || ((Event.current.type == EventType.KeyUp || Event.current.type == EventType.KeyDown) && Event.current.keyCode == KeyCode.LeftAlt))
			{
				base.Repaint();
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region draw hotspots

		private void DrawHotspots()
		{
			if (spritesVisible)
			{
				for (int i = 0; i < currOverlay.hotspots.Length; i++)
				{
					if (currOverlay.hotspots[i].hoverSprite != null)
					{
						VinomaHotspot hs = currOverlay.hotspots[i];
						Rect r = currOverlay.hotspots[i].hoverSprite.textureRect;
						r.width = r.width * zoom;
						r.height = r.height * zoom;
						r.x = (mainRect.width / 2f) - (refWH.x * zoom / 2f) + (hs.position.x * zoom) + (hs.position.width / 2 * zoom - r.width / 2f) - scroll.x;
						r.y = (mainRect.height / 2f) + (refWH.y * zoom / 2f) - (hs.position.y * zoom) - r.height - (hs.position.height / 2 * zoom - r.height / 2f) - scroll.y;
						GUI.DrawTexture(r, hs.hoverSprite.texture);
					}
				}
			}

			Handles.color = new Color(0f, 0f, 0f, 1f);
			for (int i = 0; i < currOverlay.hotspots.Length; i++)
			{
				if (i != currHotspotIdx)
				{
					Rect rect = new Rect(currOverlay.hotspots[i].position.x - (scroll.x / zoom), currOverlay.hotspots[i].position.y + (scroll.y / zoom), currOverlay.hotspots[i].position.width, currOverlay.hotspots[i].position.height);
					DrawBox(new Rect(rect.xMin - 2f / zoom, rect.yMin - 2f / zoom, rect.width + 4f / zoom, rect.height +4f / zoom));
				}
			}
			Handles.color = new Color(1f, 1f, 1f, 1f);
			for (int j = 0; j < currOverlay.hotspots.Length; j++)
			{
				if (j != currHotspotIdx)
				{
					Rect rect = new Rect(currOverlay.hotspots[j].position.x - (scroll.x/zoom), currOverlay.hotspots[j].position.y + (scroll.y/zoom), currOverlay.hotspots[j].position.width, currOverlay.hotspots[j].position.height);
					DrawBox(rect);
				}
			}

			if (currHotspot != null)
			{
				Rect rect = new Rect(currHotspot.position.x - (scroll.x / zoom), currHotspot.position.y + (scroll.y / zoom), currHotspot.position.width, currHotspot.position.height);
				Handles.color = new Color(0.25f, 0.5f, 1f, 1f);
				DrawBox(new Rect(rect.xMin - 1f / zoom, rect.yMin - 1f / zoom, rect.width + 2f / zoom, rect.height + 2f / zoom));
				DrawBox(rect);
			}
		}

		private int TrySelectHotspot(Vector2 mousePosition)
		{
			for (int i = 0; i < currOverlay.hotspots.Length; i++)
			{
				Rect rect = new Rect(currOverlay.hotspots[i].position.x - (scroll.x / zoom), currOverlay.hotspots[i].position.y + (scroll.y / zoom), currOverlay.hotspots[i].position.width, currOverlay.hotspots[i].position.height);
				if (rect.Contains(Handles.inverseMatrix.MultiplyPoint(mousePosition)))
				{
					return i;
				}
			}
			return -1;
		}

		private void HandleMainRectEvents()
		{
			if (currHotspot != null && !MouseOnTopOfInspector())
			{
				HandleCornerScaling();
				HandleSideScaling();
				HandleDragging();
			}
			HandleSelection();
			HandleCreate();
			HandleDelete();
		}

		private void HandleCornerScaling()
		{
			Color white = Color.white;
			float sx = (scroll.x / zoom);
			float sy = (scroll.y / zoom);
			Rect rect = new Rect(currHotspot.position.x - sx, currHotspot.position.y + sy, currHotspot.position.width, currHotspot.position.height);
			float xMin = rect.xMin;
			float xMax = rect.xMax;
			float yMax = rect.yMax;
			float yMin = rect.yMin;
			EditorGUI.BeginChangeCheck();
			HandleBorderPointSlider(ref xMin, ref yMax, MouseCursor.ResizeUpLeft, false, styles.dragdot, styles.dragdotactive, white);
			HandleBorderPointSlider(ref xMax, ref yMax, MouseCursor.ResizeUpRight, false, styles.dragdot, styles.dragdotactive, white);
			HandleBorderPointSlider(ref xMin, ref yMin, MouseCursor.ResizeUpRight, false, styles.dragdot, styles.dragdotactive, white);
			HandleBorderPointSlider(ref xMax, ref yMin, MouseCursor.ResizeUpLeft, false, styles.dragdot, styles.dragdotactive, white);
			if (EditorGUI.EndChangeCheck())
			{
				rect.xMin = xMin + sx;
				rect.xMax = xMax + sx;
				rect.yMax = yMax - sy;
				rect.yMin = yMin - sy;
				currHotspot.position = ClampSpriteRect(rect);
			}
			if (GUIUtility.hotControl == 0)
			{
				currHotspot.position = FlipNegativeRect(currHotspot.position);
			}
		}

		private void HandleBorderPointSlider(ref float x, ref float y, MouseCursor mouseCursor, bool isHidden, GUIStyle dragDot, GUIStyle dragDotActive, Color color)
		{
			Color color2 = GUI.color;
			if (isHidden)
			{
				GUI.color = new Color(0f, 0f, 0f, 0f);
			}
			else
			{
				GUI.color = color;
			}
			Vector2 vector = VinomaEdUtil.PointSlider(new Vector2(x, y), mouseCursor, dragDot, dragDotActive);
			x = vector.x;
			y = vector.y;
			GUI.color = color2;
		}

		private void HandleSideScaling()
		{
			float sx = (scroll.x / zoom);
			float sy = (scroll.y / zoom);
			Rect rect = new Rect(currHotspot.position.x - sx, currHotspot.position.y + sy, currHotspot.position.width, currHotspot.position.height);
			float xMin = rect.xMin;
			float xMax = rect.xMax;
			float yMax = rect.yMax;
			float yMin = rect.yMin;
			Vector2 vector = Handles.matrix.MultiplyPoint(new Vector3(rect.xMin, rect.yMin));
			Vector2 vector2 = Handles.matrix.MultiplyPoint(new Vector3(rect.xMax, rect.yMax));
			float width = Mathf.Abs(vector2.x - vector.x);
			float height = Mathf.Abs(vector2.y - vector.y);
			EditorGUI.BeginChangeCheck();
			xMin = HandleBorderScaleSlider(xMin, rect.yMax, width, height, true);
			xMax = HandleBorderScaleSlider(xMax, rect.yMax, width, height, true);
			yMax = HandleBorderScaleSlider(rect.xMin, yMax, width, height, false);
			yMin = HandleBorderScaleSlider(rect.xMin, yMin, width, height, false);
			if (EditorGUI.EndChangeCheck())
			{
				rect.xMin = xMin + sx;
				rect.xMax = xMax + sx;
				rect.yMax = yMax - sy;
				rect.yMin = yMin - sy;
				currHotspot.position = ClampSpriteRect(rect);
			}
		}

		private float HandleBorderScaleSlider(float x, float y, float width, float height, bool isHorizontal)
		{
			float fixedWidth = styles.dragBorderdot.fixedWidth;
			Vector2 pos = Handles.matrix.MultiplyPoint(new Vector2(x, y));
			EditorGUI.BeginChangeCheck();
			float result = 0;
			if (isHorizontal)
			{
				Rect cursorRect = new Rect(pos.x - fixedWidth * 0.5f, pos.y, fixedWidth, height);
				result = VinomaEdUtil.ScaleSlider(pos, MouseCursor.ResizeHorizontal, cursorRect).x;
			}
			else
			{
				Rect cursorRect2 = new Rect(pos.x, pos.y - fixedWidth * 0.5f, width, fixedWidth);
				result = VinomaEdUtil.ScaleSlider(pos, MouseCursor.ResizeVertical, cursorRect2).y;
			}
			if (EditorGUI.EndChangeCheck())
			{
				return result;
			}
			return (!isHorizontal) ? y : x;
		}

		private void HandleDragging()
		{
			float sx = (scroll.x / zoom);
			float sy = (scroll.y / zoom);
			Rect clamp = new Rect(0f, 0f, refWH.x, refWH.y);
			EditorGUI.BeginChangeCheck();
			Rect rect = new Rect(currHotspot.position.x - sx, currHotspot.position.y + sy, currHotspot.position.width, currHotspot.position.height);
			rect = ClampedRect(RoundedRect(VinomaEdUtil.SliderRect(rect)), clamp, true);
			if (EditorGUI.EndChangeCheck())
			{
				currHotspot.position = new Rect(rect.x + sx, rect.y - sy, rect.width, rect.height);
			}
		}

		private void HandleSelection()
		{
			if (Event.current.type == EventType.MouseDown && Event.current.button == 0 && GUIUtility.hotControl == 0 && !Event.current.alt && !MouseOnTopOfInspector())
			{
				int selected = currHotspotIdx;
				currHotspotIdx = TrySelectHotspot(Event.current.mousePosition);
				if (currHotspotIdx >= 0)
				{
					//SpriteEditorWindow.s_OneClickDragStarted = true;
				}
				else
				{
					base.Repaint();
				}
				if (selected != currHotspotIdx && currHotspotIdx >= 0)
				{
					Event.current.Use();
				}
			}
		}

		private void HandleCreate()
		{
			if (!MouseOnTopOfInspector() && !Event.current.alt)
			{
				EditorGUI.BeginChangeCheck();
				Rect rect = VinomaEdUtil.RectCreator(refWH.x, refWH.y, styles.createRect);
				if (EditorGUI.EndChangeCheck() && rect.width > 0f && rect.height > 0f)
				{
					GUIUtility.keyboardControl = 0;
					CreateHotspot(rect);
				}
			}
		}

		private void HandleDelete()
		{
			if (currHotspot == null || currHotspotIdx < 0)
			{
				return;
			}

			if ((Event.current.commandName == "SoftDelete" || Event.current.commandName == "Delete") && (Event.current.type == EventType.ValidateCommand || Event.current.type == EventType.ExecuteCommand))
			{
				if (Event.current.type == EventType.ExecuteCommand)
				{
					ArrayUtility.RemoveAt<VinomaHotspot>(ref currOverlay.hotspots, currHotspotIdx);
					currHotspotIdx = -1;
					EditorUtility.SetDirty(currOverlay);
					EditorUtility.SetDirty(VinomaEdGlobal.asset);
					EditorSceneManager.MarkAllScenesDirty();
					GUI.changed = false;
				}
				Event.current.Use();
			}
		}

		private void CreateHotspot(Rect r)
		{
			r.x += (scroll.x / zoom);
			r.y -= (scroll.y / zoom);

			VinomaHotspot hs = new VinomaHotspot();
			hs.position = r;
			hs.hoverSprite = null;
			hs.actions = new VinomaActionOptDef[0];

			ArrayUtility.Add<VinomaHotspot>(ref currOverlay.hotspots, hs);
			currHotspotIdx = currOverlay.hotspots.Length - 1;

			EditorUtility.SetDirty(currOverlay);
			EditorUtility.SetDirty(VinomaEdGlobal.asset);
			EditorSceneManager.MarkAllScenesDirty();
			GUI.changed = false;
		}

		private bool MouseOnTopOfInspector()
		{
			Rect r = new Rect(position.width - PropsWidth - 20, position.height - PropsHeight - 20, PropsWidth, PropsHeight);
			return r.Contains(Event.current.mousePosition);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region properties

		private void DoSelectedProperties()
		{
			if (currHotspot == null) return;
			GUILayout.BeginArea(new Rect(position.width - PropsWidth - 20, position.height - PropsHeight - 20, PropsWidth, PropsHeight), GC_Hotspot, GUI.skin.window);
			scroll2 = EditorGUILayout.BeginScrollView(scroll2);
			{
				EditorGUIUtility.labelWidth = 100;
				currHotspot.position = EditorGUILayout.RectField(GC_Position, currHotspot.position);
				EditorGUILayout.Space();

				currHotspot.hoverSprite = (Sprite)EditorGUILayout.ObjectField(GC_Sprite, currHotspot.hoverSprite, typeof(Sprite), false);
				EditorGUILayout.Space();

				EditorGUIUtility.labelWidth = 60;
				if (currHotspot.actions.Length == 0)
				{
					EditorGUILayout.BeginHorizontal();
					EditorGUILayout.PrefixLabel(GC_Actions);
				}
				else
				{
					for (int j = 0; j < currHotspot.actions.Length; j++)
					{
						EditorGUILayout.BeginHorizontal();
						if (j == 0) EditorGUILayout.PrefixLabel(GC_Actions);
						else EditorGUILayout.PrefixLabel(" ");

						currHotspot.actions[j].act = (VinomaActionOptDef.Action)EditorGUILayout.EnumPopup(currHotspot.actions[j].act);

						if (currHotspot.actions[j].act == VinomaActionOptDef.Action.Switch)
						{
							currHotspot.actions[j].s_opt1 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt1);
							currHotspot.actions[j].swOpt = (VinomaSwitchOperation)EditorGUILayout.EnumPopup(currHotspot.actions[j].swOpt);
						}
						else if (currHotspot.actions[j].act == VinomaActionOptDef.Action.Variable)
						{
							currHotspot.actions[j].s_opt1 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt1);
							currHotspot.actions[j].varOpt = (VinomaVarOperation)EditorGUILayout.EnumPopup(currHotspot.actions[j].varOpt, GUILayout.Width(70));
							currHotspot.actions[j].s_opt2 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt2);
							if (currHotspot.actions[j].varOpt == VinomaVarOperation.Random)
							{
								GUILayout.Label(gc_To);
								currHotspot.actions[j].s_opt3 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt3);
							}
						}
						else if (currHotspot.actions[j].act == VinomaActionOptDef.Action.Goto)
						{
							currHotspot.actions[j].goOpt = (VinomaGotoOption)EditorGUILayout.EnumPopup(currHotspot.actions[j].goOpt);
							if (currHotspot.actions[j].goOpt == VinomaGotoOption.Label)
							{
								currHotspot.actions[j].s_opt2 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt2);
							}
							else if (currHotspot.actions[j].goOpt == VinomaGotoOption.Scene)
							{
								currHotspot.actions[j].s_opt1 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt1);
								currHotspot.actions[j].s_opt2 = EditorGUILayout.TextField(currHotspot.actions[j].s_opt2);
							}
						}
						EditorGUILayout.EndHorizontal();
					}
					EditorGUILayout.BeginHorizontal();
				}

				GUILayout.FlexibleSpace();
				if (GUILayout.Button(gc_Add2, EditorStyles.miniButtonLeft))
				{
					ArrayUtility.Add<VinomaActionOptDef>(ref currHotspot.actions, new VinomaActionOptDef());
					GUI.changed = true;
				}
				GUI.enabled = currHotspot.actions.Length > 0;
				if (GUILayout.Button(gc_Rem2, EditorStyles.miniButtonRight))
				{
					ArrayUtility.RemoveAt<VinomaActionOptDef>(ref currHotspot.actions, currHotspot.actions.Length - 1);
					GUI.changed = true;
				}
				GUI.enabled = true;
				EditorGUILayout.EndHorizontal();
			}
			EditorGUILayout.EndScrollView();
			GUILayout.EndArea();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region overlays

		private void RefreshOverlaysPopup()
		{
			if (VinomaEdGlobal.asset.scenes != null)
			{
				GC_OverlaysPopup = new GUIContent[VinomaEdGlobal.asset.hotspotOverlays.Length];
				for (int i = 0; i < VinomaEdGlobal.asset.hotspotOverlays.Length; i++)
				{
					GC_OverlaysPopup[i] = new GUIContent(VinomaEdGlobal.asset.hotspotOverlays[i].name);
				}
				Repaint();
			}
			else
			{
				GC_OverlaysPopup = new GUIContent[0];
			}

			VinomaEdGlobal.asset.HotspotOverlayNames = new GUIContent[0];
		}

		private void OnCreateOverlay(plyTextInputWiz wiz)
		{
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				// check if name is unique
				foreach (VinomaHotspotsOverlay sc in VinomaEdGlobal.asset.hotspotOverlays)
				{
					if (sc.name.Equals(s))
					{
						EditorUtility.DisplayDialog("Error", "The name must be unique among all overlays.", "Ok");
						return;
					}
				}

				// create and make active
				CreateOverlay(s);
				currOverlayIdx = VinomaEdGlobal.asset.hotspotOverlays.Length - 1;
				ResetView();
			}
		}

		private void OnRenameOverlay(plyTextInputWiz wiz)
		{
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				// check if name is unique
				foreach (VinomaHotspotsOverlay sc in VinomaEdGlobal.asset.hotspotOverlays)
				{
					if (sc.name.Equals(s) && sc != currOverlay)
					{
						EditorUtility.DisplayDialog("Error", "The name must be unique among all overlays.", "Ok");
						return;
					}
				}

				// rename
				currOverlay.name = s;
				EditorUtility.SetDirty(VinomaEdGlobal.asset);
				EditorSceneManager.MarkAllScenesDirty();
				RefreshOverlaysPopup();
				UpdateActions(currOverlay.ident, false, true);
			}

			Repaint();
		}

		private void CreateOverlay(string name)
		{
			VinomaHotspotsOverlay sc = ScriptableObject.CreateInstance<VinomaHotspotsOverlay>();
			sc.name = name;
			sc.ident = VinomaEdGlobal.asset.CreateHotspotOverlayIdent();
			sc.hotspots = new VinomaHotspot[0];

//#if ASSET_HIDEFLAGS_ON
//			sc.hideFlags = HideFlags.HideInHierarchy;
//#endif
			if (VinomaEdGlobal.asset.scenes == null) VinomaEdGlobal.asset.hotspotOverlays = new VinomaHotspotsOverlay[0];
			ArrayUtility.Add<VinomaHotspotsOverlay>(ref VinomaEdGlobal.asset.hotspotOverlays, sc);
			//AssetDatabase.AddObjectToAsset(sc, VinomaEdGlobal.asset);
			ForceSaveAsset();
			RefreshOverlaysPopup();
		}

		private void RemoveOverlay()
		{
			UpdateActions(currOverlay.ident, true, false);
			ArrayUtility.Remove<VinomaHotspotsOverlay>(ref VinomaEdGlobal.asset.hotspotOverlays, currOverlay);
			DestroyImmediate(currOverlay, true);
			RefreshOverlaysPopup();
			currOverlayIdx--;
			if (currOverlayIdx < 0 && VinomaEdGlobal.asset.hotspotOverlays.Length > 0) currOverlayIdx = 0;
			ForceSaveAsset();
			ResetView();
		}

		private void ForceSaveAsset()
		{
			EditorUtility.SetDirty(VinomaEdGlobal.asset);
			EditorSceneManager.MarkAllScenesDirty();
			//AssetDatabase.SaveAssets();
			//AssetDatabase.ImportAsset(VinomaEdGlobal.ASSET_PATH);
		}

		private void UpdateActions(int changedId, bool removed, bool renamed)
		{
			if (VinomaEdGlobal.asset != null)
			{
				bool dirty = false;
				for (int i = 0; i < VinomaEdGlobal.asset.scenes.Length; i++)
				{
					if (VinomaEdGlobal.asset.scenes[i] == null) continue;
					for (int j = 0; j < VinomaEdGlobal.asset.scenes[i].actions.Length; j++)
					{
						if (VinomaEdGlobal.asset.scenes[i].actions[j] == null) continue;
						VA_Hotspots h = VinomaEdGlobal.asset.scenes[i].actions[j] as VA_Hotspots;
						if (h != null)
						{
							if (h.overlayIdent == changedId)
							{
								dirty = true;
								if (removed)
								{
									h.overlayIdent = 0;
									h._cachedIdx = -1;
									h._cachedName = "-none-";
								}
								else if (renamed)
								{
									h._cachedName = VinomaEdGlobal.asset.GetHotspotOverlayName(changedId);
								}
							}
						}
					}
				}

				if (dirty)
				{
					EditorUtility.SetDirty(VinomaEdGlobal.asset);
					EditorSceneManager.MarkAllScenesDirty();
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region helpers

		private Rect ClampSpriteRect(Rect rect)
		{
			return RoundedRect(new Rect
			{
				xMin = Mathf.Clamp(rect.xMin, 0f, refWH.x - 1),
				yMin = Mathf.Clamp(rect.yMin, 0f, refWH.y - 1),
				xMax = Mathf.Clamp(rect.xMax, 1f, refWH.x),
				yMax = Mathf.Clamp(rect.yMax, 1f, refWH.y)
			});
		}

		private static void DrawBox(Rect position)
		{
			Vector3[] array = new Vector3[5];
			int num = 0;
			array[num++] = new Vector3(position.xMin, position.yMin, 0f);
			array[num++] = new Vector3(position.xMax, position.yMin, 0f);
			array[num++] = new Vector3(position.xMax, position.yMax, 0f);
			array[num++] = new Vector3(position.xMin, position.yMax, 0f);
			array[num++] = new Vector3(position.xMin, position.yMin, 0f);
			Handles.DrawPolyLine(array);
		}

		private static Rect RoundedRect(Rect rect)
		{
			return new Rect((float)Mathf.RoundToInt(rect.xMin), (float)Mathf.RoundToInt(rect.yMin), (float)Mathf.RoundToInt(rect.width), (float)Mathf.RoundToInt(rect.height));
		}

		private static Rect RoundToInt(Rect r)
		{
			r.xMin = (float)Mathf.RoundToInt(r.xMin);
			r.yMin = (float)Mathf.RoundToInt(r.yMin);
			r.xMax = (float)Mathf.RoundToInt(r.xMax);
			r.yMax = (float)Mathf.RoundToInt(r.yMax);
			return r;
		}

		private static Rect ClampedRect(Rect rect, Rect clamp, bool maintainSize)
		{
			Rect result = new Rect(rect);
			if (maintainSize)
			{
				Vector2 center = rect.center;
				if (center.x + Mathf.Abs(rect.width) * 0.5f > clamp.xMax)
				{
					center.x = clamp.xMax - rect.width * 0.5f;
				}
				if (center.x - Mathf.Abs(rect.width) * 0.5f < clamp.xMin)
				{
					center.x = clamp.xMin + rect.width * 0.5f;
				}
				if (center.y + Mathf.Abs(rect.height) * 0.5f > clamp.yMax)
				{
					center.y = clamp.yMax - rect.height * 0.5f;
				}
				if (center.y - Mathf.Abs(rect.height) * 0.5f < clamp.yMin)
				{
					center.y = clamp.yMin + rect.height * 0.5f;
				}
				result.center = center;
			}
			else
			{
				if (result.width > 0f)
				{
					result.xMin = Mathf.Max(rect.xMin, clamp.xMin);
					result.xMax = Mathf.Min(rect.xMax, clamp.xMax);
				}
				else
				{
					result.xMin = Mathf.Min(rect.xMin, clamp.xMax);
					result.xMax = Mathf.Max(rect.xMax, clamp.xMin);
				}
				if (result.height > 0f)
				{
					result.yMin = Mathf.Max(rect.yMin, clamp.yMin);
					result.yMax = Mathf.Min(rect.yMax, clamp.yMax);
				}
				else
				{
					result.yMin = Mathf.Min(rect.yMin, clamp.yMax);
					result.yMax = Mathf.Max(rect.yMax, clamp.yMin);
				}
			}
			result.width = Mathf.Abs(result.width);
			result.height = Mathf.Abs(result.height);
			return result;
		}

		private Rect FlipNegativeRect(Rect rect)
		{
			return new Rect
			{
				xMin = Mathf.Min(rect.xMin, rect.xMax),
				yMin = Mathf.Min(rect.yMin, rect.yMax),
				xMax = Mathf.Max(rect.xMin, rect.xMax),
				yMax = Mathf.Max(rect.yMin, rect.yMax)
			};
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
