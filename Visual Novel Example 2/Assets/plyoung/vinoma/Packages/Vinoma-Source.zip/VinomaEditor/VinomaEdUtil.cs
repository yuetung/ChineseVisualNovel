﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommon2;
using VinomaEngine;

namespace VinomaEditor
{
	// ------------------------------------------------------------------------------------------------------------

	public static class VinomaEdUtil
	{

		public static void ReadChildSprites(List<_SpriteCacheEntry> list, Transform parent, Vector2 offs, Vector2 size, bool addRen = true, bool goDeeper = true)
		{
			if (addRen)
			{
				SpriteRenderer ren = parent.GetComponent<SpriteRenderer>();
				offs = new Vector2(offs.x + parent.localPosition.x * size.x, offs.y - parent.localPosition.y * size.y);
				size = new Vector2(size.x * parent.localScale.x, size.y * parent.localScale.y);

				if (ren != null)
				{
					list.Add(new _SpriteCacheEntry() { sprite = ren.sprite, offs = offs, size = size });
				}
			}

			if (goDeeper)
			{
				// first add all direct children to list
				for (int i = 0; i < parent.childCount; i++)
				{
					ReadChildSprites(list, parent.GetChild(i), offs, size, true, false);
				}

				// now enter each child hierarchy
				for (int i = 0; i < parent.childCount; i++)
				{
					ReadChildSprites(list, parent.GetChild(i), offs, size, false, true);
				}
			}
		}

		public static void DrawImages(List<_SpriteCacheEntry> _spriteCache, Rect controlRect, bool mirror, float zoom = 0f)
		{
			if (_spriteCache == null || _spriteCache.Count == 0) return;

			controlRect.width -= 2;
			controlRect.height -= 2;
			GUI.BeginGroup(new Rect(controlRect.x + 1, controlRect.y + 1, controlRect.width, controlRect.height));
			controlRect.x = 0;
			controlRect.y = 0;

			float wRatio = 1f, hRatio = 1f;

			for (int i = 0; i < _spriteCache.Count; i++)
			{
				if (_spriteCache[i].sprite == null) continue; // sanity check

				if (i == 0)
				{
					Vector2 sz = DrawAsMainSprite(_spriteCache[i].sprite, controlRect, mirror, zoom);
					wRatio = sz.x / _spriteCache[i].sprite.rect.width;
					hRatio = sz.y / _spriteCache[i].sprite.rect.height;
				}
				else
				{
					DrawSubSprite(_spriteCache[i].sprite, controlRect, _spriteCache[i].offs, _spriteCache[i].size, wRatio, hRatio, zoom);
				}
			}
			GUI.EndGroup();
		}

		private static Vector2 DrawAsMainSprite(Sprite sprite, Rect controlRect, bool mirror, float zoom)
		{
			Rect thumbRect = new Rect(0f, 0f, sprite.rect.width, sprite.rect.height);

			if (thumbRect.width > controlRect.width)
			{
				float f = controlRect.width / thumbRect.width;
				thumbRect.width *= f; thumbRect.height *= f;
			}
			if (thumbRect.height > controlRect.height)
			{
				float f = controlRect.height / thumbRect.height;
				thumbRect.width *= f; thumbRect.height *= f;
			}

			Vector2 res = new Vector2(thumbRect.width, thumbRect.height);

			if (zoom != 0.0f)
			{
				thumbRect.y += thumbRect.height;
				thumbRect.width *= zoom;
				thumbRect.height *= zoom;
			}

			thumbRect.x += (controlRect.width - thumbRect.width) / 2f;
			thumbRect.y += (controlRect.height - thumbRect.height) / 2f;

			if (mirror)
			{
				thumbRect.x += thumbRect.width;
				thumbRect.width *= -1;
			}

			// Draw the thumbnail
			Rect spriteRect = new Rect(sprite.rect.x / sprite.texture.width, sprite.rect.y / sprite.texture.height, sprite.rect.width / sprite.texture.width, sprite.rect.height / sprite.texture.height);
			GUI.DrawTextureWithTexCoords(thumbRect, sprite.texture, spriteRect, true);

			return res;
		}

		private static void DrawSubSprite(Sprite sp, Rect controlRect, Vector2 offs, Vector2 size, float wRatio, float hRatio, float zoom)
		{
			Rect r = new Rect(0f, 0f, sp.rect.width, sp.rect.height);
			r.width *= wRatio * size.x;
			r.height *= hRatio * size.y;

			if (zoom != 0.0f)
			{
				r.y += controlRect.height;
				r.width *= zoom;
				r.height *= zoom;
				hRatio *= zoom;
			}

			r.x += ((controlRect.width - r.width) / 2f) + (sp.pixelsPerUnit * wRatio * offs.x);
			r.y += ((controlRect.height - r.height) / 2f) + (sp.pixelsPerUnit * hRatio * offs.y);

			// Draw the thumbnail
			Rect spriteRect = new Rect(sp.rect.x / sp.texture.width, sp.rect.y / sp.texture.height, sp.rect.width / sp.texture.width, sp.rect.height / sp.texture.height);
			GUI.DrawTextureWithTexCoords(r, sp.texture, spriteRect, true);
		}

		// ------------------------------------------------------------------------------------------------------------

		private static Assembly editorAsm;
		private static MethodInfo RectCreator_Method;
		private static MethodInfo SliderRect_Method;
		private static MethodInfo ScaleSlider_Method;
		private static MethodInfo PointSlider_Method;

		/// <summary> SpriteEditorHandles.RectCreator() </summary>
		public static Rect RectCreator(float textureWidth, float textureHeight, GUIStyle rectStyle)
		{
			if (RectCreator_Method == null)
			{
				if (editorAsm == null) editorAsm = Assembly.GetAssembly(typeof(Editor));
				System.Type t = editorAsm.GetType("UnityEditorInternal.SpriteEditorHandles");
				RectCreator_Method = t.GetMethod("RectCreator", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(float), typeof(float), typeof(GUIStyle) }, null);
			}
			object o = RectCreator_Method.Invoke(null, new object[] { textureWidth, textureHeight, rectStyle });
			return (Rect)o;
		}

		/// <summary> SpriteEditorHandles.SliderRect() </summary>
		public static Rect SliderRect(Rect pos)
		{
			if (SliderRect_Method == null)
			{
				if (editorAsm == null) editorAsm = Assembly.GetAssembly(typeof(Editor));
				System.Type t = editorAsm.GetType("UnityEditorInternal.SpriteEditorHandles");
				SliderRect_Method = t.GetMethod("SliderRect", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(Rect) }, null);
			}
			object o = SliderRect_Method.Invoke(null, new object[] { pos });
			return (Rect)o;
		}

		/// <summary> SpriteEditorHandles.ScaleSlider() </summary>
		public static Vector2 ScaleSlider(Vector2 pos, MouseCursor cursor, Rect cursorRect)
		{
			if (ScaleSlider_Method == null)
			{
				if (editorAsm == null) editorAsm = Assembly.GetAssembly(typeof(Editor));
				System.Type t = editorAsm.GetType("UnityEditorInternal.SpriteEditorHandles");
				ScaleSlider_Method = t.GetMethod("ScaleSlider", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(Vector2), typeof(MouseCursor), typeof(Rect) }, null);
			}
			object o = ScaleSlider_Method.Invoke(null, new object[] { pos, cursor, cursorRect });
			return (Vector2)o;
		}

		/// <summary> SpriteEditorHandles.ScaleSlider() </summary>
		public static Vector2 PointSlider(Vector2 pos, MouseCursor cursor, GUIStyle dragDot, GUIStyle dragDotActive)
		{
			if (PointSlider_Method == null)
			{
				if (editorAsm == null) editorAsm = Assembly.GetAssembly(typeof(Editor));
				System.Type t = editorAsm.GetType("UnityEditorInternal.SpriteEditorHandles");
				PointSlider_Method = t.GetMethod("PointSlider", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(Vector2), typeof(MouseCursor), typeof(GUIStyle), typeof(GUIStyle) }, null);
			}
			object o = PointSlider_Method.Invoke(null, new object[] { pos, cursor, dragDot, dragDotActive });
			return (Vector2)o;
		}

	}

	// ------------------------------------------------------------------------------------------------------------
}
