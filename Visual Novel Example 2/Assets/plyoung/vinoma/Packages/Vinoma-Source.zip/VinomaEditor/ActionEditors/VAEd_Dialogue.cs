﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Story, "Dialogue", typeof(VA_Dialogue), "Show dialogue text and optionally play a sound")]
	public class VAEd_Dialogue : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "Name of the character talking.");
		private static GUIContent gc_Text = new GUIContent("Text", "Conversation text to show.");
		private static GUIContent gc_Portrait = new GUIContent("Portrait", "Optional portrait to show.");
		private static GUIContent gc_Clip = new GUIContent("Sound", "Optional Dialogue sound to play. This will stop any currently playing dialogue sound.");
		private static GUIContent gc_Balance = new GUIContent("Balance", "Only valid for Mono and Stereo AudioClips. Mono sounds will be panned at constant power left and right. Stereo sounds will Stereo sounds have each left/right value faded up and down according to the specified pan value.");
		private static GUIContent[] gc_Labels = { new GUIContent("Left"), new GUIContent("Right") };

		public override void DrawProperties(VinomaAction action)
		{
			VA_Dialogue ac = action as VA_Dialogue;
			EditorGUIUtility.labelWidth = 70;
			ac.characterName = EditorGUILayout.TextField(gc_Name, ac.characterName);
			EditorGUILayout.PrefixLabel(gc_Text);
			ac.text = EditorGUILayout.TextArea(ac.text, EditorStyles.textArea);
			EditorGUILayout.Space();
			ac.portrait = (Sprite)EditorGUILayout.ObjectField(gc_Portrait, ac.portrait, typeof(Sprite), false);
			ac.clip = (AudioClip)EditorGUILayout.ObjectField(gc_Clip, ac.clip, typeof(AudioClip), false);
			ac.balance = EditorGUILayout.Slider(gc_Balance, ac.balance, -1f, +1f);
			plyEdGUI.SliderLabels(GUILayoutUtility.GetLastRect(), gc_Labels[0], gc_Labels[1]);
			EditorGUILayout.Space();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
