﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public enum VinomaActionGroup
	{
		Story=0,
		Characters,
		Visual,
		Media,
		Effects,
		Other,

		MAX,
	}
}
