﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Other, "Variable", typeof(VA_Variable), "Assign or manipulate a game variable")]
	public class VAEd_Variable : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "Name of Variable.");
		private static GUIContent gc_Opt = new GUIContent("Operator", "What operation to perform on the variable.");
		private static GUIContent gc_To = new GUIContent("<>");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Variable ac = action as VA_Variable;
			EditorGUIUtility.labelWidth = 70;
			ac.varName = EditorGUILayout.TextField(gc_Name, ac.varName);
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.PrefixLabel(gc_Opt);
				ac.opt = (VinomaVarOperation)EditorGUILayout.EnumPopup(ac.opt, GUILayout.Width(100));
				ac.value = EditorGUILayout.TextField(ac.value);
				if (ac.opt == VinomaVarOperation.Random)
				{
					GUILayout.Label(gc_To);
					ac.value2 = EditorGUILayout.TextField(ac.value2);
				}
			}
			EditorGUILayout.EndHorizontal();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
