﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Story, "Buttons", typeof(VA_Buttons), "Show Buttons")]
	public class VAEd_Buttons : VinomaActionEd
	{
		private static GUIContent gc_Add = new GUIContent("+", "Add a button.");
		private static GUIContent gc_Rem = new GUIContent("-", "Remove last button.");
		private static GUIContent gc_Text = new GUIContent("Text", "Text to show on the button.");
		private static GUIContent gc_Act = new GUIContent("Actions", "Actions to perform when this button is pressed.");
		private static GUIContent gc_Add2 = new GUIContent("+", "Add an action to perform.");
		private static GUIContent gc_Rem2 = new GUIContent("-", "Remove last action.");
		private static GUIContent gc_Timeout = new GUIContent(" Timeout", "Enable this if a button should automatically be chosen after a certain amount of wait time (in seconds).");
		private static GUIContent gc_Timeout2 = new GUIContent(" ", "The button that should be selected when timeout is reached");
		private static GUIContent gc_Sec = new GUIContent(" seconds");
		private static GUIContent gc_To = new GUIContent("<>");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Buttons ac = action as VA_Buttons;
			EditorGUIUtility.labelWidth = 70;

			for (int i = 0; i < ac.buttons.Length; i++)
			{
				EditorGUILayout.BeginVertical(VinomaEdGUI.FrameFill_Style);
				{
					ac.buttons[i].text = EditorGUILayout.TextField(gc_Text, ac.buttons[i].text);

					if (ac.buttons[i].actions.Length == 0)
					{
						EditorGUILayout.BeginHorizontal();
						EditorGUILayout.PrefixLabel(gc_Act);
					}
					else
					{
						for (int j = 0; j < ac.buttons[i].actions.Length; j++)
						{
							EditorGUILayout.BeginHorizontal();
							if (j == 0) EditorGUILayout.PrefixLabel(gc_Act);
							else EditorGUILayout.PrefixLabel(" ");

							ac.buttons[i].actions[j].act = (VinomaActionOptDef.Action)EditorGUILayout.EnumPopup(ac.buttons[i].actions[j].act);

							if (ac.buttons[i].actions[j].act == VinomaActionOptDef.Action.Switch)
							{
								ac.buttons[i].actions[j].s_opt1 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt1);
								ac.buttons[i].actions[j].swOpt = (VinomaSwitchOperation)EditorGUILayout.EnumPopup(ac.buttons[i].actions[j].swOpt);
							}
							else if (ac.buttons[i].actions[j].act == VinomaActionOptDef.Action.Variable)
							{
								ac.buttons[i].actions[j].s_opt1 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt1);
								ac.buttons[i].actions[j].varOpt = (VinomaVarOperation)EditorGUILayout.EnumPopup(ac.buttons[i].actions[j].varOpt, GUILayout.Width(70));
								ac.buttons[i].actions[j].s_opt2 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt2);
								if (ac.buttons[i].actions[j].varOpt == VinomaVarOperation.Random)
								{
									GUILayout.Label(gc_To);
									ac.buttons[i].actions[j].s_opt3 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt3);
								}
							}
							else if (ac.buttons[i].actions[j].act == VinomaActionOptDef.Action.Goto)
							{
								ac.buttons[i].actions[j].goOpt = (VinomaGotoOption)EditorGUILayout.EnumPopup(ac.buttons[i].actions[j].goOpt);
								if (ac.buttons[i].actions[j].goOpt == VinomaGotoOption.Label)
								{
									ac.buttons[i].actions[j].s_opt2 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt2);
								}
								else if (ac.buttons[i].actions[j].goOpt == VinomaGotoOption.Scene)
								{
									ac.buttons[i].actions[j].s_opt1 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt1);
									ac.buttons[i].actions[j].s_opt2 = EditorGUILayout.TextField(ac.buttons[i].actions[j].s_opt2);
								}
							}
							EditorGUILayout.EndHorizontal();
						}						
						EditorGUILayout.BeginHorizontal();
					}

					GUILayout.FlexibleSpace();
					if (ac.timeoutOpt >= 0)
					{
						bool t = ac.timeoutOpt == i;
						EditorGUI.BeginChangeCheck();
						t = EditorGUILayout.ToggleLeft(gc_Timeout2, t, GUILayout.Width(25), GUILayout.Height(16));
						if (EditorGUI.EndChangeCheck() && t)
						{
							ac.timeoutOpt = i;
							GUI.changed = true;
						}
					}

					if (GUILayout.Button(gc_Add2, EditorStyles.miniButtonLeft))
					{
						ArrayUtility.Add<VinomaActionOptDef>(ref ac.buttons[i].actions, new VinomaActionOptDef());

						GUI.changed = true;
					}
					GUI.enabled = ac.buttons[i].actions.Length > 0 && !EditorApplication.isPlayingOrWillChangePlaymode;
					if (GUILayout.Button(gc_Rem2, EditorStyles.miniButtonRight))
					{
						ArrayUtility.RemoveAt<VinomaActionOptDef>(ref ac.buttons[i].actions, ac.buttons[i].actions.Length - 1);
						GUI.changed = true;
					}
					GUI.enabled = !EditorApplication.isPlayingOrWillChangePlaymode;
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.EndVertical();
			}

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				if (GUILayout.Button(gc_Add, EditorStyles.miniButtonLeft))
				{
					ArrayUtility.Add<VinomaButtonDef>(ref ac.buttons, new VinomaButtonDef());
					ac.buttons[ac.buttons.Length - 1].actions = new VinomaActionOptDef[0];
					GUI.changed = true;
				}
				GUI.enabled = ac.buttons.Length > 0 && !EditorApplication.isPlayingOrWillChangePlaymode;
				if (GUILayout.Button(gc_Rem, EditorStyles.miniButtonRight))
				{
					ArrayUtility.RemoveAt<VinomaButtonDef>(ref ac.buttons, ac.buttons.Length - 1);
					GUI.changed = true;
				}
				GUI.enabled = !EditorApplication.isPlayingOrWillChangePlaymode;

				EditorGUILayout.Space();
				bool t = ac.timeoutOpt >= 0;
				EditorGUI.BeginChangeCheck();
				t = EditorGUILayout.ToggleLeft(gc_Timeout, t, GUILayout.Width(75));
				if (EditorGUI.EndChangeCheck())
				{
					if (t == false) ac.timeoutOpt = -1;
					else if (ac.timeoutOpt < 0) ac.timeoutOpt = 0;
					GUI.changed = true;
				}

				if (ac.timeoutOpt >= 0)
				{
					ac.timeoutTime = EditorGUILayout.FloatField(ac.timeoutTime, GUILayout.Width(60));
					GUILayout.Label(gc_Sec);
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
