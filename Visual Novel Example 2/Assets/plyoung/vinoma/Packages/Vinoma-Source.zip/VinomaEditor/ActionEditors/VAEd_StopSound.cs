﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Media, "Stop Sound", typeof(VA_StopSound), "Stop the named sound clip")]
	public class VAEd_StopSound : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "Name of the sound the stop. Only sounds that where started with a name can be stopped.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_StopSound ac = action as VA_StopSound;
			EditorGUIUtility.labelWidth = 70;
			plyEdGUI.TextSelect(gc_Name, ac.soundName, GetSoundNamesUsedInScene, OnNameSelected, ac);
		}

		private void OnNameSelected(string s, object obj)
		{
			VA_StopSound ac = obj as VA_StopSound;
			if (ac != null)
			{
				GUI.changed = true;
				ac.soundName = s;
			}
		}

		// ------------------------------------------------------------------------------------------------------------

		public static string[] GetSoundNamesUsedInScene()
		{
			if (VinomaEditorWindow.Instance == null || VinomaEditorWindow.Instance.currScene == null) return new string[0];
			List<string> res = new List<string>();

			for (int i = 0; i < VinomaEditorWindow.Instance.currScene.actions.Length; i++)
			{
				VA_PlaySound ac = VinomaEditorWindow.Instance.currScene.actions[i] as VA_PlaySound;
				if (ac != null && !string.IsNullOrEmpty(ac.soundName) && !res.Contains(ac.soundName)) res.Add(ac.soundName);
			}

			return res.ToArray();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
