﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Story, "Hotspots", typeof(VA_Hotspots), "Enable or disable a hotspots overlay")]
	public class VAEd_Hotspots : VinomaActionEd
	{
		private static GUIContent gc_Target = new GUIContent("Target", "The hotspots overlay to enable/ disable.");
		private static GUIContent gc_Scale = new GUIContent("Scale", "What to use as reference for the scaling and position of the hotspots.");
		private static GUIContent gc_Edit = new GUIContent(Ico._edit + " Edit", "Open hotspots overlay editor.");
		private static GUIContent gc_Disable = new GUIContent("Auto-disable", "Should the hotspots overlay be automatically disabled when a hotspot is clicked?");
		private static GUIContent gc_Wait = new GUIContent("Wait", "Wait for a hotspot to be clicked or move on to the next action immediately?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Hotspots ac = action as VA_Hotspots;

			if (ac._cachedIdx < 0 && ac.overlayIdent > 0)
			{
				GUI.changed = true;
				ac._cachedIdx = VinomaEdGlobal.asset.GetHotspotOverlayIDX(ac.overlayIdent);
				if (ac._cachedIdx < 0) ac.overlayIdent = 0; // reset since overlay is missing
				ac._cachedName = VinomaEdGlobal.asset.GetHotspotOverlayName(ac.overlayIdent);
				if (string.IsNullOrEmpty(ac._cachedName)) ac._cachedName = "-none-";
			}

			EditorGUIUtility.labelWidth = 70;
			ac.opt = (VinomaEnableOption)EditorGUILayout.EnumPopup(ac.opt);
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUI.BeginChangeCheck();
				ac._cachedIdx = EditorGUILayout.Popup(gc_Target, ac._cachedIdx, VinomaEdGlobal.asset.HotspotOverlayNames);
				if (EditorGUI.EndChangeCheck())
				{
					ac.overlayIdent = VinomaEdGlobal.asset.GetHotspotOverlayIdent(ac._cachedIdx);
					ac._cachedName = VinomaEdGlobal.asset.GetHotspotOverlayName(ac.overlayIdent);
					if (string.IsNullOrEmpty(ac._cachedName)) ac._cachedName = "-none-";
				}
				if (GUILayout.Button(gc_Edit, plyEdGUI.Style_MiniIcoButtonRight, GUILayout.Width(60)))
				{
					VinomaHotspotsEd.Show_VinomaHotspotsEd();
				}
			}
			EditorGUILayout.EndHorizontal();
			if (ac.opt == VinomaEnableOption.Enable)
			{
				ac.refScale = (VinomaWidthAdapt)EditorGUILayout.EnumPopup(gc_Scale, ac.refScale);
				EditorGUILayout.BeginHorizontal();
				{
					ac.wait = EditorGUILayout.Toggle(gc_Wait, ac.wait);
					EditorGUIUtility.labelWidth = 90;
					ac.autoDisable = EditorGUILayout.Toggle(gc_Disable, ac.autoDisable);
				}
				EditorGUILayout.EndHorizontal();
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
