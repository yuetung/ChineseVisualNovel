﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Story, "Label", typeof(VA_Label), "Add a label to the scene which can be used by the Goto action")]
	public class VAEd_Label : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "Name of label.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Label ac = action as VA_Label;
			EditorGUIUtility.labelWidth = 70;
			ac.labelName = EditorGUILayout.TextField(gc_Name, ac.labelName);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
