﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Other, "Switch", typeof(VA_Switch), "Assign or manipulate a switch")]
	public class VAEd_Switch : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "Name of Switch.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Switch ac = action as VA_Switch;
			EditorGUIUtility.labelWidth = 70;
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.PrefixLabel(gc_Name);
				ac.varName = EditorGUILayout.TextField(ac.varName);
				ac.opt = (VinomaSwitchOperation)EditorGUILayout.EnumPopup(ac.opt, GUILayout.Width(150));
			}
			EditorGUILayout.EndHorizontal();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
