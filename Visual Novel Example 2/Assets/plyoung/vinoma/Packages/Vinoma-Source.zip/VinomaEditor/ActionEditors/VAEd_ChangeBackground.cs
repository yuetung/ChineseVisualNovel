﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;
using VinomaEditor;
using plyCommon2;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Visual, "Change Background", typeof(VA_ChangeBackground), "Replace any visible background with a new background")]
	public class VAEd_ChangeBackground: VinomaActionEd
	{
		private static readonly RectOffset padding = new RectOffset(1, 1, 1, 1);
		private static GUIContent gc_Source = new GUIContent("Source", "The sprite to use as background.");
		private static GUIContent gc_Scale = new GUIContent("Scaling", "How the background image should adapt to the screen size.");
		private static GUIContent gc_Fade = new GUIContent("Fade", "How long the fade-in should take in seconds. Set to 0 to disable.");
		private static GUIContent gc_Wait = new GUIContent("Wait", "Wait for the background fade-in to complete before moving on to the next action?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_ChangeBackground ac = action as VA_ChangeBackground;

			EditorGUILayout.BeginHorizontal();
			{
				//Rect r = GUILayoutUtility.GetRect(150, 95, GUILayout.Width(150), GUILayout.Height(95));
				//plyEdGUI.DrawThumbnailWithFrame(ac.image, r, padding, VinomaEdGUI.FrameFill_Style, true);

				ac.image = (Sprite)EditorGUILayout.ObjectField(ac.image, typeof(Sprite), false, GUILayout.Width(150), GUILayout.Height(95));

				EditorGUILayout.BeginVertical();
				{
					EditorGUIUtility.labelWidth = 70;
					//ac.image = (Sprite)EditorGUILayout.ObjectField(gc_Source, ac.image, typeof(Sprite), false);
					ac.scaleType = (ply2D.ScaleType)EditorGUILayout.EnumPopup(gc_Scale, ac.scaleType);
					ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
					ac.waitComplete = EditorGUILayout.Toggle(gc_Wait, ac.waitComplete);
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
