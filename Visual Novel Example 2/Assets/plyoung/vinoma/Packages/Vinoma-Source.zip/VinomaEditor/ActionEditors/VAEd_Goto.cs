﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Story, "Goto", typeof(VA_Goto), "Go to another label or scene and continue actions from there")]
	public class VAEd_Goto : VinomaActionEd
	{
		private static GUIContent gc_Goto1 = new GUIContent("Go to", "Choose to go to a label or scene.");
		private static GUIContent gc_LabelName = new GUIContent("Label", "Name of label to go to.");
		private static GUIContent gc_SceneName = new GUIContent("Scene", "Name of scene to go to.");
		private static GUIContent gc_GotoLabel = new GUIContent("Label", "Go to optional label in the scene?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Goto ac = action as VA_Goto;
			EditorGUIUtility.labelWidth = 70;
			ac.gotoOpt = (VinomaGotoOption)EditorGUILayout.EnumPopup(gc_Goto1, ac.gotoOpt);

			if (ac.gotoOpt == VinomaGotoOption.Label)
			{
				ac.labelName = EditorGUILayout.TextField(gc_LabelName, ac.labelName);
			}
			else if (ac.gotoOpt == VinomaGotoOption.Scene)
			{
				ac.sceneName = EditorGUILayout.TextField(gc_SceneName, ac.sceneName);
				EditorGUILayout.BeginHorizontal();
				{
					EditorGUILayout.PrefixLabel(gc_GotoLabel);
					ac.gotoSceneLabel = EditorGUILayout.Toggle(ac.gotoSceneLabel, GUILayout.Width(25));
					if (ac.gotoSceneLabel)
					{
						ac.labelName = EditorGUILayout.TextField(ac.labelName);
					}
				}
				EditorGUILayout.EndHorizontal();
			}
			
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
