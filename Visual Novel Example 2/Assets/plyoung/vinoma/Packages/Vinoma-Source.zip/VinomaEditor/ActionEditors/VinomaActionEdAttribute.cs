﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
	public class VinomaActionEdAttribute: System.Attribute
	{
		public VinomaActionGroup Group;
		public string Name;
		public string Tooltip;
		public System.Type Target;

		public VinomaActionEdAttribute(VinomaActionGroup group, string name, System.Type target, string tooltip)
		{
			Group = group;
			Name = name;
			Target = target;
			Tooltip = tooltip;
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
