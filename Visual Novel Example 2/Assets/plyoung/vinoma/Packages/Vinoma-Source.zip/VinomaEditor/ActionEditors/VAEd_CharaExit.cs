﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Characters, "Exit Scene", typeof(VA_CharaExit), "Remove a character from the scene")]
	public class VAEd_CharaExit : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "The name of the character that should exist the scene. Can only be applied to a character that are present in the scene.");
		private static GUIContent gc_Exit = new GUIContent("Exit", "The direction the character should exit in.");
		private static GUIContent gc_Move = new GUIContent("Move", "How long the exit movement should take in seconds when Exit is not set to In-Place. Will not have an effect if set to 0.");
		private static GUIContent gc_Fade = new GUIContent("Fade", "How long the fade-out should take in seconds. Set to 0 to disable.");
		private static GUIContent gc_Wait = new GUIContent("Wait", "Wait for the fade-out (or move, whichever takes longer) to complete before moving on to the next action?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_CharaExit ac = action as VA_CharaExit;
			EditorGUIUtility.labelWidth = 50;
			plyEdGUI.TextSelect(gc_Name, ac.characterName, VinomaEdGlobal.GetCharacterNamesUsedInScene, OnNameSelected, ac);

			EditorGUILayout.BeginHorizontal();
			{
				ac.exitTo = (VinomaSceneSide)EditorGUILayout.EnumPopup(gc_Exit, ac.exitTo);
				if (ac.exitTo != VinomaSceneSide.InPlace)
				{
					GUILayout.Space(10);
					ac.moveEasing = VinomaEdGUI.EasingField(gc_Move, ac.moveEasing, GUILayout.Width(VinomaEdGUI.PropertyPanelWidth / 2));
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			{
				ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
				GUILayout.Space(10);
				ac.waitComplete = EditorGUILayout.Toggle(gc_Wait, ac.waitComplete, GUILayout.Width(VinomaEdGUI.PropertyPanelWidth / 2));
			}
			EditorGUILayout.EndHorizontal();
		}

		private void OnNameSelected(string s, object obj)
		{
			VA_CharaExit ac = obj as VA_CharaExit;
			if (ac != null)
			{
				ac.characterName = s;
				GUI.changed = true;
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
