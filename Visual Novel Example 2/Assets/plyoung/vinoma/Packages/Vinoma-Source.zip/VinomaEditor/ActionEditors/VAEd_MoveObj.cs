﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;
using VinomaEditor;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Effects, "Move Object", typeof(VA_MoveObj), "Moves an object to a target position")]
	public class VAEd_MoveObj : VinomaActionEd
	{
		private static GUIContent gc_Object = new GUIContent("Object", "The GameObject to move.");
		private static GUIContent gc_Target = new GUIContent("Target", "The object/ transform that represents the target position.");
		private static GUIContent gc_Speed = new GUIContent("Speed", "How fast to move the object.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_MoveObj ac = action as VA_MoveObj;
			EditorGUIUtility.labelWidth = 80;

			ac.targetObj = (GameObject)EditorGUILayout.ObjectField(gc_Object, ac.targetObj, typeof(GameObject), true);
			ac.targetTr = (GameObject)EditorGUILayout.ObjectField(gc_Target, ac.targetTr, typeof(GameObject), true);
			ac.speed = EditorGUILayout.FloatField(gc_Speed, ac.speed);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
