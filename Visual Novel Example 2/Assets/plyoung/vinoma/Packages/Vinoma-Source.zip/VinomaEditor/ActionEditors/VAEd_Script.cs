﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Other, "Script", typeof(VA_Script), "Call a function that is in a script attached to the CustomScripts GameObject")]
	public class VAEd_Script : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Function", "Name of function to call in a script attached to the 'CustomScripts' GameObject.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Script ac = action as VA_Script;
			EditorGUIUtility.labelWidth = 70;
			ac.functionName = EditorGUILayout.TextField(gc_Name, ac.functionName);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
