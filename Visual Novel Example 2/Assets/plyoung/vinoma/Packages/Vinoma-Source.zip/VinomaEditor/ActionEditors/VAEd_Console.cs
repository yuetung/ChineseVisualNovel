﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Other, "Console", typeof(VA_Console), "Show a message on the Unity console")]
	public class VAEd_Console : VinomaActionEd
	{
		private static GUIContent gc_Msg = new GUIContent("Message", "The message to show on the Unity console.");
		private static GUIContent gc_Opt = new GUIContent("Show", "Optionally show the value from a game variable or switch.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Console ac = action as VA_Console;
			EditorGUIUtility.labelWidth = 70;
			ac.message = EditorGUILayout.TextField(gc_Msg, ac.message);
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.PrefixLabel(gc_Opt);
				ac.opt = (VA_Console.ConsoleVarOpt)EditorGUILayout.EnumPopup(ac.opt);
				if (ac.opt != VA_Console.ConsoleVarOpt.None)
				{
					ac.varName = EditorGUILayout.TextField(ac.varName, GUILayout.MinWidth(200));
				}
			}
			EditorGUILayout.EndHorizontal();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
