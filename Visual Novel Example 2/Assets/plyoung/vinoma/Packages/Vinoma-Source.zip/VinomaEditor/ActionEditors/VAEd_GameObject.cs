﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Visual, "GameObject", typeof(VA_GameObject), "Enable or disable a Unity GameObject")]
	public class VAEd_GameObject : VinomaActionEd
	{
		private static GUIContent gc_Target = new GUIContent("Target", "The GameObject to enable or disable.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_GameObject ac = action as VA_GameObject;
			EditorGUIUtility.labelWidth = 70;
			ac.opt = (VinomaEnableOption)EditorGUILayout.EnumPopup(ac.opt);
			ac.target = (GameObject)EditorGUILayout.ObjectField(gc_Target, ac.target, typeof(GameObject), true);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
