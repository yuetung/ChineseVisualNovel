﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Story, "Branch", typeof(VA_Branch), "Branch will divert action execution depending on the first condition that is met.")]
	public class VAEd_Branch : VinomaActionEd
	{
		private static readonly GUIContent[] GC_VinomaVarConditions = new GUIContent[] { new GUIContent("=", "Equal to"), new GUIContent("!=", "Not Equal to"), new GUIContent("<", "Smaller than"), new GUIContent(">", "Bigger than"), new GUIContent("<=", "Smaller than or Equal to"), new GUIContent(">=", "Bigger than or Equal to") };

		private static GUIContent gc_Add = new GUIContent("+", "Add a branch.");
		private static GUIContent gc_Rem = new GUIContent("-", "Remove last branch.");
		private static GUIContent gc_Do = new GUIContent("Goto", "Action to perform when the conditions are met.");
		private static GUIContent gc_If = new GUIContent("If", "The conditions to check for.");
		private static GUIContent gc_Add2 = new GUIContent("+", "Add a condition.");
		private static GUIContent gc_Rem2 = new GUIContent("-", "Remove last condition.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Branch ac = action as VA_Branch;
			EditorGUIUtility.labelWidth = 70;

			for (int i = 0; i < ac.branches.Length; i++)
			{
				EditorGUILayout.BeginVertical(VinomaEdGUI.FrameFill_Style);
				{
					EditorGUILayout.BeginHorizontal();
					{
						EditorGUILayout.PrefixLabel(gc_Do);
						ac.branches[i].goOpt = (VinomaGotoOption)EditorGUILayout.EnumPopup(ac.branches[i].goOpt);
						if (ac.branches[i].goOpt == VinomaGotoOption.Label)
						{
							ac.branches[i].labelName = EditorGUILayout.TextField(ac.branches[i].labelName);
						}
						else if (ac.branches[i].goOpt == VinomaGotoOption.Scene)
						{
							ac.branches[i].sceneName = EditorGUILayout.TextField(ac.branches[i].sceneName);
							ac.branches[i].labelName = EditorGUILayout.TextField(ac.branches[i].labelName);
						}
					}
					EditorGUILayout.EndHorizontal();

					if (ac.branches[i].conditions.Length == 0)
					{
						EditorGUILayout.BeginHorizontal();
						EditorGUILayout.PrefixLabel(gc_If);
					}
					else
					{
						
						for (int j = 0; j < ac.branches[i].conditions.Length; j++)
						{
							EditorGUILayout.BeginHorizontal();
							if (j == 0) EditorGUILayout.PrefixLabel(gc_If);
							else
							{
								ac.branches[i].conditions[j].combine = (VinomaConditionCombine)EditorGUILayout.EnumPopup(ac.branches[i].conditions[j].combine, GUILayout.Width(EditorGUIUtility.labelWidth - 4));
							}

							ac.branches[i].conditions[j].chectType = (VinomaConditionCheck)EditorGUILayout.EnumPopup(ac.branches[i].conditions[j].chectType, GUILayout.Width(80));
							ac.branches[i].conditions[j].opt1 = EditorGUILayout.TextField(ac.branches[i].conditions[j].opt1);
							if (ac.branches[i].conditions[j].chectType == VinomaConditionCheck.Switch)
							{
								ac.branches[i].conditions[j].swOpt = (VinomaSwitchCondition)EditorGUILayout.EnumPopup(ac.branches[i].conditions[j].swOpt, GUILayout.Width(126));
							}
							else
							{
								ac.branches[i].conditions[j].varOpt = (VinomaVarCondition)EditorGUILayout.Popup((int)ac.branches[i].conditions[j].varOpt, GC_VinomaVarConditions, GUILayout.Width(35));
								ac.branches[i].conditions[j].opt2 = EditorGUILayout.TextField(ac.branches[i].conditions[j].opt2);
							}
							EditorGUILayout.EndHorizontal();
						}

						EditorGUILayout.BeginHorizontal();
					}
					
					
					GUILayout.FlexibleSpace();
					if (GUILayout.Button(gc_Add2, EditorStyles.miniButtonLeft))
					{
						ArrayUtility.Add<VinomaConditionDef>(ref ac.branches[i].conditions, new VinomaConditionDef());
						GUI.changed = true;
					}
					GUI.enabled = ac.branches[i].conditions.Length > 0;
					if (GUILayout.Button(gc_Rem2, EditorStyles.miniButtonRight))
					{
						ArrayUtility.RemoveAt<VinomaConditionDef>(ref ac.branches[i].conditions, ac.branches[i].conditions.Length - 1);
						GUI.changed = true;
					}
					GUI.enabled = true;						
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.EndVertical();
			}

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				if (GUILayout.Button(gc_Add, EditorStyles.miniButtonLeft))
				{
					ArrayUtility.Add<VinomaBranchDef>(ref ac.branches, new VinomaBranchDef());
					ac.branches[ac.branches.Length - 1].conditions = new VinomaConditionDef[0];
					GUI.changed = true;
				}
				GUI.enabled = ac.branches.Length > 0;
				if (GUILayout.Button(gc_Rem, EditorStyles.miniButtonRight))
				{
					ArrayUtility.RemoveAt<VinomaBranchDef>(ref ac.branches, ac.branches.Length - 1);
					GUI.changed = true;
				}
				GUI.enabled = true;
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
