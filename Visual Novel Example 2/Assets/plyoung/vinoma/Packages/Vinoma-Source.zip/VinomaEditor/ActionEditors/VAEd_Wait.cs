﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;
using VinomaEditor;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Effects, "Wait", typeof(VA_Wait), "Wait before executing the next action")]
	public class VAEd_Wait : VinomaActionEd
	{
		private static GUIContent gc_Wait = new GUIContent("Wait Time", "How long to wait, in seconds, before moving on to the next action.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Wait ac = action as VA_Wait;
			EditorGUIUtility.labelWidth = 80;
			ac.opt = (VA_Wait.WaitOption)EditorGUILayout.EnumPopup(ac.opt);
			if (ac.opt == VA_Wait.WaitOption.Seconds)
			{
				ac.waitTime = EditorGUILayout.FloatField("Wait Time", ac.waitTime);
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
