﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Media, "Play Sound", typeof(VA_PlaySound), "Play a sound clip")]
	public class VAEd_PlaySound : VinomaActionEd
	{
		private static GUIContent gc_Clip = new GUIContent("Source", "The sound clip to use as source.");
		private static GUIContent gc_Name = new GUIContent("Name", "An optional name to identify this sound effect by. This is needed if you want to later stop the sound.");
		private static GUIContent gc_Balance = new GUIContent("Balance", "Only valid for Mono and Stereo AudioClips. Mono sounds will be panned at constant power left and right. Stereo sounds will Stereo sounds have each left/right value faded up and down according to the specified pan value.");
		private static GUIContent gc_Loop = new GUIContent("Loop", "Should the sound loop?");
		private static GUIContent[] gc_Labels = { new GUIContent("Left"), new GUIContent("Right") };

		public override void DrawProperties(VinomaAction action)
		{
			VA_PlaySound ac = action as VA_PlaySound;
			EditorGUIUtility.labelWidth = 70;
			EditorGUI.BeginChangeCheck();
			ac.clip = (AudioClip)EditorGUILayout.ObjectField(gc_Clip, ac.clip, typeof(AudioClip), false);
			if (EditorGUI.EndChangeCheck())
			{
				if (ac.clip != null) ac.soundName = ac.clip.name;
				else ac.soundName = "";
			}
			ac.soundName = EditorGUILayout.TextField(gc_Name, ac.soundName);
			ac.balance = EditorGUILayout.Slider(gc_Balance, ac.balance, -1f, +1f);
			plyEdGUI.SliderLabels(GUILayoutUtility.GetLastRect(), gc_Labels[0], gc_Labels[1]);
			EditorGUILayout.Space();
			ac.loop = EditorGUILayout.Toggle(gc_Loop, ac.loop);
			
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
