﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Visual, "Text", typeof(VA_UIText), "Changes text on a UI Text Component")]
	public class VAEd_UIText : VinomaActionEd
	{
		private static GUIContent gc_Target = new GUIContent("Target", "The target object that has a Text component on it.");
		private static GUIContent gc_Text = new GUIContent("Text", "Text to set it to.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_UIText ac = action as VA_UIText;
			EditorGUIUtility.labelWidth = 70;
			ac.target = (GameObject)EditorGUILayout.ObjectField(gc_Target, ac.target, typeof(GameObject), true);
			EditorGUILayout.PrefixLabel(gc_Text);
			ac.text = EditorGUILayout.TextArea(ac.text, EditorStyles.textArea);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
