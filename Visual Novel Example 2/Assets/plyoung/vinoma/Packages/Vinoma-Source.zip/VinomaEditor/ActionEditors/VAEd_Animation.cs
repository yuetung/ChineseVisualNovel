﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;
using VinomaEditor;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Effects, "Animation", typeof(VA_Animation), "Play or Stop an Animation on target object or character. The Target must have an Animator component")]
	public class VAEd_Animation : VinomaActionEd
	{
		private static GUIContent gc_Target = new GUIContent("Target", "The GameObject to Play animation on.");
		private static GUIContent gc_Chara = new GUIContent("Name", "The Character to Play animation on. The character must be present in the scene.");
		private static GUIContent gc_Play = new GUIContent("Play", "Name of Animation State to enter.");
		//private static GUIContent gc_Layer = new GUIContent("Layer", "Layer the Animation State is in.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_Animation ac = action as VA_Animation;
			EditorGUIUtility.labelWidth = 80;

			EditorGUI.BeginChangeCheck();
			ac.opt = (VinomaTargetObject)EditorGUILayout.EnumPopup(ac.opt);
			if (EditorGUI.EndChangeCheck())
			{
				ac.targetObj = null;
				ac.targetChara = null;
			}

			if (ac.opt == VinomaTargetObject.Object)
			{
				ac.targetObj = (GameObject)EditorGUILayout.ObjectField(gc_Target, ac.targetObj, typeof(GameObject), true);
			}
			else if (ac.opt == VinomaTargetObject.Character)
			{
				plyEdGUI.TextSelect(gc_Chara, ac.targetChara, VinomaEdGlobal.GetCharacterNamesUsedInScene, OnNameSelected, ac);
			}

			ac.aniName = EditorGUILayout.TextField(gc_Play, ac.aniName);
			//ac.aniLayer = EditorGUILayout.IntField(gc_Layer, ac.aniLayer);
		}

		private void OnNameSelected(string s, object obj)
		{
			VA_Animation ac = obj as VA_Animation;
			if (ac != null)
			{
				ac.targetChara = s;
				GUI.changed = true;
			}
		}


		// ------------------------------------------------------------------------------------------------------------
	}
}
