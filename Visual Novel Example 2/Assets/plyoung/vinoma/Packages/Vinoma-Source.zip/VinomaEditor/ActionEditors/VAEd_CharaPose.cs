﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Characters, "Change Pose", typeof(VA_CharaPose), "Change the pose of a character in the scene")]
	public class VAEd_CharaPose : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "The name of the character that should change its pose. Can only be applied to a character that are present in the scene.");
		private static GUIContent gc_Pose = new GUIContent("Pose", "The new pose that the character should use.");
		private static GUIContent gc_Fade = new GUIContent("Fade", "The fade-in time in seconds. If used then the old pose will fade-out with the same settings. Set to 0 to disable.");
		private static GUIContent gc_Wait = new GUIContent("Wait", "Wait for the fade-in to complete before moving on to the next action?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_CharaPose ac = action as VA_CharaPose;
			ReadFab(ac);

			EditorGUILayout.BeginHorizontal();
			{
				//Rect r = GUILayoutUtility.GetRect(150, 180, GUILayout.Width(150), GUILayout.Height(180));
				//Rect r = GUILayoutUtility.GetRect(300, 300, GUILayout.Width(300), GUILayout.Height(300));
				Rect r = GUILayoutUtility.GetRect(150, 150, GUILayout.Width(150), GUILayout.Height(150));
				GUI.Box(r, GUIContent.none, VinomaEdGUI.FrameFill_Style);
				VinomaEdUtil.DrawImages(ac._spriteCache, r, false, 3f);

				EditorGUILayout.BeginVertical();
				{
					EditorGUIUtility.labelWidth = 70;
					plyEdGUI.TextSelect(gc_Name, ac.characterName, VinomaEdGlobal.GetCharacterNamesUsedInScene, OnNameSelected, ac);
					if (ac._characterFab != null)
					{
						EditorGUI.BeginChangeCheck();
						ac._poseIdx = EditorGUILayout.Popup(gc_Pose, ac._poseIdx, ac._poseNames);
						if (EditorGUI.EndChangeCheck())
						{
							ac.poseName = ac._poseIdx < 0 ? "" : ac._poseNames[ac._poseIdx].text;
							UpdateSpriteCache(ac);
						}
						ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
						ac.waitComplete = EditorGUILayout.Toggle(gc_Wait, ac.waitComplete);
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		private void OnNameSelected(string s, object obj)
		{
			VA_CharaPose ac = obj as VA_CharaPose;
			if (ac != null)
			{				
				ac.characterName = s;
				ac._characterFab = null;
				ac._poseIdx = -1;
				ac._spriteCache = null;
				ac._poseNames = null;
				ReadFab(ac);
				GUI.changed = true;
				//EditorUtility.SetDirty(VinomaEdGlobal.asset);
			}
		}

		private void ReadFab(VA_CharaPose ac)
		{
			if (!string.IsNullOrEmpty(ac.characterName))
			{
				ac._characterFab = VinomaEdGlobal.GetPrefabForCharacterInScene(ac.characterName);
				if (ac._characterFab == null)
				{
					ac._poseNames = null;

					//Debug.Log("Could not find: " + ac.characterName);
					//ac.characterName = null;
					//GUI.changed = true;
				}
			}

			if (ac._poseNames != null || ac._characterFab == null) return;

			ac._poseIdx = -1;
			ac._poseNames = new GUIContent[ac._characterFab.transform.childCount];
			for (int i = 0; i < ac._characterFab.transform.childCount; i++)
			{
				ac._poseNames[i] = new GUIContent(ac._characterFab.transform.GetChild(i).name);
				if (string.IsNullOrEmpty(ac.poseName))
				{
					ac._poseIdx = i;
					ac.poseName = ac._poseNames[i].text;
					GUI.changed = true;
				}
				else if (ac._poseIdx < 0 && ac._poseNames[i].text.Equals(ac.poseName))
				{
					ac._poseIdx = i;
				}
			}

			if (ac._spriteCache == null)
			{
				UpdateSpriteCache(ac);
			}
		}

		private void UpdateSpriteCache(VA_CharaPose ac)
		{
			ac._spriteCache = new List<_SpriteCacheEntry>();

			SpriteRenderer ren = ac._characterFab.GetComponent<SpriteRenderer>();
			if (ren != null)
			{
				ac._spriteCache.Add(new _SpriteCacheEntry() { sprite = ren.sprite, offs = Vector2.zero, size = Vector2.one });
			}

			if (ac._poseIdx >= 0)
			{
				VinomaEdUtil.ReadChildSprites(ac._spriteCache, ac._characterFab.transform.GetChild(ac._poseIdx), Vector2.zero, Vector2.one);
			}
		}

		// ------------------------------------------------------------------------------------------------------------


		// ------------------------------------------------------------------------------------------------------------
	}
}
