﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Media, "Stop Music", typeof(VA_StopMusic), "Stop any playing music")]
	public class VAEd_StopMusic : VinomaActionEd
	{
		private static GUIContent gc_Fade = new GUIContent("Fade", "The fade-out time in seconds. Set to 0 to disable.");

		public override void DrawProperties(VinomaAction action)
		{
			VA_StopMusic ac = action as VA_StopMusic;
			EditorGUIUtility.labelWidth = 70;
			ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
