﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Media, "Start Music", typeof(VA_StartMusic), "Stop any playing music and start playing a new music clip")]
	public class VAEd_StartMusic : VinomaActionEd
	{
		private static GUIContent gc_Clip = new GUIContent("Source", "The sound clip to use as source.");
		private static GUIContent gc_Fade = new GUIContent("Fade", "The cross-fade time in seconds. Set to 0 to disable.");
		private static GUIContent gc_Loop = new GUIContent("Loop", "Should the music loop?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_StartMusic ac = action as VA_StartMusic;
			EditorGUIUtility.labelWidth = 70;
			ac.clip = (AudioClip)EditorGUILayout.ObjectField(gc_Clip, ac.clip, typeof(AudioClip), false);
			ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
			ac.loop = EditorGUILayout.Toggle(gc_Loop, ac.loop);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
