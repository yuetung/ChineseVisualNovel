﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Characters, "Enter Scene", typeof(VA_CharaEnter), "Add a character to the scene")]
	public class VAEd_CharaEnter : VinomaActionEd
	{
		private static GUIContent gc_Source = new GUIContent("Source", "The sprite to use.");
		private static GUIContent gc_Name = new GUIContent("Name", "The name to give this character. Defaults to sprite name.");
		private static GUIContent gc_Pose = new GUIContent("Pose", "The character's initial pose.");
		private static GUIContent gc_Sort = new GUIContent("Sort", "Show the character in front or behind other characters?");
		private static GUIContent gc_Order = new GUIContent("Order", "The custom sort order to use.");
		private static GUIContent gc_Enter = new GUIContent("Enter", "From which side of the screen should the character enter the scene. In-place means the character starts at the specified Location.");
		private static GUIContent gc_Move = new GUIContent("Move", "How long the enter movement should take in seconds when Enter is not set to In-Place. Will not have an effect if set to 0.");
		private static GUIContent gc_Fade = new GUIContent("Fade", "How long the fade-in should take in seconds. Set to 0 to disable.");
		private static GUIContent gc_Location = new GUIContent("Location", "The location that the character should end up at in the scene. Other character will be moved if they are in the way.");
		private static GUIContent gc_Offet = new GUIContent("Offset", "Normally used to control the character's up/ down position in the scene but can also be sued to adjust the final left/ right position.");
		private static GUIContent gc_Mirror = new GUIContent("Mirror", "Used to flip the character around.");
		private static GUIContent gc_Wait = new GUIContent("Wait", "Wait for the fade-in (or move, whichever takes longer) to complete before moving on to the next action?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_CharaEnter ac = action as VA_CharaEnter;
			ReadFab(ac);

			EditorGUILayout.BeginHorizontal();
			{
				//Rect r = GUILayoutUtility.GetRect(400, 400, GUILayout.Width(400), GUILayout.Height(400));
				Rect r = GUILayoutUtility.GetRect(150, 180, GUILayout.Width(150), GUILayout.Height(180));
				GUI.Box(r, GUIContent.none, VinomaEdGUI.FrameFill_Style);
				VinomaEdUtil.DrawImages(ac._spriteCache, r, ac.mirror);

				EditorGUILayout.BeginVertical();
				{
					EditorGUIUtility.labelWidth = 70;
					EditorGUI.BeginChangeCheck();
					ac.characterFab = (GameObject)EditorGUILayout.ObjectField(gc_Source, ac.characterFab, typeof(GameObject), false);
					if (EditorGUI.EndChangeCheck())
					{
						ac.characterName = null;
						ac.poseName = null;
						ac._poseIdx = -1;
						ac._spriteCache = null;
						ac._poseNames = null;
						ReadFab(ac);
					}

					if (ac.characterFab != null)
					{
						if (string.IsNullOrEmpty(ac.characterName))
						{
							ac.characterName = ac.characterFab.name;
							GUI.changed = true;
						}
						ac.characterName = EditorGUILayout.TextField(gc_Name, ac.characterName);
						EditorGUI.BeginChangeCheck();
						ac._poseIdx = EditorGUILayout.Popup(gc_Pose, ac._poseIdx, ac._poseNames);
						if (EditorGUI.EndChangeCheck())
						{
							ac.poseName = ac._poseIdx < 0 ? "" : ac._poseNames[ac._poseIdx].text;
							UpdateSpriteCache(ac);
						}
						ac.sortOrder = (VinomaSceneSortOrder)EditorGUILayout.EnumPopup(gc_Sort, ac.sortOrder);
						if (ac.sortOrder == VinomaSceneSortOrder.Custom)
						{
							ac.customSortOrder = EditorGUILayout.IntField(gc_Order, ac.customSortOrder);
						}
						ac.enterFrom = (VinomaSceneSide)EditorGUILayout.EnumPopup(gc_Enter, ac.enterFrom);
						if (ac.enterFrom != VinomaSceneSide.InPlace)
						{
							ac.moveEasing = VinomaEdGUI.EasingField(gc_Move, ac.moveEasing);
						}
						ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
						if (ac.sceneLocation != VinomaSceneLocation.Custom)
						{
							EditorGUI.BeginChangeCheck();
							ac.sceneLocation = (VinomaSceneLocation)EditorGUILayout.EnumPopup(gc_Location, ac.sceneLocation);
							if (EditorGUI.EndChangeCheck() && ac.sceneLocation == VinomaSceneLocation.Custom) ac.customLocation.isUsed = true;
						}
						else
						{
							EditorGUI.BeginChangeCheck();
							ac.customLocation = plyEdGUI.Vector2OptionalField(gc_Location, ac.customLocation);
							if (EditorGUI.EndChangeCheck() && ac.customLocation.isUsed == false) ac.sceneLocation = VinomaSceneLocation.Middle;
						}
						ac.offset = plyEdGUI.Vector2OptionalField(gc_Offet, ac.offset);
						EditorGUILayout.BeginHorizontal();
						{
							ac.mirror = EditorGUILayout.Toggle(gc_Mirror, ac.mirror);
							ac.waitComplete = EditorGUILayout.Toggle(gc_Wait, ac.waitComplete);
						}
						EditorGUILayout.EndHorizontal();
					}

				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		private void ReadFab(VA_CharaEnter ac)
		{
			if (ac._poseNames != null || ac.characterFab == null) return;

			if (!ac.offset.isUsed)
			{	// give it a default value that the user can later change but only if 
				// offset is not yet being used (was not yet manually edited)
				ac.offset.value = ac.characterFab.transform.position;
			}

			ac._poseIdx = -1;
			ac._poseNames = new GUIContent[ac.characterFab.transform.childCount];
			for (int i = 0; i < ac.characterFab.transform.childCount; i++)
			{
				ac._poseNames[i] = new GUIContent(ac.characterFab.transform.GetChild(i).name);
				if (string.IsNullOrEmpty(ac.poseName))
				{
					ac._poseIdx = i;
					ac.poseName = ac._poseNames[i].text;
					GUI.changed = true;
				}
				else if (ac._poseIdx < 0 && ac._poseNames[i].text.Equals(ac.poseName))
				{
					ac._poseIdx = i;
				}
			}

			if (ac._spriteCache == null)
			{
				UpdateSpriteCache(ac);
			}
		}

		private void UpdateSpriteCache(VA_CharaEnter ac)
		{
			ac._spriteCache = new List<_SpriteCacheEntry>();

			SpriteRenderer ren = ac.characterFab.GetComponent<SpriteRenderer>();
			if (ren != null)
			{
				ac._spriteCache.Add(new _SpriteCacheEntry() { sprite = ren.sprite, offs = Vector2.zero, size = Vector2.one });
			}

			if (ac._poseIdx >= 0)
			{
				VinomaEdUtil.ReadChildSprites(ac._spriteCache, ac.characterFab.transform.GetChild(ac._poseIdx), Vector2.zero, Vector2.one);
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
