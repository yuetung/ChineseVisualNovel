﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Visual, "Panel", typeof(VA_UIPanel), "Show or hide a GUI panel")]
	public class VAEd_UIPanel : VinomaActionEd
	{
		private static GUIContent gc_Name = new GUIContent("Name", "Panel name.");
		private static GUIContent gc_Option = new GUIContent("Option", "Show or hide panel.");
		private static GUIContent gc_Additive= new GUIContent("Additive", "Show the panel without hiding other panels?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_UIPanel ac = action as VA_UIPanel;
			EditorGUIUtility.labelWidth = 70;
			ac.viewOpt = (VinomaViewOption)EditorGUILayout.EnumPopup(ac.viewOpt);
			ac.panelName = EditorGUILayout.TextField(gc_Name, ac.panelName);
			if (ac.viewOpt == VinomaViewOption.Show)
			{
				ac.additive = EditorGUILayout.Toggle(gc_Additive, ac.additive);
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
