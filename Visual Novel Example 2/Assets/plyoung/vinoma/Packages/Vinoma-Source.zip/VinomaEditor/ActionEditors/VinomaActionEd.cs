﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public class VinomaActionEd
	{
		public virtual void DrawProperties(VinomaAction action)
		{
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
