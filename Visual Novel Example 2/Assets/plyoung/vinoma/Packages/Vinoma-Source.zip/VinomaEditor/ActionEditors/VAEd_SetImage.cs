﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	[VinomaActionEd(VinomaActionGroup.Visual, "Image", typeof(VA_SetImage), "Changes the Sprite of an Object that has a SpriteRenderer or Image component")]
	public class VAEd_SetImage : VinomaActionEd
	{
		private static GUIContent gc_Target = new GUIContent("Target", "The target GameObjects that has an Image or SpriteRenderer component on it.");
		private static GUIContent gc_Sprite = new GUIContent("Sprite", "Sprite to set use. Set to none to remove any current sprite from the target.");
		private static GUIContent gc_Fade = new GUIContent("Fade", "How long the fade-in (or fade-out if removing sprite) should take in seconds. Set to 0 to disable.");
		private static GUIContent gc_Wait = new GUIContent("Wait", "Wait for the fade to complete before moving on to the next action?");

		public override void DrawProperties(VinomaAction action)
		{
			VA_SetImage ac = action as VA_SetImage;
			EditorGUIUtility.labelWidth = 70;
			ac.target = (GameObject)EditorGUILayout.ObjectField(gc_Target, ac.target, typeof(GameObject), true);
			ac.sp = (Sprite)EditorGUILayout.ObjectField(gc_Sprite, ac.sp, typeof(Sprite), false);
			ac.fadeEasing = VinomaEdGUI.EasingField(gc_Fade, ac.fadeEasing);
			ac.waitComplete = EditorGUILayout.Toggle(gc_Wait, ac.waitComplete);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
