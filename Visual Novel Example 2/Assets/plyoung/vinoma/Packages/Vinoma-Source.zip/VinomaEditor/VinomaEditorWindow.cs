﻿
using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using plyCommon2;
using plyCommon2Editor;
using VinomaEngine;

namespace VinomaEditor
{
	public class VinomaEditorWindow : EditorWindow
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		private const float BLOCK_DRAG_SENSE = 120f;

		private static readonly GUIContent GC_AddScene = new GUIContent(Ico._add, "Add Vinoma scene");
		private static readonly GUIContent GC_DuplicateScene = new GUIContent(Ico._duplicate, "Duplicate currently open Vinoma scene into a new scene");
		private static readonly GUIContent GC_RemoveScene = new GUIContent(Ico._remove, "Remove Vinoma scene");
		private static readonly GUIContent GC_RenameScene = new GUIContent(Ico._edit, "Rename Vinoma scene");
		private static readonly GUIContent GC_ToggleCollapse = new GUIContent(Ico._select_arrows, "Toggle all Actions collapse state");
		private static readonly GUIContent GC_PlayScene = new GUIContent(Ico._play + " Test the Scene", "Play test this Scene");
		private static readonly GUIContent GC_Settings = new GUIContent(Ico._settings, "Vinoma and game settings");
		private static readonly GUIContent GC_OpenScene = new GUIContent(Ico._folder, "Open the Main Vinoma Unity Scene");
		private static readonly GUIContent GC_RemoveAtion = new GUIContent(Ico._cancel, "Remove Action");
		private static readonly GUIContent GC_ToggleAtionOff = new GUIContent(Ico._radio_button_on, "Toggle Action off");
		private static readonly GUIContent GC_ToggleAtionOn = new GUIContent(Ico._radio_button_off, "Toggle Action on");
		private static readonly GUIContent GC_SceneUp = new GUIContent(Ico._arrow_up, "Move Vinoma scene up in list of scenes");
		private static readonly GUIContent GC_SceneDown = new GUIContent(Ico._arrow_down, "Move Vinoma scene down in list of scenes");

		public class VinomaActionNfo
		{
			public VinomaActionEdAttribute att;
			public VinomaActionEd ed;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public static List<VinomaActionNfo> actions = null;		
		public static VinomaEditorWindow Instance;
		public VinomaScene currScene = null;

		private int _currSceneIdx = -1;
		private int currSceneIdx 
		{ 
			get { return _currSceneIdx; } 
			set 
			{
				if (VinomaEdGlobal.asset == null)
				{
					LoadAsset(true);
					 _currSceneIdx = - 1;
				}

				if (VinomaEdGlobal.asset != null)
				{
					_currSceneIdx = value;
					currScene = _currSceneIdx < 0 ? null : VinomaEdGlobal.asset.scenes[_currSceneIdx];
				}
				else
				{
					_currSceneIdx = -1;
					currScene = null;
				}

				GC_SceneSelect.text = _currSceneIdx >= 0 ? VinomaEdGlobal.asset.scenes[_currSceneIdx].name : "Scene";
			} 
		}

		private bool doRepaint = false;
		private Vector2[] scroll = { Vector2.zero, Vector2.zero };
		//private int activeLeftPanel = 0;
		private GUIContent[] GC_ScenesPopup = new GUIContent[0];
		private bool[] actionGroupFolds = new bool[0];
		private static GUIContent GC_Action = new GUIContent();
		private GUIContent GC_DragDropLabel = new GUIContent();
		private VinomaActionNfo dragDrop = null;
		private VinomaAction dragDropInsertContext = null;
		private VinomaAction dragDropInsertContext_change = null;
		private VinomaAction dragDropBlock = null;
		private VinomaAction dragDropBlockOldContext = null;
		private VinomaAction actionDragStartedOn = null;
		private System.Diagnostics.Stopwatch dragTimer;
		private bool unlinkDragDropBlock = false;
		private Rect mainRectArea;
		private bool allCollapsed = true;
		private VinomaSceneController sceneController;
		private int lastTrackedScene = -1;
		public Sprite sp;
		private SceneListPopup sceneList = new SceneListPopup();
		private GUIContent GC_SceneSelect = new GUIContent("Scene");

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		public static void Show_VinomaEditor()
		{
			EditorWindow.GetWindow<VinomaEditorWindow>("Vinoma");
		}

		protected void OnEnable()
		{
			Instance = this;
			UpdateWindowIcon();

			actionGroupFolds = new bool[(int)VinomaActionGroup.MAX];
			for (int i = 0; i < (int)VinomaActionGroup.MAX; i++) actionGroupFolds[i] = 1 == EditorPrefs.GetInt("VinomaEd.ActionGroupFold."+i, 1);
		}

		protected void OnDestroy()
		{
		}

		protected void OnFocus()
		{
			Instance = this;
			//UpdateWindowIcon();
			wantsMouseMove = true;
			VinomaActionsWindow.Show_VinomaActions();
		}

		protected void OnLostFocus()
		{
			wantsMouseMove = false;
		}

		private void UpdateWindowIcon()
		{
#if !UNITY_4
			if (VinomaEdGUI.Texture_WinIcon == null) VinomaEdGUI.Texture_WinIcon = plyEdGUI.LoadTextureResource("VinomaEditor.edRes.ico_vinoma" + (EditorGUIUtility.isProSkin ? "_pro" : "") + ".png", typeof(VinomaEditorWindow).Assembly);
			//plyEdUtil.SetWindowTitle(this, VinomaEdGUI.Texture_WinIcon, "Vinoma");
			titleContent = new GUIContent("Vinoma", VinomaEdGUI.Texture_WinIcon);
#endif
		}

		public static void Reflect()
		{
			if (actions != null) return;
			//if (EditorApplication.isPlayingOrWillChangePlaymode) return;

			Assembly[] asms = System.AppDomain.CurrentDomain.GetAssemblies();
			List<System.Type> foundEffects = new List<System.Type>();
			List<System.Type> foundEditors = new List<System.Type>();

			// Find Actions and Action Editors
			for (int i = 0; i < asms.Length; i++)
			{
				try
				{
					System.Type[] types = asms[i].GetExportedTypes();
					for (int j = 0; j < types.Length; j++)
					{
						if (types[j].IsClass && typeof(VinomaAction).IsAssignableFrom(types[j]) && types[j].Name != "VinomaAction") foundEffects.Add(types[j]);
						if (types[j].IsClass && typeof(VinomaActionEd).IsAssignableFrom(types[j]) && types[j].Name != "VinomaActionEd") foundEditors.Add(types[j]);
					}
				}
				catch (System.NotSupportedException) { continue; } // dynamic modules will cause this
			}

			// Instantiate Editors
			actions = new List<VinomaActionNfo>();
			foreach (System.Type effectType in foundEffects)
			{
				foreach (System.Type edType in foundEditors)
				{
					object[] attribs = edType.GetCustomAttributes(typeof(VinomaActionEdAttribute), false);
					if (attribs.Length > 0)
					{
						VinomaActionEdAttribute att = (VinomaActionEdAttribute)attribs[0];
						if (att.Target == effectType)
						{
							VinomaActionNfo nfo = new VinomaActionNfo();
							nfo.att = att;
							nfo.ed = (VinomaActionEd)System.Activator.CreateInstance(edType);
							actions.Add(nfo);
							break;
						}
					}
				}				
			}

			// sort
			actions = actions.OrderBy(a => a.att.Group).OrderBy(a => a.att.Name).ToList();
		}

		private void LoadAsset(bool force)
		{
			Reflect();
			VinomaEdGlobal.LoadAsset(force);

			if (VinomaEdGlobal.asset != null)
			{
				// create a default scene if none found
				if (VinomaEdGlobal.asset.scenes == null || VinomaEdGlobal.asset.scenes.Length == 0)
				{
					CreateScene("Scene 1");
				}
				else
				{
					RefreshScenesPopup();
				}

				// make 1st scene active
				if (currSceneIdx < 0 || currSceneIdx >= VinomaEdGlobal.asset.scenes.Length)
				{
					currSceneIdx = 0;
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region gui and system events

		protected void OnInspectorUpdate()
		{
			if (doRepaint)
			{
				doRepaint = false;
				Repaint();
			}

			else if (EditorApplication.isPlaying)
			{
				// force continues repaints so the Vinoma editor shows correct state of game
				Repaint();
			}
		}

		protected void OnGUI()
		{
			if (EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isPlaying)
			{	//do not render while in transition from/to play mode
				return;
			}

			LoadAsset(false);
			VinomaEdGUI.UseSkin();

			if (EditorApplication.isPlayingOrWillChangePlaymode && Event.current.type == EventType.Repaint)
			{
				// this help prevent some layout problems when the scene is changed during play test mode
				if (lastTrackedScene != currSceneIdx)
				{
					lastTrackedScene = currSceneIdx;
					GUIUtility.ExitGUI();
					return;
				}
			}

			if (currScene == null && currSceneIdx >= 0)
			{   // became null for some reason.. refresh
				currSceneIdx = _currSceneIdx; // simply setting the sceneIdx again will set currScene reference
			}

			MainPanel();

			if (VinomaEdGlobal.asset == null)
			{
				return;
			}

			HandleEvents();
		}

		private void HandleEvents()
		{
			if (EditorApplication.isPlayingOrWillChangePlaymode)
			{
				return;
			}

			switch (Event.current.type)
			{
				case EventType.MouseDown:
				{
				} break;

				case EventType.MouseUp:
				{
				} break;

				case EventType.MouseDrag:
				{
				} break;

				case EventType.DragExited:
				{
					if (dragDropBlock != null)
					{	// restore the dragDropBlock to its old position
						dragDropInsertContext = dragDropBlockOldContext;
						AddActionToScene();
					}

					dragDrop = null;
					dragDropBlock = null;
					dragDropInsertContext = null;
					dragDropInsertContext_change = null;
					dragDropBlockOldContext = null;
					Event.current.Use();
				} break;

				case EventType.DragPerform:
				{
					if (dragDrop != null)
					{
						DragAndDrop.AcceptDrag();
						plyEdGUI.ClearFocus();
						Event.current.Use();
						AddActionToScene();
					}
				} break;

				case EventType.DragUpdated:
				{
					dragDrop = DragAndDrop.GetGenericData("VinomaActionNfo") as VinomaActionNfo;
					if (dragDrop != null)
					{
						if (mainRectArea.Contains(Event.current.mousePosition))
						{
							GC_DragDropLabel.text = dragDrop.att.Name;

							// must update visual mode else DragPerform event will not trigger
							DragAndDrop.visualMode = DragAndDropVisualMode.Move;
							Event.current.Use();
							break;
							
						}
					}
					
					DragAndDrop.visualMode = DragAndDropVisualMode.Rejected;
					dragDrop = null;

				} break;

				case EventType.Repaint:
				{
					if (dragDropInsertContext != null)
					{	// the drag drop marker will drawn "snap-in" style in other part of code
						break;
					}

					if (dragDrop == null || DragAndDrop.visualMode == DragAndDropVisualMode.None || DragAndDrop.visualMode == DragAndDropVisualMode.Rejected)
					{	// no drag drop activity
						break;
					}
					else
					{
						// draw the action being dragged
						DrawActionLabel(dragDrop, new Rect(Event.current.mousePosition.x -15, Event.current.mousePosition.y -15, 0, 0));
					}

				} break;
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region main panel
		
		private void MainPanel()
		{
			if (Event.current.type == EventType.Repaint)
			{
				dragDropInsertContext_change = null;
			}

			if (Event.current.button == 0 && (Event.current.type == EventType.MouseDown || Event.current.type == EventType.MouseUp))
			{
				actionDragStartedOn = null;
				if (dragTimer != null) dragTimer.Stop();
			}

			// ----------

			EditorGUILayout.BeginVertical(VinomaEdGUI.MainPanelBack_Style);
			{
				Rect r;
				MainPanelToolbar();

				if (VinomaEdGlobal.asset == null)
				{
					ShowNotification(new GUIContent("The Vinoma main scene must be open before actions can be edited."));
					EditorGUILayout.EndVertical();
					GUILayout.FlexibleSpace();
					return;
				}

				mainRectArea = EditorGUILayout.BeginVertical(VinomaEdGUI.MainPanelContent_Style, GUILayout.ExpandHeight(true), GUILayout.ExpandWidth(true));
				{
					mainRectArea.width -= GUI.skin.verticalScrollbar.CalcSize(GUIContent.none).x;
					GUI.DrawTexture(new Rect(mainRectArea.xMax - 145, mainRectArea.yMax - 140, 128, 128), VinomaEdGUI.Texture_VinomaIcon);

					r = mainRectArea;
					r.x += 39; r.width = 2;
					GUI.DrawTextureWithTexCoords(r, VinomaEdGUI.Texture_Timeline, new Rect(0, 0, r.width / VinomaEdGUI.Texture_Timeline.width, r.height / VinomaEdGUI.Texture_Timeline.height));

					scroll[1] = EditorGUILayout.BeginScrollView(scroll[1], false, true, GUIStyle.none, GUI.skin.verticalScrollbar, GUI.skin.scrollView);
					{
						GUILayout.Space(20);
						DrawLinkedActions();
						GUILayout.Space(150);
						GUILayout.FlexibleSpace();

						r = GUILayoutUtility.GetLastRect();
						float h = r.yMax;
						r.x += 15; r.y -= 130; r.height += 150;
						r.width = 10; r.height = 10;
						while (r.y < h)
						{
							GUI.DrawTexture(r, VinomaEdGUI.Texture_TimelineDot);
							r.y += 40;
						}
					}
					EditorGUILayout.EndScrollView();
				}
				EditorGUILayout.EndVertical();

				GUI.Box(mainRectArea, GUIContent.none, plyEdGUI.Style_InnerShadow);
			}
			EditorGUILayout.EndVertical();

			// ----------

			// detect Block dragging
			if (Event.current.type == EventType.MouseDrag && actionDragStartedOn != null)
			{
				if (dragTimer.ElapsedMilliseconds > BLOCK_DRAG_SENSE)
				{
					dragTimer.Stop();
					dragDropBlock = actionDragStartedOn;
					unlinkDragDropBlock = true;
					DragAndDrop.PrepareStartDrag();
					DragAndDrop.objectReferences = new UnityEngine.Object[0];
					DragAndDrop.paths = null;
					DragAndDrop.SetGenericData("VinomaActionNfo", GetActionNfo(dragDropBlock));
					DragAndDrop.StartDrag(dragDropBlock.name);
					Event.current.Use();
					actionDragStartedOn = null;
				}
			}

			if (Event.current.type == EventType.Repaint)
			{
				if (unlinkDragDropBlock)
				{
					UnlinkActionForDragDrop();
				}

				dragDropInsertContext = dragDropInsertContext_change;
			}
		}

		private void MainPanelToolbar()
		{
			EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
			{
				GUI.enabled = VinomaEdGlobal.asset != null && !EditorApplication.isPlayingOrWillChangePlaymode;
				if (GUILayout.Button(GC_Settings, plyEdGUI.Style_ToolbarIcoButton))
				{
					VinomaSettingsWindow.Show_VinomaSettingsWindow();
				}
				GUI.enabled = !EditorApplication.isPlayingOrWillChangePlaymode;
				if (GUILayout.Button(GC_OpenScene, plyEdGUI.Style_ToolbarIcoButton))
				{
					RemoveNotification();
					LoadAsset(true);
					doRepaint = true;
					GUIUtility.ExitGUI();
					return;
				}
				GUI.enabled = VinomaEdGlobal.asset != null && !EditorApplication.isPlayingOrWillChangePlaymode;
				EditorGUILayout.Space();

				//currSceneIdx = EditorGUILayout.Popup(currSceneIdx, GC_ScenesPopup, EditorStyles.toolbarPopup);
				if (GUILayout.Button(GC_SceneSelect, EditorStyles.toolbarPopup, GUILayout.MinWidth(100)))
				{
					sceneList.labels = GC_ScenesPopup;
					sceneList.onSelected = OnSceneSelected;
					sceneList.currIdx = currSceneIdx;
					PopupWindow.Show(GUILayoutUtility.GetLastRect(), sceneList);
				}

				if (GUILayout.Button(GC_AddScene, plyEdGUI.Style_ToolbarIcoButton))
				{
					plyTextInputWiz.ShowWiz("Add Scene", "Enter a unique name", "Scene " + (VinomaEdGlobal.asset.scenes.Length + 1), OnCreateScene, null);
				}
				if (GUILayout.Button(GC_DuplicateScene, plyEdGUI.Style_ToolbarIcoButton))
				{
					plyTextInputWiz.ShowWiz("Duplicate Scene", "Enter a unique name", "Scene " + (VinomaEdGlobal.asset.scenes.Length + 1), OnDuplicateScene, null);
				}
				if (GUILayout.Button(GC_RemoveScene, plyEdGUI.Style_ToolbarIcoButton))
				{
					if (EditorUtility.DisplayDialog("Remove Scene", "Removing the Scene can't be undone. Are you sure?", "Yes", "Cancel"))
					{
						RemoveScene();
					}
				}

				if (GUILayout.Button(GC_SceneUp, plyEdGUI.Style_ToolbarIcoButton))
				{
					MoveScene(true);
				}
				if (GUILayout.Button(GC_SceneDown, plyEdGUI.Style_ToolbarIcoButton))
				{
					MoveScene(false);
				}

				if (GUILayout.Button(GC_RenameScene, plyEdGUI.Style_ToolbarIcoButton))
				{
					plyTextInputWiz.ShowWiz("Rename Scene", "Enter a unique name", currScene.name, OnRenameScene, null);
				}
				GUILayout.Space(5);
				GUI.enabled = VinomaEdGlobal.asset != null;
				if (GUILayout.Button(GC_ToggleCollapse, plyEdGUI.Style_ToolbarIcoButton))
				{
					allCollapsed = !allCollapsed;
					SetAllActionsCollapseState(allCollapsed);
				}
				GUI.enabled = VinomaEdGlobal.asset != null && !EditorApplication.isPlayingOrWillChangePlaymode;
				GUILayout.Space(20);
				if (GUILayout.Button(GC_PlayScene, plyEdGUI.Style_ToolbarIcoButton))
				{
					VinomaEdGlobal.PlayTestScene(currSceneIdx);
					GUIUtility.ExitGUI();
					return;
				}
				GUILayout.FlexibleSpace();
				GUI.enabled = true;
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DrawLinkedActions()
		{
			// show notification if no actions in scene
			if (currScene == null || currScene.firstAction == null)
			{
				GUILayout.Label("Drag-and-Drop an Action here\nto start editing this Scene.", VinomaEdGUI.Notification_Style);
				return;
			}

			VinomaAction action = currScene.firstAction;
			while (action != null)
			{
				if (DrawAction(action)) break;
				action = action.next;
			}

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(currScene);
				plyEdUtil.MarkSceneDirty();
			}
		}

		private void OnSceneSelected(int idx)
		{
			currSceneIdx = idx;
			plyEdGUI.ClearFocus();
			Repaint();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region action drawer

		private void DrawActionLabel(VinomaActionNfo nfo, Rect pos)
		{
			pos.width = 200; pos.height = 36;
			VinomaEdGUI.Action_Style[(int)nfo.att.Group].Draw(pos, GC_DragDropLabel, false, false, false, false);
			pos.width = 20; pos.height = 20; pos.x += 7; pos.y += 7;
			GUI.DrawTexture(pos, VinomaEdGUI.ActionIcon(dragDrop.att.Name));
		}

		public static Rect DrawActionLabel(VinomaActionNfo nfo, bool showToolTip = false)
		{
			GC_Action.text = nfo.att.Name;
			GC_Action.tooltip = showToolTip ? nfo.att.Tooltip : null;
			GUILayout.Label(GC_Action, VinomaEdGUI.Action_Style[(int)nfo.att.Group], GUILayout.Width(200), GUILayout.Height(36));
			Rect r = GUILayoutUtility.GetLastRect();
			Rect rr = r;
			rr.width = 20; rr.height = 20; rr.x += 7; rr.y += 7;
			GUI.DrawTexture(rr, VinomaEdGUI.ActionIcon(nfo.att.Name));

			return r;
		}

		private bool DrawAction(VinomaAction action)
		{
			VinomaActionNfo nfo = GetActionNfo(action);
			if (nfo == null)
			{
				GUILayout.Label("ERROR: ACTION INFO NOT FOUND. THIS SHOULD NOT HAPPEN.");
				return true;
			}

			Rect r, rr;

			// allocate space for drag-and-drop snap-in
			if (dragDropInsertContext == action)
			{
				r = GUILayoutUtility.GetRect(200, 36);
				if (Event.current.type == EventType.Repaint && r.Contains(Event.current.mousePosition))
				{
					dragDropInsertContext_change = action;
					DrawActionLabel(dragDrop, r);
				}
			}

			// draw action
			if (!action.active)
			{
				GUI.color = new Color(0.6f, 0.6f, 0.6f, 1f);
				GUI.backgroundColor = new Color(0.65f, 0.65f, 0.65f, 1f);
			}

			GUILayout.Space(3);
			r = rr = DrawActionLabel(nfo);
			rr.x = rr.xMax - 25; rr.y += 3; rr.width = 20; rr.height = 20;
			if (GUI.Button(rr, action._expanded ? Ico._arrow_down : Ico._arrow_up, VinomaEdGUI.ActionCollapseButton_Style)) { action._expanded = !action._expanded; GUI.changed = true; }
			GUI.color = GUI.backgroundColor = Color.white;

			if (action._expanded)
			{
				GUI.enabled = !EditorApplication.isPlayingOrWillChangePlaymode;
				rr = EditorGUILayout.BeginVertical(VinomaEdGUI.ActionPropertiesContainer_Style, GUILayout.Width(VinomaEdGUI.PropertyPanelWidth), GUILayout.MaxWidth(VinomaEdGUI.PropertyPanelWidth), GUILayout.ExpandWidth(false));
				{
					rr.x = rr.xMax - 17; rr.y += 1; rr.width = 20; rr.height = 20;
					if (GUI.Button(rr, GC_RemoveAtion, VinomaEdGUI.ActionRemoveButton_Style))
					{
						RemoveAction(action);
						GUIUtility.ExitGUI();
						return true;
					}

					rr.x -= 25;
					if (GUI.Button(rr, action.active ? GC_ToggleAtionOff : GC_ToggleAtionOn, VinomaEdGUI.ActionActiveButton_Style))
					{
						action.active = !action.active;
						GUI.changed = true;
					}

					if (!action.active)
					{
						GUI.color = new Color(1f, 1f, 1f, 0.5f);
						GUI.backgroundColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
					}
					EditorGUILayout.Space();
					nfo.ed.DrawProperties(action);
					GUILayout.Space(5);
					GUI.color = Color.white;
					GUI.backgroundColor = Color.white;
				}
				EditorGUILayout.EndVertical();
				GUI.enabled = true;
			}

			// not expanded, show the "note"
			else
			{
				rr = r; rr.x = rr.xMax; rr.width = 2000; rr.height -= 12;
				GUI.Label(rr, action.ToString(), VinomaEdGUI.ActionNote_Style);
			}

			// draw active action marker if in play mode
			if (EditorApplication.isPlaying)
			{
				doRepaint = true; // repaint constantly so that correct active action can be shown
				if (sceneController == null)
				{
					GameObject go = GameObject.Find("VinomaSceneController");
					if (go != null) sceneController = go.GetComponent<VinomaSceneController>();
				}

				if (sceneController != null && sceneController.activeSceneIdx >= 0 && sceneController.activeSceneIdx < VinomaEdGlobal.asset.scenes.Length)
				{
					if (currSceneIdx != sceneController.activeSceneIdx)
					{
						currSceneIdx = sceneController.activeSceneIdx;
					}

					if (VinomaEdGlobal.asset.scenes[sceneController.activeSceneIdx].activeAction == action)
					{
						rr = r; rr.x -= 8; rr.y -= 12; rr.width = 216; rr.height = 56;
						GUI.DrawTexture(rr, VinomaEdGUI.Texture_ActionActive);
					}
				}
			}

			// check if drag-and-drop insert (in space just above this action)
			if (!EditorApplication.isPlayingOrWillChangePlaymode && Event.current.type == EventType.Repaint && dragDrop != null && dragDropInsertContext == null)
			{
				if (r.Contains(Event.current.mousePosition))
				{
					dragDropInsertContext_change = action;
					DrawActionLabel(dragDrop, r);
				}
			}

			// check if trying to grab and drag action
			if (!EditorApplication.isPlayingOrWillChangePlaymode && Event.current.button == 0 && Event.current.type == EventType.MouseDrag && dragDrop == null && actionDragStartedOn == null)
			{
				if (Event.current.button == 0 && r.Contains(Event.current.mousePosition))
				{
					plyEdGUI.ClearFocus();
					actionDragStartedOn = action;
					if (dragTimer == null) dragTimer = new System.Diagnostics.Stopwatch();
					dragTimer.Reset();
					dragTimer.Start();
				}
			}

			return false;
		}

		private void SetAllActionsCollapseState(bool expand)
		{
			VinomaAction action = currScene.firstAction;
			while (action != null)
			{
				action._expanded = expand;
				action = action.next;
			}
			doRepaint = true;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region scene management

		private void RefreshScenesPopup()
		{
			GC_ScenesPopup = new GUIContent[VinomaEdGlobal.asset.scenes.Length];
			for (int i = 0; i < VinomaEdGlobal.asset.scenes.Length; i++)
			{
				GC_ScenesPopup[i] = new GUIContent(VinomaEdGlobal.asset.scenes[i].name);
			}
			//Repaint();
		}

		private void OnCreateScene(plyTextInputWiz wiz)
		{
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				// check if name is unique
				foreach (VinomaScene sc in VinomaEdGlobal.asset.scenes)
				{
					if (sc.name.Equals(s))
					{
						EditorUtility.DisplayDialog("Error", "The name must be unique among all scenes.", "Ok");
						return;
					}
				}

				// create and make active
				CreateScene(s);
				currSceneIdx = VinomaEdGlobal.asset.scenes.Length - 1;
			}

			//Repaint();
		}

		private void OnDuplicateScene(plyTextInputWiz wiz)
		{
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				// check if name is unique
				foreach (VinomaScene sc in VinomaEdGlobal.asset.scenes)
				{
					if (sc.name.Equals(s))
					{
						EditorUtility.DisplayDialog("Error", "The name must be unique among all scenes.", "Ok");
						return;
					}
				}

				// create and make active
				CreateScene(s, VinomaEdGlobal.asset.scenes[currSceneIdx]);
				currSceneIdx = VinomaEdGlobal.asset.scenes.Length - 1;
			}
		}

		private void OnRenameScene(plyTextInputWiz wiz)
		{
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s))
			{
				// check if name is unique
				foreach (VinomaScene sc in VinomaEdGlobal.asset.scenes)
				{
					if (sc.name.Equals(s) && sc != currScene)
					{
						EditorUtility.DisplayDialog("Error", "The name must be unique among all scenes.", "Ok");
						return;
					}
				}

				// rename
				currScene.name = s;
				GC_SceneSelect.text = currScene.name;
				EditorUtility.SetDirty(VinomaEdGlobal.asset);
				plyEdUtil.MarkSceneDirty();
				RefreshScenesPopup();
			}

			//Repaint();
		}

		private void CreateScene(string name, VinomaScene fromScene = null)
		{
			VinomaScene sc = ScriptableObject.CreateInstance<VinomaScene>();
			sc.name = name;

			if (VinomaEdGlobal.asset.scenes == null) VinomaEdGlobal.asset.scenes = new VinomaScene[0];
			ArrayUtility.Add(ref VinomaEdGlobal.asset.scenes, sc);

			if (fromScene != null)
			{
				fromScene.CopyTo(sc);
			}

			ForceSaveAsset();
			RefreshScenesPopup();
		}

		private void MoveScene(bool up)
		{
			if (up)
			{
				if (currSceneIdx <= 0) return;
				VinomaScene s = VinomaEdGlobal.asset.scenes[currSceneIdx - 1];
				ArrayUtility.RemoveAt(ref VinomaEdGlobal.asset.scenes, currSceneIdx - 1);
				ArrayUtility.Insert(ref VinomaEdGlobal.asset.scenes, currSceneIdx, s);
				currSceneIdx--;
			}
			else
			{
				if (currSceneIdx >= VinomaEdGlobal.asset.scenes.Length - 1) return;
				ArrayUtility.RemoveAt(ref VinomaEdGlobal.asset.scenes, currSceneIdx);
				ArrayUtility.Insert(ref VinomaEdGlobal.asset.scenes, currSceneIdx + 1, currScene);
				currSceneIdx++;
			}

			ForceSaveAsset();
			RefreshScenesPopup();
		}

		private void RemoveScene()
		{
			// remove the scene's actions
			VinomaAction ac = currScene.firstAction;
			currScene.firstAction = null;
			while (ac != null)
			{
				DestroyImmediate(ac, true);
				ac = ac.next;
			}

			// remove the scene
			ArrayUtility.Remove<VinomaScene>(ref VinomaEdGlobal.asset.scenes, currScene);
			DestroyImmediate(currScene, true);
			currSceneIdx--;
			ForceSaveAsset();

			// create a default new scene if last scene was removed
			if (currSceneIdx < 0)
			{
				if (VinomaEdGlobal.asset.scenes.Length == 0) CreateScene("Scene 1");
				currSceneIdx = 0;
			}

			RefreshScenesPopup();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region action management

		private void AddActionToScene()
		{
			plyEdGUI.ClearFocus();

			if (dragDrop != null)
			{
				VinomaAction action = dragDropBlock == null ? CreateAction(dragDrop) : dragDropBlock;

				if (dragDropBlock != null)
				{
					AddActionToAsset(action);
				}

				// insert as first
				if (currScene.firstAction == null)
				{
					action.next = null; action.prev = null;
					currScene.firstAction = action;
				}

				// insert as last
				else if (dragDropInsertContext == null)
				{
					VinomaAction last = currScene.firstAction;
					while (last.next != null) last = last.next;
					last.next = action;
					action.prev = last;
				}

				// insert above context
				else
				{
					if (currScene.firstAction == dragDropInsertContext) currScene.firstAction = action;
					action.next = dragDropInsertContext;
					action.prev = dragDropInsertContext.prev;
					dragDropInsertContext.prev = action;
					if (action.prev != null) action.prev.next = action;
				}

				action.owner = currScene;

				// add to list of actions
				if (currScene.actions == null) currScene.actions = new VinomaAction[0];

				VinomaAction[] actions = currScene.actions;
				ArrayUtility.Add(ref actions, action);
				currScene.actions = actions;

				// done
				EditorUtility.SetDirty(VinomaEdGlobal.asset);
				plyEdUtil.MarkSceneDirty();
			}

			dragDrop = null;
			dragDropBlock = null;
			dragDropInsertContext = null;
			dragDropInsertContext_change = null;
			dragDropBlockOldContext = null;

			doRepaint = true;
		}

		private VinomaAction CreateAction(VinomaActionNfo nfo)
		{
			VinomaAction ac = ScriptableObject.CreateInstance(nfo.att.Target) as VinomaAction;
			ac.name = nfo.att.Name;
			AddActionToAsset(ac);
			return ac;
		}

		private void AddActionToAsset(VinomaAction action)
		{
//#if ASSET_HIDEFLAGS_ON
//			action.hideFlags = HideFlags.HideInHierarchy;
//#endif
			//AssetDatabase.AddObjectToAsset(action, currScene);
			ForceSaveAsset();
		}

		private void RemoveAction(VinomaAction action)
		{
			plyEdGUI.ClearFocus();

			// change links between actions
			if (currScene.firstAction == action) currScene.firstAction = action.next;
			if (action.prev != null) action.prev.next = action.next;
			if (action.next != null) action.next.prev = action.prev;
			action.next = null;
			action.prev = null;
			action.owner = null;

			// remove action
			VinomaAction[] actions = currScene.actions;
			ArrayUtility.Remove(ref actions, action);
			currScene.actions = actions;

			DestroyImmediate(action, true);
			ForceSaveAsset();
		}

		private void UnlinkActionForDragDrop()
		{
			dragDropInsertContext = null;
			dragDropInsertContext_change = null;
			unlinkDragDropBlock = false;
			dragDropBlockOldContext = dragDropBlock.next;

			VinomaAction ac = (VinomaAction)ScriptableObject.Instantiate(dragDropBlock);
			ac.name = dragDropBlock.name;
			ac.next = null;
			ac.prev = null;
			ac.owner = null;

			RemoveAction(dragDropBlock);
			dragDropBlock = ac;

			doRepaint = true;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub helpers

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region helpers

		private void ForceSaveAsset()
		{
			EditorUtility.SetDirty(VinomaEdGlobal.asset);
			plyEdUtil.MarkSceneDirty();
			//AssetDatabase.SaveAssets();
			//AssetDatabase.ImportAsset(VinomaEdGlobal.ASSET_PATH);
		}

		private VinomaActionNfo GetActionNfo(VinomaAction action)
		{
			System.Type t = action.GetType();
			for (int i = 0; i < actions.Count; i++)
			{
				if (actions[i].att.Target == t) return actions[i];
			}
			return null;
		}

		private Rect CalcRectFromStyle(GUIContent gc, GUIStyle st)
		{
			Vector2 sz = st.CalcSize(gc);
			Rect r = new Rect(0, 0, sz.x, sz.y);
			return r;
		}

		private Rect CalcRectFromStyle(GUIContent gc, GUIStyle st, Vector2 position)
		{
			Vector2 sz = st.CalcSize(gc);
			Rect r = new Rect(position.x, position.y, sz.x, sz.y);
			return r;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
