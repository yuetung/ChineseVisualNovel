﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class VinomaInputManager : MonoBehaviour
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties


		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		public static bool MouseHandled { get; set; }

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void Awake()
		{
			MouseHandled = false;
		}

		protected void LateUpdate()
		{
			MouseHandled = false;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub


		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
