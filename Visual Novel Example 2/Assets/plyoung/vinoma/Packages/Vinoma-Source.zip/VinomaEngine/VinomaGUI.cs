﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	//[AddComponentMenu("Vinoma/Vinoma GUI Controller")]
	[AddComponentMenu("")]
	public class VinomaGUI : MonoBehaviour
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties
		
		[Header("Game Settings Area")]
		public Text resolutionLabel;
		public Text qualityLabel;
		public Toggle fullscreenToggle;

		public Slider mainVolumeSlider;
		public Slider sfxVolumeSlider;
		public Slider musicVolumeSlider;

		[Header("Dialogue Panel")]
		public GameObject dialoguePanel;
		public Text conversationName;
		public Text conversationText;

		[Header("Player Response")]
		public GameObject responseButtonsPanel;
		public Button[] responseButtons = new Button[5];

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		public static VinomaGUI Instance { get; private set; }

		public VinomaDialogueController dialogueController { get; private set; }

		public IDialogueTextHandler dialogueTextHandler { get; private set; }

		private GameObject activePanel = null;
		private GameObject previousPanel = null;
		private Dictionary<string, GameObject> panels = new Dictionary<string, GameObject>();

		private int currRes = 0;
		private int currQlt = 0;

		private System.Action buttonsCallback;
		private VinomaButtonDef[] buttonsDefs;
		private float buttonsTimer = 0.0f;
		private int defaultButton = -1;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void Awake()
		{
			Instance = this;
			GameObject.DontDestroyOnLoad(gameObject);

			dialogueTextHandler = null;
			if (conversationText != null)
			{	// check if there is a handler
				dialogueTextHandler = conversationText.gameObject.GetComponent<IDialogueTextHandler>();
			}

			// find all the "panels"
			GameObject first = null;
			for (int i = 0; i < transform.childCount; i++)
			{
				GameObject go = transform.GetChild(i).gameObject;
				if (first == null) first = go;
				if (panels.ContainsKey(go.name))
				{
					Debug.LogError(string.Format("The panel named [{0}] was already added. You should not use duplicate names for the UI panels.", go.name));
				}
				else
				{
					panels.Add(go.name, go);
				}
			}

			if (panels.Count > 0)
			{
				// hide all panels
				foreach (GameObject go in panels.Values)
				{
					go.SetActive(false);
				}

				// make the 1st panel visible
				previousPanel = null;
				activePanel = first;
				first.SetActive(true);
			}

			dialogueController = gameObject.AddComponent<VinomaDialogueController>();
		}

		protected void Start()
		{
			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				if (fullscreenToggle != null) fullscreenToggle.isOn = VinomaGameGlobal.setting_fullscreen;
				if (resolutionLabel != null) resolutionLabel.text = Screen.width + "x" + Screen.height;

				for (int i = 0; i < Screen.resolutions.Length; i++)
				{
					if (Screen.width == Screen.resolutions[i].width && Screen.height == Screen.resolutions[i].height)
					{
						currRes = i;
						break;
					}
				}
			}

			currQlt = QualitySettings.GetQualityLevel();
			if (qualityLabel != null) qualityLabel.text = QualitySettings.names[currQlt];

			if (mainVolumeSlider != null) mainVolumeSlider.value = VinomaGameGlobal.setting_mainVolume;
			if (sfxVolumeSlider != null) sfxVolumeSlider.value = VinomaGameGlobal.setting_sfxVolume;
			if (musicVolumeSlider != null) musicVolumeSlider.value = VinomaGameGlobal.setting_musicVolume;

			ReziseUI(null);
		}

		protected void OnDestroy()
		{
			Instance = null;
		}

		protected void Update()
		{
			if (UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject())
			{
				VinomaInputManager.MouseHandled = true;
			}

			if (buttonsTimer > 0.0f && defaultButton >= 0)
			{
				buttonsTimer -= Time.deltaTime;
				if (buttonsTimer <= 0.0f)
				{
					OnResponseButton(defaultButton + 1); // +1 cause it expect indexing to start at 1 and not 0
				}
			}

		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region UI Callbacks

		public void QuitGame()
		{
			Application.Quit();
		}

		public void SetLanguage(string lang)
		{
			Languages.Instance.SetActiveLanguage(lang);
		}

		public void ResetPanels(bool gameScenesActive)
		{
			previousPanel = null;
			activePanel = null;
			foreach (GameObject go in panels.Values)
			{
				AutoPanelVisibility v = go.GetComponent<AutoPanelVisibility>();
				if (v != null)
				{
					if (v.option == AutoPanelVisibility.Option.AlwaysVisible)
					{
						go.SetActive(true);
					}
					else if (v.option == AutoPanelVisibility.Option.VisibleDuringGameScenes)
					{
						go.SetActive(gameScenesActive == true);
					}
					else if (v.option == AutoPanelVisibility.Option.VisibleDuringNotGameScenes)
					{
						go.SetActive(gameScenesActive == false);
					}
				}
				else
				{
					// else do nothing - go.SetActive(false);
				}
			}		
		}

		public void HideAllPanels()
		{
			previousPanel = null;
			activePanel = null;
			foreach (GameObject go in panels.Values)
			{
				go.SetActive(false);
			}
		}

		public void ShowPanel(string panelName)
		{
			if (string.IsNullOrEmpty(panelName)) return;

			GameObject go;
			if (panels.TryGetValue(panelName, out go))
			{
				if (activePanel != null) activePanel.SetActive(false);
				go.SetActive(true);
				previousPanel = activePanel;
				activePanel = go;
			}
			else
			{
				Debug.LogError(string.Format("ShowPanel failed. The panel [{0}] could not be found in the list of panels."));
			}
		}

		public void ShowPanelAdditive(string panelName)
		{
			GameObject go;
			if (panels.TryGetValue(panelName, out go))
			{
				go.SetActive(true);
			}
			else
			{
				Debug.LogError(string.Format("ShowPanelAdditive failed. The panel [{0}] could not be found in the list of panels."));
			}
		}

		public void HidePanel(string panelName)
		{
			if (string.IsNullOrEmpty(panelName)) return;

			GameObject go;
			if (panels.TryGetValue(panelName, out go))
			{
				if (activePanel == go)
				{
					previousPanel = activePanel;
					activePanel = null;
				}
				go.SetActive(false);
			}
			else
			{
				Debug.LogError(string.Format("HidePanel failed. The panel [{0}] could not be found in the list of panels."));
			}
		}

		public void HideActivePanel()
		{
			if (activePanel != null)
			{
				activePanel.SetActive(false);
				
			}

			activePanel = null;
			previousPanel = null;
		}

		public void HideActiveAndShowPreviousPanel()
		{
			//Debug.Log(activePanel + " :: " + previousPanel);
			if (activePanel != null)
			{
				activePanel.SetActive(false);
				activePanel = null;
			}

			if (previousPanel != null)
			{
				previousPanel.SetActive(true);
				activePanel = previousPanel;
			}

			previousPanel = null;
		}

		public void StartNewGame()
		{
			VinomaGameGlobal.Instance.StopMusic(new plyEasing());
			VinomaSceneController.Instance.StartNewGame();
		}

		public void LoadGameFromSlot(int slot)
		{
			if (LoadSaveController.Instance.SlotHasData(slot))
			{
				HideActivePanel();
				VinomaGameGlobal.Instance.StopMusic(new plyEasing());
				LoadSaveController.Instance.LoadFromSlot(slot);
			}
		}

		public void SaveGameToSlot(int slot)
		{
			LoadSaveController.Instance.SaveToSlot(slot);
		}

		public void DeleteAllSaveData()
		{
			LoadSaveController.Instance.DeleteAll();
		}

		public void IncreaseResolution()
		{
			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				currRes++;
				if (currRes >= Screen.resolutions.Length) currRes = Screen.resolutions.Length - 1;
				if (resolutionLabel != null) resolutionLabel.text = Screen.resolutions[currRes].width + "x" + Screen.resolutions[currRes].height;
			}
		}

		public void DecreaseResolution()
		{
			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				currRes--;
				if (currRes < 0) currRes = 0;
				if (resolutionLabel != null) resolutionLabel.text = Screen.resolutions[currRes].width + "x" + Screen.resolutions[currRes].height;
			}
		}

		public void IncreaseQuality()
		{
			currQlt++;
			if (currQlt >= QualitySettings.names.Length) currQlt = QualitySettings.names.Length - 1;
			if (qualityLabel != null) qualityLabel.text = QualitySettings.names[currQlt];
		}

		public void DecreaseQuality()
		{
			currQlt--;
			if (currQlt < 0) currQlt = 0;
			if (qualityLabel != null) qualityLabel.text = QualitySettings.names[currQlt];
		}

		public void ApplySettings()
		{
			VinomaGameGlobal.setting_mainVolume = mainVolumeSlider.value;
			VinomaGameGlobal.setting_sfxVolume = sfxVolumeSlider.value;
			VinomaGameGlobal.setting_musicVolume = musicVolumeSlider.value;
			VinomaGameGlobal.setting_quality = currQlt;

			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				VinomaGameGlobal.setting_fullscreen = fullscreenToggle.isOn;
				VinomaGameGlobal.setting_width = Screen.resolutions[currRes].width;
				VinomaGameGlobal.setting_height = Screen.resolutions[currRes].height;
			}

			VinomaGameGlobal.SaveSettings();
		}

		public void OnResponseButton(int id)
		{
			defaultButton = -1;
			buttonsTimer = 0.0f;

			id--; // cause array starts at 0 while the buttons start at 1
			if (buttonsDefs == null || id < 0 || id >= buttonsDefs.Length)
			{
				Debug.LogError("The button ID is invalid, it should be from 1 to the number of buttons shown.");
				return;
			}

			responseButtonsPanel.SetActive(false);
			if (activePanel == responseButtonsPanel)
			{
				previousPanel = null;
				activePanel = null;
			}

			VinomaButtonDef def = buttonsDefs[id];
			buttonsDefs = null;

			List<VinomaActionOptDef> gotoActs = new List<VinomaActionOptDef>();
			for (int i = 0; i < def.actions.Length; i++)
			{
				if (def.actions[i].act == VinomaActionOptDef.Action.Goto)
				{	// goto actions should be performed last so collect and perform later
					gotoActs.Add(def.actions[i]);
				}
				else
				{
					if (def.actions[i].act == VinomaActionOptDef.Action.Variable)
					{
						VinomaSceneController.Instance.PerformOperationOnVariable(def.actions[i].s_opt1, def.actions[i].s_opt2, def.actions[i].s_opt3, def.actions[i].varOpt);
					}
					else if (def.actions[i].act == VinomaActionOptDef.Action.Variable)
					{
						VinomaSceneController.Instance.PerformOperationOnSwitch(def.actions[i].s_opt1, def.actions[i].swOpt);
					}
				}
			}

			if (gotoActs.Count > 0)
			{
				if (gotoActs.Count > 1) Debug.LogWarning("There can be only one goto action in a button. The first one will now be performed and the rest ignored.");
				VinomaSceneController.Instance.Goto(gotoActs[0].goOpt, gotoActs[0].s_opt1, gotoActs[0].s_opt2);
			}
			else if (buttonsCallback != null) buttonsCallback();
		}

		public void ToggleDialogueAuto(Toggle toggle)
		{
			dialogueController.SetDialogueAuto(toggle.isOn);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public void ReziseUI(SpriteRenderer back)
		{
			float backgroundEdgeOffs = back == null ? 0f : Camera.main.WorldToScreenPoint(back.transform.position - back.bounds.extents).x;
			if (backgroundEdgeOffs < 0.0f) backgroundEdgeOffs = 0f;

			float designEdgeOffs = (Screen.width - (Screen.height * ((float)VinomaGameGlobal.Instance.asset.designWidth / (float)VinomaGameGlobal.Instance.asset.designHeight))) / 2f;
			if (designEdgeOffs < 0.0f) designEdgeOffs = 0f;

			foreach (GameObject go in panels.Values)
			{
				WidthAdaptController c = go.GetComponent<WidthAdaptController>();
				if (c != null)
				{
					c.UpdateWidth(backgroundEdgeOffs, designEdgeOffs);
				}
			}
		}

		public void ShowButtons(VinomaButtonDef[] defs, int defaultButtonIdx, float buttonsTimeout, System.Action callback)
		{
			buttonsCallback = callback;
			buttonsDefs = defs;

			if (defaultButtonIdx >= defs.Length)
			{
				Debug.LogWarning("A timeout was chosen for the buttons but the selected button is not in the set of defined buttons. Please check that one of the buttons are marked as the one to use when the timeout is reached.");
				defaultButton = -1;
				buttonsTimer = 0.0f;
			}
			else
			{
				defaultButton = defaultButtonIdx;
				buttonsTimer = defaultButtonIdx < 0 ? 0.0f : buttonsTimeout;
			}

			// hide all buttons
			for (int i = 0; i < responseButtons.Length; i++)
			{
				responseButtons[i].gameObject.SetActive(false);
			}

			// show only defined buttons
			responseButtonsPanel.SetActive(true);
			for (int i = 0; i < defs.Length; i++)
			{
				responseButtons[i].gameObject.SetActive(true);
				//Transform tr = responseButtons[i].transform.FindChild("Text");
				Transform tr = responseButtons[i].transform.Find("Text");
				if (tr == null)
				{
					Debug.LogError("The Button should have a child object called Text that has a Text component on it.");
					return;
				}

				Text t = tr.GetComponent<Text>();
				if (t == null)
				{
					Debug.LogError("The Button should have a child object called Text that has a Text component on it.");
					return;
				}

				t.text = VinomaSceneController.Instance.ParseTextForVariables(Languages.Instance.GetString(defs[i].langId_text, defs[i].text));
			}

		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}

}

