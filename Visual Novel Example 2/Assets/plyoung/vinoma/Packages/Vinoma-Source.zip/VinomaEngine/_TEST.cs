﻿//using UnityEngine;

//namespace VinomaEngine
//{
//	public class _TEST
//	{
//		[RuntimeInitializeOnLoadMethod]
//		static void OnRuntimeMethodLoad()
//		{
//			Debug.Log("Game loaded and is running");
//		}
//	}
//}


//
