﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VinomaScene : ScriptableObject
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties
		
		public VinomaAction firstAction;	// the first action of the scene
		public VinomaAction[] actions;    // all actions contained in the scene

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		public VinomaAction activeAction { get; set; }

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		public void CopyTo(VinomaScene sc)
		{
			if (firstAction != null)
			{
				List<VinomaAction> actions = new List<VinomaAction>();
				VinomaAction sourceAction = firstAction;
				VinomaAction newAction = sourceAction.Copy();
				sourceAction.CopyBaseDataTo(newAction, sc);
				sc.firstAction = newAction;
				actions.Add(newAction);

				while (sourceAction.next != null)
				{
					newAction.next = sourceAction.next.Copy();
					sourceAction.next.CopyBaseDataTo(newAction.next, sc);
					newAction.next.owner = sc;
					newAction.next.prev = newAction;

					sourceAction = sourceAction.next;
					newAction = newAction.next;
					actions.Add(newAction);
				}

				sc.actions = actions.ToArray();
			}
			else
			{
				firstAction = null;
				actions = new VinomaAction[0];
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		// Init Scene actions. Triggered from Triggered from GameGlobal.Start()
		public void Init()
		{
			VinomaAction action = firstAction;
			while (action != null)
			{
				action.Init();
				action = action.next;
			}
		}

		// Force stop the scene
		public void Stop()
		{
			if (activeAction != null)
			{
				activeAction.Stop();
			}
		}

		// called each frame
		public void Update()
		{
			if (activeAction != null)
			{
				activeAction.Update();
			}
		}

		public int GetActionIdx(VinomaAction ac)
		{
			for (int i = 0; i < actions.Length; i++)
			{
				if (actions[i] == ac) return i;
			}
			return -1;
		}

		public int GetActiveActionIdx()
		{
			if (activeAction == null) return -1;
			return GetActionIdx(activeAction);
		}

		public void UpdateStrings(Languages languages)
		{
			for (int i = 0; i < actions.Length; i++)
			{
				actions[i].UpdateStrings(languages);
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
