﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	[AddComponentMenu("")]
	public class VinomaDataAsset : MonoBehaviour//, ISerializationCallbackReceiver
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties

		public VinomaScene[] scenes = new VinomaScene[0];
		public VinomaHotspotsOverlay[] hotspotOverlays = new VinomaHotspotsOverlay[0];

		public int designWidth = 1024;
		public int designHeight = 768;
		public float pixelsPerUnit = 100f;
		public VinomaWidthAdapt sceneBorder = VinomaWidthAdapt.Background;
		public bool clearOnSceneChange = true;
		public bool gameObjectsToo = true;
		public AudioClip menuMusic;
		public bool manageGameSettings = true;
		public bool resolutionSettingsActive = true;
		public float autoDialogueSpeed = 1f;

		[SerializeField] private int nexthotspotOverlaysId = 1;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region hotspots

		private GUIContent[] _hotspotOverlayNames = new GUIContent[0];
		public GUIContent[] HotspotOverlayNames
		{
			get
			{
				if (hotspotOverlays != null)
				{
					if (_hotspotOverlayNames.Length != hotspotOverlays.Length)
					{
						_hotspotOverlayNames = new GUIContent[hotspotOverlays.Length];
						for (int i = 0; i < hotspotOverlays.Length; i++) _hotspotOverlayNames[i] = new GUIContent(hotspotOverlays[i].name);
					}
				}
				else
				{
					if (_hotspotOverlayNames.Length != 0) _hotspotOverlayNames = new GUIContent[0];
				}
				return _hotspotOverlayNames;
			}
			set
			{
				_hotspotOverlayNames = value;
			}
		}

		public string GetHotspotOverlayName(int ident)
		{
			int idx = GetHotspotOverlayIDX(ident);
			if (idx < 0) return "";
			return hotspotOverlays[idx].name;
		}

		public int CreateHotspotOverlayIdent()
		{
			return nexthotspotOverlaysId++;
		}

		public int GetHotspotOverlayIDX(int ident)
		{
			for (int i = 0; i < hotspotOverlays.Length; i++)
			{
				if (hotspotOverlays[i].ident == ident) return i;
			}
			return -1;
		}

		public int GetHotspotOverlayIdent(int idx)
		{
			if (idx < 0 || idx >= hotspotOverlays.Length) return 0;
			return hotspotOverlays[idx].ident;
		}

		public VinomaHotspotsOverlay GetHotspotOverlay(int ident)
		{
			for (int i = 0; i < hotspotOverlays.Length; i++)
			{
				if (hotspotOverlays[i].ident == ident) return hotspotOverlays[i];
			}
			return null;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		////
		//// Summary:
		////     ///
		////     Implement this method to receive a callback after Unity deserializes your object.
		////     ///
		//void OnAfterDeserialize()
		//{
		//}
		////
		//// Summary:
		////     ///
		////     Implement this method to receive a callback before Unity serializes your object.
		////     ///
		//void OnBeforeSerialize()
		//{
		//}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub



		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
