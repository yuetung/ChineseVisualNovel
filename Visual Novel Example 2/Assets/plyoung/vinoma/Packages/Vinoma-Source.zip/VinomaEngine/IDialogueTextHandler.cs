﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	public interface IDialogueTextHandler
	{
		// called when new text should be set on dialogue text field
		void SetText(string text);

		// called after the dialogue is made visible and conversation about to start
		void Clear();
	}

	// ------------------------------------------------------------------------------------------------------------
}
