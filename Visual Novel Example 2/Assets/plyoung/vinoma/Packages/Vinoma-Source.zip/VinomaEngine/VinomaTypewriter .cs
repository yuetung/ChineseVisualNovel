﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[RequireComponent(typeof(Text)), AddComponentMenu("Vinoma/Typewriter Effect")]
	public class VinomaTypewriter : MonoBehaviour, IDialogueTextHandler
	{
		public Text targetUIText;
		public float delay = 0.1f;
		public bool perWord = false;

		private bool runEffect = false;
		private string origText = "";
		private int idx = 0;
		private float timer = 0.0f;

		protected void Reset()
		{
			if (targetUIText == null) targetUIText = GetComponent<Text>();
		}

		public void SetText(string text)
		{
			targetUIText.text = "";
			origText = text;
			idx = 0;
			timer = 0.0f;
			runEffect = !string.IsNullOrEmpty(text);
		}

		public void Clear()
		{
			targetUIText.text = "";
		}

		protected void Update()
		{
			if (!runEffect) return;

			timer -= Time.deltaTime;
			if (timer <= 0.0f)
			{
				timer = delay;

				if (perWord)
				{
					string word = "";
					int p = origText.IndexOf(' ', idx);
					if (p <= 0)
					{
						word = origText.Substring(idx);
						runEffect = false;
					}
					else
					{
						p++;
						word = origText.Substring(idx, p - idx);
						idx = p;
						if (idx >= origText.Length) runEffect = false;
					}

					targetUIText.text += word;
				}
				else
				{
					targetUIText.text += origText[idx];
					idx++; if (idx >= origText.Length) runEffect = false;
				}
			}

		}
	}

	// ------------------------------------------------------------------------------------------------------------
}
