﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{

	public enum VinomaSceneSortOrder
	{
		Front,
		Back,
		Custom
	}

	public enum VinomaSceneLocation
	{
		Middle,
		Left,
		Right,
		Custom
	}

	public enum VinomaSceneSide
	{
		InPlace,
		Left,
		Right,
		Top,
		Bottom,
		TopLeft,
		TopRight,
		BottomLeft,
		BottomRight
	}

	public enum VinomaWidthAdapt
	{
		Screen,
		Design,
		Background
	}

	public enum VinomaViewOption
	{
		Show, 
		Hide
	}

	public enum VinomaEnableOption
	{
		Enable,
		Disable
	}

	//public enum VinomaPlayOption
	//{
	//	Play,
	//	Stop
	//}

	public enum VinomaTargetObject
	{
		Object,
		Character
	}

	/// <summary>
	/// Options available when using a goto type action
	/// </summary>
	public enum VinomaGotoOption
	{
		Label,		//!< go to specific label in scene
		Scene,		//!< go to start of specific scene (or optionally a label in that scene)
		SceneTop,	//!< go to top of current scene
		SceneEnd,	//!< go to end of current scene
	}

	public enum VinomaVarOperation
	{
		Set,
		Append,
		Add,
		Subtract,
		Multiply,
		Divide,
		Random
	}

	public enum VinomaSwitchOperation
	{
		On,
		Off,
		Toggle
	}

	public enum VinomaConditionCheck
	{
		Variable, Switch
	}

	public enum VinomaVarCondition
	{
		EqualTo,
		NotEqualTo,
		SmallerThan,
		BiggerThan,
		SmallerThanOrEqual,
		BiggerThanOrEqual,
	}

	public enum VinomaSwitchCondition
	{
		IsOn,
		IsOff,
	}

	public enum VinomaConditionCombine
	{
		And, Or
	}

	public enum VinomaObjectGroup 
	{ 
		VinomaGUI, 
		GameObjects 
	}

	// ------------------------------------------------------------------------------------------------------------

	[System.Serializable]
	public struct VinomaActionOptDef
	{
		public enum Action { None, Goto, Variable, Switch }
		public Action act;					// what happens when button is pressed
		public string s_opt1;				// goto-scene, variable name, switch name
		public string s_opt2;				// goto-label, variable value
		public string s_opt3;				// variable value2
		public VinomaGotoOption goOpt;		// if act = goto
		public VinomaVarOperation varOpt;	// if act = Variable
		public VinomaSwitchOperation swOpt; // if act = switch

		public VinomaActionOptDef Copy()
		{
			return new VinomaActionOptDef()
			{
				act = act,
				s_opt1 = s_opt1,
				s_opt2 = s_opt2,
				s_opt3 = s_opt3,
				goOpt = goOpt,
				varOpt = varOpt,
				swOpt = swOpt
			};
		}
	}

	[System.Serializable]
	public struct VinomaButtonDef
	{
		public string text;					// button text
		public int langId_text;
		public VinomaActionOptDef[] actions;    // actions to perform when the button is pressed

		public VinomaButtonDef Copy()
		{
			VinomaButtonDef def = new VinomaButtonDef()
			{
				text = text,
				langId_text = langId_text,
				actions = new VinomaActionOptDef[actions.Length]
			};

			for (int i = 0; i < actions.Length; i++)
			{
				def.actions[i] = actions[i].Copy();
			}

			return def;
		}
	}

	[System.Serializable]
	public struct VinomaConditionDef
	{
		public VinomaConditionCheck chectType;	// check variable or switch?
		public VinomaVarCondition varOpt;		// for variable
		public VinomaSwitchCondition swOpt;		// for switches
		public string opt1;						// name if variable or switch
		public string opt2;						// value to check variable against
		public VinomaConditionCombine combine;  // how to combine with previous condition if any

		public VinomaConditionDef Copy()
		{
			return new VinomaConditionDef()
			{
				chectType = chectType,
				varOpt = varOpt,
				swOpt = swOpt,
				opt1 = opt1,
				opt2 = opt2,
				combine = combine
			};
		}
	}

	[System.Serializable]
	public struct VinomaBranchDef
	{
		public VinomaGotoOption goOpt;		// what to do when condition(s) succeed
		public string sceneName;
		public string labelName;
		public VinomaConditionDef[] conditions;

		public VinomaBranchDef Copy()
		{
			VinomaBranchDef def = new VinomaBranchDef()
			{
				goOpt = goOpt,
				sceneName = sceneName,
				labelName = labelName,
				conditions = new VinomaConditionDef[conditions.Length]
			};

			for (int i = 0; i < conditions.Length; i++)
			{
				def.conditions[i] = conditions[i].Copy();
			}

			return def;
		}
	}

	// ------------------------------------------------------------------------------------------------------------

	public struct _SpriteCacheEntry
	{
		public Sprite sprite;
		public Vector2 offs;
		public Vector2 size;
	}

	// ------------------------------------------------------------------------------------------------------------
}
