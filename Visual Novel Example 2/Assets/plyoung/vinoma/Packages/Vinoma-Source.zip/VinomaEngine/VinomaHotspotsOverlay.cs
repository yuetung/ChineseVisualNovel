﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VinomaHotspot
	{
		public Rect position;
		public Sprite hoverSprite;
		public VinomaActionOptDef[] actions;
	}

	[System.Serializable]
	public class VinomaHotspotsOverlay : ScriptableObject
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties

		public int ident;
		public VinomaHotspot[] hotspots;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime



		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system



		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub



		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
