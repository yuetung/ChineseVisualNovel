﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using plyCommon2;
using DG.Tweening;


namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class VinomaSceneController : MonoBehaviour
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		private class CharacterInfo
		{
			public string name;						// name of character
			public int sortOrder = 0;				// character's main sort order
			public GameObject go;					// character's GameObject
			public SpriteRendererFadeGroup[] fadeGroup;		// 0: mainSprite, 1+: poseSprites
			public SpriteRenderer sprite;			// the sprite considered to be the "main". this might change when pose is changed
			public bool mainSpriteIsInPose = false;	// helper for determining the main sprite
			public Vector3 pos;						// keep track of character's view position
			public FloatRectOffset padding;			// main sprite's padding
			public bool _move = false;				// helper
			public Tweener moveTween = null;		// helper keeping track of the active move tweener

			public int enter_sceneIdx = -1;			// the scene that added the character (used by save system)
			public int enter_actionIdx = -1;		// the action that added the character (used by save system)
			public int pose_sceneIdx = -1;			// the scene that last changed the character pose (used by save system)
			public int pose_actionIdx = -1;			// the action that last changed the character pose (used by save system)

			// returns the sprite's width, taking into account the padding
			public float Width()
			{
				if (sprite != null) return sprite.bounds.size.x - padding.left - padding.right;
				return padding.left + padding.right;
			}

			// return the Left edge of the character, taking into account the padding
			public float Left()
			{
				if (sprite != null) return pos.x - (sprite.bounds.size.x * 0.5f) + padding.left;
				return pos.x + padding.left;
			}

			// return the Right edge of the character, taking into account the padding
			public float Right()
			{
				if (sprite != null) return pos.x + (sprite.bounds.size.x * 0.5f) - padding.right;
				return pos.x - padding.right;
			}
		}

		private class HotspotOverlayInfo
		{
			public VinomaHotspotsOverlay overlay;
			public GameObject obj;
			public bool autoDisable;
			public bool waiting;
			public System.Action callback;
		}

		private static readonly string[] VarInTextHelper = new string[] { " _", "_ ", "_\n", "_" };

		public class ObjectSaveData
		{
			public GameObject target;
			public string charaName;
			public int sceneIdx;
			public int actionIdx;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		public static VinomaSceneController Instance { get; private set; }					//!< An Instance of the controller. It is ready after Awake()
		public int activeSceneIdx { get; private set; }										//!< Index of the currently active Vinoma Scene (index into asset.scenes)
		public VinomaDataAsset asset { get { return VinomaGameGlobal.Instance.asset; } }	//!< Shortcut to VinomaGameGlobal.Instance.asset which contains all the Vinoma data

		private Dictionary<string, string> variables = new Dictionary<string, string>();	// <name, value>
		private Dictionary<string, bool> switches = new Dictionary<string, bool>();			// <name, value>
		private Dictionary<string, System.Action<string>> variableLinks = new Dictionary<string, System.Action<string>>();	// <name, callback>
		private Dictionary<string, System.Action<bool>> switcheLinks = new Dictionary<string, System.Action<bool>>();		// <name, callback>

		private Camera cam;
		private GameObject customScriptsObject;
		private Transform gameObjectsRoot;

		// ----- Background Image(s)

		private SpriteRenderer[] background = new SpriteRenderer[2];
		private SpriteToScreenScaler[] backgroundScaler = new SpriteToScreenScaler[2];
		private Tweener backgroundFadeTween;
		private float edgeOffs = 0f; // this is either 0 when fullscreen or some positive value if there are black borders to left and right on screen

		// ----- Character(s)

		private Transform charactersRoot;
		private Dictionary<string, CharacterInfo> characters = new Dictionary<string, CharacterInfo>();

		// ----- Hotspot Overlays

		private Transform hotspotsRoot;
		private Dictionary<int, HotspotOverlayInfo> hotspots = new Dictionary<int, HotspotOverlayInfo>();

		// ----- Data used by save system

		private bool loading = false;
		private int simSceneIdx = -1;		// used during loading to simulate current action/ scene
		private int simActionIdx = -1;		// used during loading to simulate current action/ scene

		private int backSetSceneIdx = -1;	// idx of scene that last changed the background
		private int backSetActionIdx = -1;	// idx of the action that last changed the background

		private int musicSetSceneIdx = -1;	// idx of scene that last changed the music
		private int musicSetActionIdx = -1;	// idx of the action that last changed the music

		private List<ObjectSaveData> textActionChanges = new List<ObjectSaveData>();
		private List<ObjectSaveData> imageActionChanges = new List<ObjectSaveData>();
		private List<ObjectSaveData> animActionChanges = new List<ObjectSaveData>();
		private List<ObjectSaveData> moveActionChanges = new List<ObjectSaveData>();

		[System.NonSerialized] public List<ObjectSaveData> dialogueSeen = new List<ObjectSaveData>();

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void Awake()
		{
			Instance = this;
			GameObject.DontDestroyOnLoad(gameObject);

			activeSceneIdx = -1;
			cam = Camera.main;

			customScriptsObject = GameObject.Find("_CustomScripts_");
			if (customScriptsObject == null) customScriptsObject = GameObject.Find("[CustomScripts]");
			if (customScriptsObject != null)
			{
				GameObject.DontDestroyOnLoad(customScriptsObject);
			}
			else Debug.LogError("The _CustomScripts_ object was not found.");

			GameObject go = GameObject.Find("_GameObjects_");
			if (go == null) go = GameObject.Find("GameObjects");
			if (go != null)
			{
				gameObjectsRoot = go.transform;
				GameObject.DontDestroyOnLoad(go);
			}
			else Debug.LogError("The _GameObjects_ object was not found.");

			for (int i = 0; i < 2; i++)
			{
				go = new GameObject("Background-" + i);
				go.transform.parent = transform;
				background[i] = go.AddComponent<SpriteRenderer>();
				backgroundScaler[i] = go.AddComponent<SpriteToScreenScaler>();
				background[i].sortingLayerName = VinomaGameGlobal.SortLayer.Background;
				background[i].sortingOrder = i;
			}

			go = new GameObject("Characters");
			go.transform.parent = transform;
			charactersRoot = go.transform;

			go = new GameObject("Hotspots");
			go.transform.parent = transform;
			hotspotsRoot = go.transform;

			Languages.Instance.RegisterLanguageChangeListener(OnLanguageChanged);
		}

		protected void Start()
		{
			gameObject.SetActive(false);
			LoadSaveController.Instance.RegisterLoadSaveListener(OnSave, OnLoad);
		}

		protected void OnDestroy()
		{
			Instance = null;
		}

		protected void Update()
		{
			if (activeSceneIdx >= 0 && activeSceneIdx < asset.scenes.Length)
			{
				asset.scenes[activeSceneIdx].Update();
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region loading and saving

		private void OnSave(int slot)
		{
			string key = slot.ToString();
			string data = null;

			// *** save info seen dialogue
			data = "";
			for (int i = 0; i < dialogueSeen.Count; i++)
			{
				data += dialogueSeen[i].sceneIdx + LoadSaveController.SEP_UNIT +
						dialogueSeen[i].actionIdx + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".seendlg", data);

			// *** save the active scene and action index
			LoadSaveController.Instance.SetInt(key + ".scn", activeSceneIdx);
			LoadSaveController.Instance.SetInt(key + ".act", asset.scenes[activeSceneIdx].GetActiveActionIdx());

			// *** save the variables and switches
			// save the variable data in such a way that i always override any old data
			// and do not have to worry about loading an old saved variable that does
			// not exist in the current variables to be saved
			data = "";			
			foreach (KeyValuePair<string, string> kv in variables)
			{
				data += kv.Key + LoadSaveController.SEP_UNIT + kv.Value + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".vars", data);

			data = "";
			foreach (KeyValuePair<string, bool> kv in switches)
			{
				data += kv.Key + LoadSaveController.SEP_UNIT + (kv.Value ? "1" : "0") + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".swch", data);

			// *** save the background info
			data = backSetSceneIdx + LoadSaveController.SEP_UNIT + backSetActionIdx;
			LoadSaveController.Instance.SetString(key + ".backg", data);

			// *** save the characters' info
			data = "";
			foreach (CharacterInfo chara in characters.Values)
			{
				data += chara.enter_sceneIdx + LoadSaveController.SEP_UNIT + chara.enter_actionIdx + LoadSaveController.SEP_UNIT +
						chara.pose_sceneIdx + LoadSaveController.SEP_UNIT + chara.pose_actionIdx + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".chars", data);

			// *** save playing music
			data = musicSetSceneIdx + LoadSaveController.SEP_UNIT + musicSetActionIdx;
			LoadSaveController.Instance.SetString(key + ".music", data);

			// ** save panel states
			data = "";
			if (VinomaGUI.Instance != null)
			{
				for (int i = 0; i < VinomaGUI.Instance.transform.childCount; i++)
				{
					Transform tr = VinomaGUI.Instance.transform.GetChild(i);
					AutoPanelVisibility viz = tr.GetComponent<AutoPanelVisibility>();
					if (viz != null)
					{
						if (viz.option == AutoPanelVisibility.Option.RememberState)
						{
							data += tr.name + LoadSaveController.SEP_UNIT + 
									(tr.gameObject.activeSelf ? "1" : "0") + LoadSaveController.SEP_RECORD;
						}
					}
				}
			}
			LoadSaveController.Instance.SetString(key + ".pnls", data);

			// *** save object states
			data = "";
			if (gameObjectsRoot != null)
			{
				for (int i = 0; i < gameObjectsRoot.childCount; i++)
				{
					data += (gameObjectsRoot.GetChild(i).gameObject.activeSelf ? "1" : "0") + LoadSaveController.SEP_UNIT;
				}
			}
			LoadSaveController.Instance.SetString(key + ".objs", data);

			// *** save text actions
			data = "";
			for (int i = 0; i < textActionChanges.Count; i++)
			{
				data += textActionChanges[i].sceneIdx + LoadSaveController.SEP_UNIT +
						textActionChanges[i].actionIdx + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".text", data);

			// *** save image actions
			data = "";
			for (int i = 0; i < imageActionChanges.Count; i++)
			{
				data += imageActionChanges[i].sceneIdx + LoadSaveController.SEP_UNIT +
						imageActionChanges[i].actionIdx + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".imgs", data);

			// *** save animation actions
			data = "";
			for (int i = 0; i < animActionChanges.Count; i++)
			{
				data += animActionChanges[i].sceneIdx + LoadSaveController.SEP_UNIT +
						animActionChanges[i].actionIdx + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".anims", data);

			// *** move actions
			data = "";
			for (int i = 0; i < moveActionChanges.Count; i++)
			{
				data += moveActionChanges[i].sceneIdx + LoadSaveController.SEP_UNIT +
						moveActionChanges[i].actionIdx + LoadSaveController.SEP_RECORD;
			}
			LoadSaveController.Instance.SetString(key + ".move", data);

		}

		private void OnLoad(int slot)
		{
			string data = null;
			string[] records;

			loading = true;
			ClearScenes(true);
			string key = slot.ToString();

			// *** load info on seen dialogue
			data = LoadSaveController.Instance.GetString(key + ".seendlg", null);
			if (!string.IsNullOrEmpty(data))
			{
				records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < records.Length; i++)
				{
					string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
					if (entries.Length == 2)
					{
						simSceneIdx = -1; simActionIdx = -1;
						if (int.TryParse(entries[0], out simSceneIdx))
						{
							if (int.TryParse(entries[1], out simActionIdx))
							{
								ObjectSaveData save = new ObjectSaveData();
								save.sceneIdx = simSceneIdx;
								save.actionIdx = simActionIdx;
								dialogueSeen.Add(save);
							}
						}
					}
				}
			}

			// *** load scene and action
			activeSceneIdx = LoadSaveController.Instance.GetInt(key + ".scn", 0);
			int actionIdx = LoadSaveController.Instance.GetInt(key + ".act", -1);

			// *** load the variables and switches
			variables.Clear();
			switches.Clear();

			data = LoadSaveController.Instance.GetString(key + ".vars", "");
			records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < records.Length; i++)
			{
				string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
				if (entries.Length == 2)
				{
					string varNm = entries[0];
					string varVal = entries[1];
					if (string.IsNullOrEmpty(varNm)) continue;
					if (!variables.ContainsKey(varNm)) {
						variables.Add(varNm, varVal);
						if (variableLinks.ContainsKey(varNm)) variableLinks[varNm](varVal);
					}
				}
			}

			data = LoadSaveController.Instance.GetString(key + ".swch", "");
			records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < records.Length; i++)
			{
				string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
				if (entries.Length == 2)
				{
					string switchNm = entries[0];
					bool switchVal = entries[1] == "1";
					if (string.IsNullOrEmpty(switchNm)) continue;
					if (!switches.ContainsKey(switchNm))
					{
						switches.Add(switchNm, switchVal);
						if (switcheLinks.ContainsKey(switchNm)) switcheLinks[switchNm](switchVal);
					}
				}
			}

			// *** restore the background
			data = LoadSaveController.Instance.GetString(key + ".backg", null);
			if (!string.IsNullOrEmpty(data)) RestoreBackground(data);

			// *** restore the characters
			data = LoadSaveController.Instance.GetString(key + ".chars", null);
			if (!string.IsNullOrEmpty(data)) RestoreCharacters(data);

			// *** run the scene, starting at saved action
			loading = false;
			RunScene(activeSceneIdx, actionIdx, true);

			// *** start music
			VinomaGameGlobal.Instance.StopMusic(new plyEasing { time = 0f });
			data = LoadSaveController.Instance.GetString(key + ".music", null);
			if (!string.IsNullOrEmpty(data)) RestoreMusic(data);

			// *** load panel states
			if (VinomaGUI.Instance != null)
			{
				data = LoadSaveController.Instance.GetString(key + ".pnls", null);
				if (!string.IsNullOrEmpty(data))
				{
					records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
					for (int i = 0; i < records.Length; i++)
					{
						string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
						if (entries.Length == 2)
						{
							//Transform tr = VinomaGUI.Instance.transform.FindChild(entries[0]);
							Transform tr = VinomaGUI.Instance.transform.Find(entries[0]);
							if (tr != null)
							{
								tr.gameObject.SetActive(entries[1] == "1");
							}
							else Debug.LogError("The saved Panel name was not found. You need to clean the saved data before testing again: " + entries[0]);
						}
					}
				}
			}

			// *** load object states
			if (gameObjectsRoot != null)
			{
				data = LoadSaveController.Instance.GetString(key + ".objs", null);
				if (!string.IsNullOrEmpty(data))
				{
					string[] entries = data.Split(LoadSaveController.SPLIT_UNIT, System.StringSplitOptions.RemoveEmptyEntries);
					for (int i = 0; i < gameObjectsRoot.childCount; i++)
					{
						if (i >= entries.Length)
						{
							Debug.LogError("The saved GameObjects entries does not match. You need to clean the saved data before testing again.");
							break;
						}
						gameObjectsRoot.GetChild(i).gameObject.SetActive(entries[i] == "1");
					}
				}
			}

			// *** load text actions
			data = LoadSaveController.Instance.GetString(key + ".text", null);
			if (!string.IsNullOrEmpty(data))
			{
				records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < records.Length; i++)
				{
					string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
					if (entries.Length == 2)
					{
						simSceneIdx = -1; simActionIdx = -1;
						if (int.TryParse(entries[0], out simSceneIdx))
						{
							if (int.TryParse(entries[1], out simActionIdx))
							{
								// expect it to be VA_UIText type
								VA_UIText ac = GetAction(simSceneIdx, simActionIdx) as VA_UIText;
								if (ac != null) SetUIText(ac);
								else Debug.LogError("Error while restoring Text actions. You need to clean the saved data before testing again.");
							}
						}
					}
				}
			}

			// *** load image actions
			data = LoadSaveController.Instance.GetString(key + ".imgs", null);
			if (!string.IsNullOrEmpty(data))
			{
				records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < records.Length; i++)
				{
					string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
					if (entries.Length == 2)
					{
						simSceneIdx = -1; simActionIdx = -1;
						if (int.TryParse(entries[0], out simSceneIdx))
						{
							if (int.TryParse(entries[1], out simActionIdx))
							{
								// expect it to be VA_SetImage type
								VA_SetImage ac = GetAction(simSceneIdx, simActionIdx) as VA_SetImage;
								if (ac != null) SetImage(ac);
								else Debug.LogError("Error while restoring Image actions. You need to clean the saved data before testing again.");
							}
						}
					}
				}
			}

			// *** load animation actions
			data = LoadSaveController.Instance.GetString(key + ".anims", null);
			if (!string.IsNullOrEmpty(data))
			{
				records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < records.Length; i++)
				{
					string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
					if (entries.Length == 2)
					{
						simSceneIdx = -1; simActionIdx = -1;
						if (int.TryParse(entries[0], out simSceneIdx))
						{
							if (int.TryParse(entries[1], out simActionIdx))
							{
								// expect it to be VA_Animation type
								VA_Animation ac = GetAction(simSceneIdx, simActionIdx) as VA_Animation;
								if (ac != null) PlayAnimation(ac);
								else Debug.LogError("Error while restoring Animation actions. You need to clean the saved data before testing again.");
							}
						}
					}
				}
			}

			// *** load move actions
			loading = true; // loading is set to false by now but the foillowing needs to know if loading or not
			data = LoadSaveController.Instance.GetString(key + ".move", null);
			if (!string.IsNullOrEmpty(data))
			{
				records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < records.Length; i++)
				{
					string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
					if (entries.Length == 2)
					{
						simSceneIdx = -1; simActionIdx = -1;
						if (int.TryParse(entries[0], out simSceneIdx))
						{
							if (int.TryParse(entries[1], out simActionIdx))
							{
								// expect it to be VA_Animation type
								VA_MoveObj ac = GetAction(simSceneIdx, simActionIdx) as VA_MoveObj;
								if (ac != null) MoveObject(ac);
								else Debug.LogError("Error while restoring Object Move actions. You need to clean the saved data before testing again.");
							}
						}
					}
				}
			}
			loading = false; // and reset it

		}

		private void RestoreBackground(string data)
		{
			string[] entries = data.Split(LoadSaveController.SPLIT_UNIT);
			if (entries.Length == 2)
			{
				simSceneIdx = -1; simActionIdx = -1;
				if (int.TryParse(entries[0], out simSceneIdx))
				{
					if (int.TryParse(entries[1], out simActionIdx))
					{
						// expect it to be VA_ChangeBackground type
						VA_ChangeBackground ac = GetAction(simSceneIdx, simActionIdx) as VA_ChangeBackground;
						if (ac != null) SetBackground(ac);
					}
				}
			}
		}

		private void RestoreCharacters(string data)
		{
			string[] records = data.Split(LoadSaveController.SPLIT_RECORD, System.StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < records.Length; i++)
			{				
				string[] entries = records[i].Split(LoadSaveController.SPLIT_UNIT);
				if (entries.Length == 4)
				{
					simSceneIdx = -1; simActionIdx = -1;
					if (int.TryParse(entries[0], out simSceneIdx))
					{
						if (int.TryParse(entries[1], out simActionIdx))
						{
							// expect it to be VA_CharaEnter type
							VA_CharaEnter ac = GetAction(simSceneIdx, simActionIdx) as VA_CharaEnter;
							if (ac != null) EnterCharacter(ac);
						}
					}

					simSceneIdx = -1; simActionIdx = -1;
					if (int.TryParse(entries[2], out simSceneIdx))
					{
						if (int.TryParse(entries[3], out simActionIdx))
						{
							// expect it to be VA_CharaPose type
							VA_CharaPose ac = GetAction(simSceneIdx, simActionIdx) as VA_CharaPose;
							if (ac != null) SetCharacterPose(ac);
						}
					}					
				}
			}

		}

		private void RestoreMusic(string data)
		{
			string[] entries = data.Split(LoadSaveController.SPLIT_UNIT);
			if (entries.Length == 2)
			{
				simSceneIdx = -1; simActionIdx = -1;
				if (int.TryParse(entries[0], out simSceneIdx))
				{
					if (int.TryParse(entries[1], out simActionIdx))
					{
						// expect it to be VA_StartMusic type
						VA_StartMusic ac = GetAction(simSceneIdx, simActionIdx) as VA_StartMusic;
						if (ac != null) StartMusic(ac);
					}
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region scene control

		public void StartNewGame()
		{
			// reset all save data helpers
			simSceneIdx = -1;
			simActionIdx = -1;
			backSetSceneIdx = -1;
			backSetActionIdx = -1;
			musicSetSceneIdx = -1;
			musicSetActionIdx = -1;
			textActionChanges = new List<ObjectSaveData>();
			imageActionChanges = new List<ObjectSaveData>();
			animActionChanges = new List<ObjectSaveData>();
			moveActionChanges = new List<ObjectSaveData>();

			// start game
			VinomaGUI.Instance.ResetPanels(true);
			ClearScenes(true);
			RunScene(0);
		}

		public void ClearScenes(bool forced)
		{
			gameObject.SetActive(true);
			VinomaGUI.Instance.ResetPanels(true);

			// reset various systems
			VinomaGUI.Instance.dialogueController.ClearAll();

			// hide panels that might be open
			VinomaGUI.Instance.dialoguePanel.SetActive(false);
			VinomaGUI.Instance.responseButtonsPanel.SetActive(false);

			// clear background
			background[0].gameObject.SetActive(false);
			background[1].gameObject.SetActive(false);
			backSetSceneIdx = -1;
			backSetActionIdx = -1;

			// clear characters
			foreach (CharacterInfo c in characters.Values) Object.Destroy(c.go);
			characters.Clear();

			// clear GameObjects
			if ((forced || asset.gameObjectsToo) && gameObjectsRoot != null)
			{
				for (int i = 0; i < gameObjectsRoot.childCount; i++)
				{
					gameObjectsRoot.GetChild(i).gameObject.SetActive(false);
				}
			}
		}

		public void RunNextScene()
		{
			if (asset.scenes.Length > activeSceneIdx + 1)
			{
				RunScene(activeSceneIdx + 1);
			}
			else
			{
				Debug.Log("Reached end of game.");
				VinomaGameGlobal.Instance.StartMenuMusic();
				VinomaGUI.Instance.ResetPanels(false);
			}
		}

		public void RunScene(int sceneIdx, int actionIdx = -1, bool preventClear = false)
		{
			// clear scene
			if (!preventClear && asset.clearOnSceneChange)
			{
				ClearScenes(false);
			}

			// run scene
			activeSceneIdx = sceneIdx;
			if (actionIdx == -1)
			{
				if (asset.scenes[sceneIdx].firstAction != null)
				{
					asset.scenes[sceneIdx].firstAction.RunAction();
				}
				else
				{
					activeSceneIdx++;
					if (activeSceneIdx >= asset.scenes.Length)
					{
						Debug.Log("Reached the end of available scenes.");
					}
					else
					{
						RunScene(activeSceneIdx);
					}
				}
			}
			else
			{
				asset.scenes[sceneIdx].actions[actionIdx].RunAction();
			}
		}

		public bool Goto(VinomaGotoOption opt, string sceneName, string labelName)
		{
			if (opt == VinomaGotoOption.SceneTop)
			{
				// goto top of active scene
				asset.scenes[activeSceneIdx].firstAction.RunAction();
			}
			else if (opt == VinomaGotoOption.SceneEnd)
			{
				// goto next scene
				activeSceneIdx++;
				if (activeSceneIdx < asset.scenes.Length)
				{
					RunScene(activeSceneIdx);
				}
				else
				{
					Debug.LogError("There was no next scene to goto.");
					return false;
				}
			}
			else if (opt == VinomaGotoOption.Label)
			{
				if (labelName.StartsWith("@"))
				{
					string vn = labelName.Substring(1);
					if (variables.ContainsKey(vn)) labelName = variables[vn];
					else Debug.LogError("Could not find Variable: " + vn);
				}

				int idx = FindLabelActionIdx(activeSceneIdx, labelName);
				if (idx >= 0)
				{
					asset.scenes[activeSceneIdx].actions[idx].RunAction();
				}
				else
				{
					Debug.LogError("The named label was not found: " + labelName);
					return false;
				}
			}
			else if (opt == VinomaGotoOption.Scene)
			{
				if (sceneName.StartsWith("@"))
				{
					string vn = sceneName.Substring(1);
					if (variables.ContainsKey(vn)) sceneName = variables[vn];
					else Debug.LogError("Could not find Variable: " + vn);
				}

				int sceneIdx = FindSceneIdxByName(sceneName);
				if (sceneIdx >= 0)
				{
					if (string.IsNullOrEmpty(labelName))
					{
						RunScene(sceneIdx);
					}
					else
					{
						if (labelName.StartsWith("@"))
						{
							string vn = labelName.Substring(1);
							if (variables.ContainsKey(vn)) labelName = variables[vn];
							else Debug.LogError("Could not find Variable: " + vn);
						}

						int idx = FindLabelActionIdx(sceneIdx, labelName);
						if (idx >= 0)
						{
							RunScene(sceneIdx, idx);
						}
						else
						{
							Debug.LogError("The label [" + labelName + "] was not found in the scene: " + sceneName);
							return false;
						}
					}
				}
				else
				{
					Debug.LogError("The named scene was not found: " + sceneName);
					return false;
				}
			}
			else
			{
				VinomaAction ac = asset.scenes[activeSceneIdx].activeAction;
				if (ac != null && ac.next != null) ac.next.RunAction();
			}

			return true;
		}

		private int FindSceneIdxByName(string name)
		{
			if (!string.IsNullOrEmpty(name))
			{
				for (int i = 0; i < asset.scenes.Length; i++)
				{
					if (name.Equals(asset.scenes[i].name))
					{
						return i;
					}
				}
			}
			return -1;
		}

		private int FindLabelActionIdx(int sceneId, string name)
		{
			if (!string.IsNullOrEmpty(name))
			{
				for (int i = 0; i < asset.scenes[sceneId].actions.Length; i++)
				{
					VA_Label ac = asset.scenes[sceneId].actions[i] as VA_Label;
					if (ac != null && name.Equals(ac.labelName)) return i;
				}
			}
			return -1;
		}

		public bool DoBranch(VinomaBranchDef[] defs)
		{
			if (defs == null || defs.Length == 0) return false;

			// find the 1st branch which the conditions for are met
			for (int i =0; i < defs.Length; i++)
			{
				bool res = false;
				for (int j = 0; j < defs[i].conditions.Length; j++)
				{
					bool thisRes = false;
					VinomaConditionDef c = defs[i].conditions[j];

					if (c.chectType == VinomaConditionCheck.Switch)
					{
						bool val = false; // if switch not found then assumed to be false (off)
						if (switches.ContainsKey(c.opt1)) val = switches[c.opt1];
						else Debug.LogWarning(string.Format("Switch [{0}] not found. Assuming an Off state.", c.opt1));

						if ((c.swOpt == VinomaSwitchCondition.IsOff && val == false) ||
							(c.swOpt == VinomaSwitchCondition.IsOn && val == true)) thisRes = true;
					}
					else
					{
						string val = "";
						if (variables.ContainsKey(c.opt1)) val = variables[c.opt1];
						else Debug.LogWarning(string.Format("Variable [{0}] not found. Assuming an empty/ zero value.", c.opt1));

						if (c.varOpt == VinomaVarCondition.EqualTo || c.varOpt == VinomaVarCondition.NotEqualTo)
						{
							switch (c.varOpt)
							{
								case VinomaVarCondition.EqualTo: thisRes = (val == c.opt2); break;
								case VinomaVarCondition.NotEqualTo: thisRes = (val != c.opt2); break;
							}
						}
						else
						{
							float f1 = 0f, f2 = 0f;
							float.TryParse(val, out f1);
							float.TryParse(c.opt2, out f2);
							switch (c.varOpt)
							{
								case VinomaVarCondition.BiggerThan: thisRes = (f1 > f2); break;
								case VinomaVarCondition.BiggerThanOrEqual: thisRes = (f1 >= f2); break;
								case VinomaVarCondition.SmallerThan: thisRes = (f1 < f2); break;
								case VinomaVarCondition.SmallerThanOrEqual: thisRes = (f1 <= f2); break;
							}
						}
					}

					if (j == 0) res = thisRes;
					else
					{
						if (c.combine == VinomaConditionCombine.And) res = res && thisRes;
						else if (c.combine == VinomaConditionCombine.Or) res = res || thisRes;
					}
				}

				if (res == true)
				{	// condition was met
					return Goto(defs[i].goOpt, defs[i].sceneName, defs[i].labelName);
				}
			}

			return false;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region background

		public void SetBackground(VA_ChangeBackground ac)
		{
			if (loading)
			{
				backSetSceneIdx = simSceneIdx;
				backSetActionIdx = simActionIdx;
			}
			else
			{
				backSetSceneIdx = activeSceneIdx;
				backSetActionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			}

			if (!loading && ac.fadeEasing.time > 0.0f)
			{
				if (backgroundFadeTween != null)
				{
					// the previous fade this not yet complete. set background[0] to
					// the previous one before starting the new fade
					backgroundFadeTween.Kill(true);
					backgroundFadeTween = null;
					OnBackgroundFadeComplete();
				}

				background[1].gameObject.SetActive(true);
				background[1].sprite = ac.image;
				background[1].color = new Color(1f, 1f, 1f, 0f);
				backgroundScaler[1].Rescale(ac.scaleType);
				backgroundFadeTween = DOTween.ToAlpha(() => background[1].color, c => background[1].color = c, 1f, ac.fadeEasing.time).SetEase(ac.fadeEasing.ease).OnComplete(OnBackgroundFadeComplete);
			}
			else
			{
				background[1].gameObject.SetActive(false);
				background[0].gameObject.SetActive(true);
				background[0].sprite = ac.image;
				background[0].color = Color.white;
				backgroundScaler[0].Rescale(ac.scaleType);
				UpdateEdgeOffset();
			}
		}

		private void OnBackgroundFadeComplete()
		{
			backgroundFadeTween = null;
			background[0].gameObject.SetActive(true);
			background[0].sprite = background[1].sprite;
			background[0].color =  background[1].color;
			backgroundScaler[0].transform.localScale = backgroundScaler[1].transform.localScale;
			background[1].gameObject.SetActive(false);
			background[1].sprite = null;
			UpdateEdgeOffset();
		}

		private void UpdateEdgeOffset()
		{
			VinomaGUI.Instance.ReziseUI(background[0]);

			if (asset.sceneBorder == VinomaWidthAdapt.Background)
			{
				edgeOffs = (cam.orthographicSize * cam.aspect) - background[0].bounds.extents.x;
				if (edgeOffs < 0.0f) edgeOffs = 0f;
				AdjustCharacterPositions();
			}
			else if (asset.sceneBorder == VinomaWidthAdapt.Design)
			{
				float ratio = (float)asset.designWidth / (float)asset.designHeight;
				edgeOffs = (cam.orthographicSize * cam.aspect) - (cam.orthographicSize * ratio);
				if (edgeOffs < 0.0f) edgeOffs = 0f;
				AdjustCharacterPositions();
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region characters

		public void EnterCharacter(VA_CharaEnter ac)
		{
			if (ac.characterFab == null) return;

			if (characters.ContainsKey(ac.characterName))
			{
				Debug.LogError("The character is already present in the scene: " + ac.characterName);
				return;
			}

			// create the character
			GameObject go = (GameObject)Instantiate(ac.characterFab);
			go.name = ac.characterName;
			go.transform.parent = charactersRoot;

			SpriteRendererFadeGroup[] fadeGroup = new SpriteRendererFadeGroup[go.transform.childCount + 1];
			fadeGroup[0] = go.AddComponent<SpriteRendererFadeGroup>();
			for (int i = 0; i < go.transform.childCount; i++)
			{
				fadeGroup[i + 1] = go.transform.GetChild(i).gameObject.AddComponent<SpriteRendererFadeGroup>();
			}

			CharacterInfo chara = new CharacterInfo();
			characters.Add(ac.characterName, chara);

			chara.name = ac.characterName;
			chara.go = go;
			chara.fadeGroup = fadeGroup;

			if (loading)
			{
				chara.enter_sceneIdx = simSceneIdx;
				chara.enter_actionIdx = simActionIdx;
			}
			else
			{
				chara.enter_sceneIdx = activeSceneIdx;
				chara.enter_actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			}

			if (ac.mirror)
			{
				go.transform.localScale = new Vector3(go.transform.localScale.x * -1f, go.transform.localScale.y, go.transform.localScale.z);
			}

			// set up the sort layer and pose
			SetCharacterSortOrder(ac.characterName, ac.sortOrder, ac.customSortOrder);
			SetCharacterPose(chara, ac.poseName, null);

			// create a fade
			if (!loading && ac.fadeEasing.time > 0.0f)
			{
				chara.fadeGroup[0].Fade(1f, ac.fadeEasing.time, ac.fadeEasing.ease, true, 0f);
			}

			// calculate and reposition all the characters. this will start tweens for the existing characters
			// and return the final position for the new one so that it can be moved with own special tween
			Vector3 charaPos = AdjustCharacterPositions(chara, ac.offset.isUsed ? ac.offset : go.transform.position, ac.sceneLocation, ac.customLocation.value);

			// now move the new character
			if (!loading && ac.enterFrom != VinomaSceneSide.InPlace && ac.moveEasing.time > 0.0f)
			{
				go.transform.position = CalculateSceneSidePosition(charaPos, chara.sprite, ac.enterFrom);
				if (chara.moveTween != null) chara.moveTween.Kill(true);
				chara.moveTween = DOTween.To(() => go.transform.position, p => go.transform.position = p, charaPos, ac.moveEasing.time).SetEase(ac.moveEasing.ease);
			}
			else
			{
				go.transform.position = charaPos;
			}

		}

		public void ExitCharacter(string charaName, VinomaSceneSide exitTo, plyEasing moveEasing, plyEasing fadeEasing)
		{
			if (!characters.ContainsKey(charaName))
			{
				Debug.LogError("The character is not present in the scene: " + charaName);
				return;
			}

			CharacterInfo chara = characters[charaName];
			characters.Remove(charaName);

			float t = 0.0f;
			if (fadeEasing.time > 0.0f)
			{
				t = fadeEasing.time + 0.1f;
				chara.fadeGroup[0].Fade(0f, fadeEasing.time, fadeEasing.ease);
			}

			if (exitTo != VinomaSceneSide.InPlace)
			{
				if (moveEasing.time > t) t = moveEasing.time + 0.1f;
				Vector3 dest = CalculateSceneSidePosition(chara.pos, chara.sprite, exitTo);
				if (chara.moveTween != null) chara.moveTween.Kill(true);
				chara.moveTween = DOTween.To(() => chara.go.transform.position, p => chara.go.transform.position = p, dest, moveEasing.time).SetEase(moveEasing.ease);
			}

			Object.Destroy(chara.go, t);
		}

		public void SetCharacterSortOrder(string charaName, VinomaSceneSortOrder opt, int order)
		{
			CharacterInfo chara;
			if (!characters.TryGetValue(charaName, out chara))
			{
				Debug.LogError("The character is not present in the scene: " + charaName);
				return;
			}

			if (opt != VinomaSceneSortOrder.Custom)
			{
				int lowest = 0;
				int highest = 0;
				foreach (CharacterInfo c in characters.Values)
				{
					if (c != chara)
					{
						if (c.sortOrder < lowest) lowest = c.sortOrder;
						if (c.sortOrder > highest) highest = c.sortOrder;
					}
				}

				// below I div 10 to get it back to base value since I multiply character
				// order by 10 to get good separation between different characters
				if (opt == VinomaSceneSortOrder.Back)
				{
					order = lowest / 10;		
					order--;
				}
				else if (opt == VinomaSceneSortOrder.Front)
				{
					order = highest / 10;
					order++;
				}
			}

			chara.sortOrder = order * 10;
	
			// setup the sorting layers
			Renderer ren = chara.go.GetComponent<Renderer>();
			if (ren != null)
			{
				ren.sortingLayerName = VinomaGameGlobal.SortLayer.Character;
				ren.sortingOrder = chara.sortOrder;
			}

			ply2D.UpdateSpriteSortOrderRecursive(chara.go.transform, VinomaGameGlobal.SortLayer.Character, chara.sortOrder);

		}

		public void SetCharacterPose(VA_CharaPose ac)
		{
			CharacterInfo chara = null;
			if (!characters.TryGetValue(ac.characterName, out chara))
			{
				Debug.LogError("The character is not present in the scene: " + ac.characterName);
				return;
			}

			if (loading)
			{
				chara.pose_sceneIdx = simSceneIdx;
				chara.pose_actionIdx = simActionIdx;
				SetCharacterPose(chara, ac.poseName, null);
			}
			else
			{
				chara.pose_sceneIdx = activeSceneIdx;
				chara.pose_actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
				SetCharacterPose(chara, ac.poseName, ac.fadeEasing);
			}
			
		}

		private void SetCharacterPose(CharacterInfo chara, string poseName, plyEasing fade)
		{
			if (chara.mainSpriteIsInPose == false && chara.sprite == null)
			{
				chara.sprite = chara.go.GetComponent<SpriteRenderer>();
				if (chara.sprite == null) chara.mainSpriteIsInPose = true;
			}

			if (chara.mainSpriteIsInPose)
			{
				chara.sprite = null; // so that when pose changes, the main sprite will be updated
			}

			if (fade != null)
			{	// if going to do fades then make sure main is not active
				chara.fadeGroup[0].Stop();
			}

			Transform parent = chara.go.transform;
			for (int i = 0; i < parent.childCount; i++)
			{
				Transform tr = parent.GetChild(i);
				if (tr.name.Equals(poseName))
				{
					if (chara.sprite == null) chara.sprite = tr.GetComponent<SpriteRenderer>();
					tr.gameObject.SetActive(true);
					if (fade != null)
					{
						chara.fadeGroup[i+1].Fade(1f, fade.time, fade.ease, true, 0f);
					}
				}
				else
				{
					if (tr.gameObject.activeSelf)
					{
						if (fade == null) tr.gameObject.SetActive(false);
						else chara.fadeGroup[i+1].Fade(0f, fade.time, fade.ease);
					}
				}
			}

			chara.padding = FloatRectOffset.zero;
			if (chara.sprite != null)
			{
				SpritePadding sp = chara.sprite.GetComponent<SpritePadding>();
				if (sp != null) chara.padding = sp.padding;
			}
		}

		private Vector3 AdjustCharacterPositions(CharacterInfo newChara, Vector3 offs, VinomaSceneLocation location, Vector2 customPos)
		{
			newChara.pos = offs;
			float w = cam.orthographicSize * cam.aspect;
			w -= edgeOffs;

			// if no other characters in scene yet then simply put in a 
			// location that was chosen without moving other
			switch (location)
			{
				case VinomaSceneLocation.Left: { newChara.pos.x -= newChara.Width(); } break;
				case VinomaSceneLocation.Right: { newChara.pos.x += newChara.Width(); } break;
				case VinomaSceneLocation.Custom: { newChara.pos = new Vector3(newChara.pos.x + customPos.x, newChara.pos.y + customPos.y, newChara.pos.z); } break;
			}

			if (characters.Count > 1)
			{	// when there are other characters in the scene then they might have to be moved
				// create a list sorted by the characters' x positions but leave out the 
				// character that is new to the scene since it will be added later
				List<CharacterInfo> cs = new List<CharacterInfo>();
				foreach (CharacterInfo c in characters.Values) if (c != newChara) cs.Add(c);
				cs.Sort((a, b) => { return a.pos.x.CompareTo(b.pos.x); });

				float totalWidth = 0f;
				bool detectedMoves = false;

				switch (location)
				{
					case VinomaSceneLocation.Left: 
					{
						// insert the new character to the left and then check if it needs to push any to the right
						cs.Insert(0, newChara);
						for (int i = 0; i < cs.Count; i++)
						{
							totalWidth += cs[i].Width();
							if (i < cs.Count - 1)
							{
								float f = (cs[i].Left() + cs[i].Width()) - cs[i + 1].Left();
								if (f > 0.0f)
								{
									cs[i + 1].pos.x += f;
									cs[i + 1]._move = true;
									detectedMoves = true;
								}
							}
						}
					} break;

					case VinomaSceneLocation.Right:
					{
						// insert the new character to the right and then check if it needs to push any to the left
						cs.Add(newChara);
						for (int i = cs.Count - 1; i >= 0; i--)
						{
							totalWidth += cs[i].Width();
							if (i < cs.Count - 1)
							{
								float f = (cs[i + 1].Left() - cs[i].Right());
								if (f < 0.0f)
								{
									cs[i].pos.x += f;
									cs[i]._move = true;
									detectedMoves = true;
								}
							}
						}
					} break;

					case VinomaSceneLocation.Middle:
					{
						// insert the new character in the middle and then push other to left and right
						int idx = cs.Count / 2;
						cs.Insert(idx, newChara);
						// character to the right
						for (int i = idx; i < cs.Count; i++)
						{
							totalWidth += cs[i].Width();
							if (i < cs.Count - 1)
							{
								float f = (cs[i].Left() + cs[i].Width()) - cs[i + 1].Left();
								if (f > 0.0f)
								{
									cs[i + 1].pos.x += f;
									cs[i + 1]._move = true;
									detectedMoves = true;
								}
							}
						}
						// characters to the left
						for (int i = idx - 1; i >= 0; i--)
						{
							totalWidth += cs[i].Width();
							if (i < cs.Count - 1)
							{
								float f = (cs[i + 1].Left() - cs[i].Right());
								if (f < 0.0f)
								{
									cs[i].pos.x += f;
									cs[i]._move = true;
									detectedMoves = true;
								}
							}
						}

					} break;
				}

				// now check if all fit in view and if not they need to be shifted and overlapped so that all fit
				if (cs[0].Left() < -w || (cs[0].Left() + totalWidth) > w)
				{
					float shift = totalWidth - (w * 2);
					shift = shift / (cs.Count - 1);
					cs[0].pos.x = -w + (cs[0].Width() / 2f);
					cs[0]._move = true;
					detectedMoves = true;
					for (int i = 1; i < cs.Count; i++)
					{
						cs[i].pos.x = cs[i - 1].Right() + (cs[i].Width() / 2f) - shift;
						cs[i]._move = true;
					}
				}

				// start moves on characters that should move (except for the new character as it uses different tween)
				if (detectedMoves)
				{
					float time = 0.2f;
					for (int i = 0; i < cs.Count; i++)
					{
						if (cs[i]._move && cs[i] != newChara)
						{
							int a = i;
							time += 0.1f;
							cs[i]._move = false;
							if (cs[a].moveTween != null) cs[a].moveTween.Kill(true);
							cs[a].moveTween = DOTween.To(() => cs[a].go.transform.position, p => cs[a].go.transform.position = p, cs[a].pos, time);
						}
					}
				}
			}

			return newChara.pos;
		}

		private void AdjustCharacterPositions()
		{
			if (characters.Count == 0) return;

			float w = cam.orthographicSize * cam.aspect;
			w -= edgeOffs;

			float totalWidth = 0f;
			bool detectedMoves = false;
			List<CharacterInfo> cs = new List<CharacterInfo>();
			foreach (CharacterInfo c in characters.Values)
			{
				cs.Add(c);
				totalWidth += c.Width();
			}
			cs.Sort((a, b) => { return a.pos.x.CompareTo(b.pos.x); });
			
			// now check if all fit in view and if not they need to be shifted and overlapped so that all fit
			if (cs[0].Left() < -w || (cs[0].Left() + totalWidth) > w)
			{
				float shift = totalWidth - (w * 2);
				shift = shift / (cs.Count - 1);
				cs[0].pos.x = -w + (cs[0].Width() / 2f);
				cs[0]._move = true;
				detectedMoves = true;
				for (int i = 1; i < cs.Count; i++)
				{
					cs[i].pos.x = cs[i - 1].Right() + (cs[i].Width() / 2f) - shift;
					cs[i]._move = true;
				}
			}

			// start moves on characters that should move (except for the new character as it uses different tween)
			if (detectedMoves)
			{
				float time = 0.2f;
				for (int i = 0; i < cs.Count; i++)
				{
					if (cs[i]._move)
					{
						int a = i;
						time += 0.1f;
						cs[i]._move = false;
						if (cs[a].moveTween != null) cs[a].moveTween.Kill(true);
						cs[a].moveTween = DOTween.To(() => cs[a].go.transform.position, p => cs[a].go.transform.position = p, cs[a].pos, time);
					}
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region music and sound

		public void StartMusic(VA_StartMusic ac)
		{
			if (loading)
			{
				musicSetSceneIdx = simSceneIdx;
				musicSetActionIdx = simActionIdx;
			}
			else
			{
				musicSetSceneIdx = activeSceneIdx;
				musicSetActionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			}

			VinomaGameGlobal.Instance.StartMusic(ac.clip, ac.loop, ac.fadeEasing);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region variable and switch

		public void PerformOperationOnVariable(string varName, string value, string value2, VinomaVarOperation opt)
		{
			string res = "";
			if (variables.ContainsKey(varName)) res = variables[varName];
			else variables.Add(varName, "");

			if (value.StartsWith("@"))
			{
				string vn = value.Substring(1);
				if (variables.ContainsKey(vn)) value = variables[vn];
				else Debug.LogError("Could not find Variable: " + vn);
			}

			if (opt == VinomaVarOperation.Set)
			{
				res = value;
			}
			else if (opt == VinomaVarOperation.Append)
			{
				res += value;
			}
			else if (opt == VinomaVarOperation.Random)
			{
				if (value2.StartsWith("@"))
				{
					string vn = value2.Substring(1);
					if (variables.ContainsKey(vn)) value2 = variables[vn];
					else Debug.LogError("Could not find Variable: " + vn);
				}

				if (value.Contains(".") || value2.Contains("."))
				{
					float v1 = 0f;
					float v2 = 0f;
					float.TryParse(value, out v1);
					float.TryParse(value2, out v2);
					res = (v1 < v2 ? Random.Range(v1, v2).ToString() : Random.Range(v2, v1).ToString());
				}
				else
				{
					int v1 = 0;
					int v2 = 0;
					int.TryParse(value, out v1);
					int.TryParse(value2, out v2);
					res = (v1 < v2 ? Random.Range(v1, v2+1).ToString() : Random.Range(v2, v1+1).ToString());
				}

			}
			else
			{
				float f1 = 0f;
				float f2 = 0f;
				float.TryParse(res, out f1);
				float.TryParse(value, out f2);
				switch (opt)
				{
					case VinomaVarOperation.Add: res = (f1 + f2).ToString(); break;
					case VinomaVarOperation.Subtract: res = (f1 - f2).ToString(); break;
					case VinomaVarOperation.Multiply: res = (f1 * f2).ToString(); break;
					case VinomaVarOperation.Divide: res = f1 == 0f || f2 == 0 ? "0" : (f1 / f2).ToString(); break;
				}
			}

			variables[varName] = res;
			if (variableLinks.ContainsKey(varName)) variableLinks[varName](res);
		}

		public void PerformOperationOnSwitch(string switchName, VinomaSwitchOperation opt)
		{
			if (!switches.ContainsKey(switchName)) switches.Add(switchName, false);
			
			switch (opt)
			{
				case VinomaSwitchOperation.On: switches[switchName] = true; break;
				case VinomaSwitchOperation.Off: switches[switchName] = false; break;
				case VinomaSwitchOperation.Toggle: switches[switchName] = !switches[switchName]; break;
			}

			if (switcheLinks.ContainsKey(switchName)) switcheLinks[switchName](switches[switchName]);
		}

		public bool TryGetVariableValue(string name, out string value)
		{
			return variables.TryGetValue(name, out value);
		}

		public bool TryGetSwitchState(string name, out bool value)
		{
			return switches.TryGetValue(name, out value);
		}

		public void LinkToVariable(string name, System.Action<string> onValueChange)
		{
			if (string.IsNullOrEmpty(name))
			{
				Debug.LogError("The Variable name must be set to create a link with it.");
				return;
			}

			if (!variableLinks.ContainsKey(name)) variableLinks.Add(name, null);
			variableLinks[name] -= onValueChange;
			variableLinks[name] += onValueChange;

			string v = null;
			if (TryGetVariableValue(name, out v)) onValueChange(v);
		}

		public void UnlinkFromVariable(string name, System.Action<string> onValueChange)
		{
			if (!variableLinks.ContainsKey(name)) return;
			variableLinks[name] -= onValueChange;
		}

		public void LinkToSwitch(string name, System.Action<bool> onValueChange)
		{
			if (string.IsNullOrEmpty(name))
			{
				Debug.LogError("The Switch name must be set to create a link with it.");
				return;
			}

			if (!switcheLinks.ContainsKey(name)) switcheLinks.Add(name, null);
			switcheLinks[name] -= onValueChange;
			switcheLinks[name] += onValueChange;

			bool v = false;
			if (TryGetSwitchState(name, out v)) onValueChange(v);
		}

		public void UnlinkFromSwitch(string name, System.Action<bool> onValueChange)
		{
			if (!switcheLinks.ContainsKey(name)) return;
			switcheLinks[name] -= onValueChange;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region hotspots

		public void SetHotspotsOverlay(VA_Hotspots ac, System.Action callback)
		{
			if (ac.opt == VinomaEnableOption.Disable)
			{
				if (hotspots.ContainsKey(ac.overlayIdent))
				{
					Destroy(hotspots[ac.overlayIdent].obj);
					hotspots.Remove(ac.overlayIdent);
				}
				else Debug.LogWarning("Trying to disable hotspots overlay that is not active.");
				return;
			}

			if (hotspots.ContainsKey(ac.overlayIdent))
			{
				Debug.LogWarning("Trying to activate a hotspots overlay that is already active: " + hotspots[ac.overlayIdent].overlay.name);
				return;
			}

			VinomaHotspotsOverlay ov = asset.GetHotspotOverlay(ac.overlayIdent);
			if (ov == null)
			{
				Debug.LogError("The hotspots overlay definition could not be found. You might have removed it after having selected it in an action.");
				return;
			}

			HotspotOverlayInfo nfo = new HotspotOverlayInfo();
			nfo.obj = new GameObject(ov.name);
			nfo.obj.transform.parent = hotspotsRoot;
			nfo.overlay = ov;
			nfo.autoDisable = ac.autoDisable;
			nfo.waiting = ac.wait;
			nfo.callback = callback;
			hotspots.Add(ac.overlayIdent, nfo);

			float pixelsPerUnit = asset.pixelsPerUnit;
			float xRatio = 1f;
			float yRatio = 1f;
			float xRef = 0f;
			float yRef = 0f;

			if (ac.refScale == VinomaWidthAdapt.Background)
			{
				if (background[1] != null && background[1].sprite != null)
				{
					pixelsPerUnit = background[1].sprite.pixelsPerUnit;
					xRatio = background[1].bounds.size.x / background[1].sprite.bounds.size.x;
					yRatio = background[1].bounds.size.y / background[1].sprite.bounds.size.y;
					xRef = background[1].bounds.size.x / 2f;
					yRef = background[1].bounds.size.y / 2f;
				}
				else if (background[0] != null && background[0].sprite != null)
				{
					pixelsPerUnit = background[0].sprite.pixelsPerUnit;
					xRatio = background[0].bounds.size.x / background[0].sprite.bounds.size.x;
					yRatio = background[0].bounds.size.y / background[0].sprite.bounds.size.y;
					xRef = background[0].bounds.size.x / 2f;
					yRef = background[0].bounds.size.y / 2f;
				}
			}
			else if (ac.refScale == VinomaWidthAdapt.Design)
			{
				xRef = Screen.width * (asset.designWidth / asset.designHeight / cam.aspect);
				yRef = Screen.height;
				xRatio = Screen.width / xRef;
				yRatio = Screen.height / yRef;
				xRef = xRef / 2f / pixelsPerUnit;
				yRef = yRef / 2f / pixelsPerUnit;
			}
			else if (ac.refScale == VinomaWidthAdapt.Screen)
			{
				xRef = Screen.width / 2f / pixelsPerUnit;
				yRef = Screen.height / 2f / pixelsPerUnit;
			}

			for (int i = 0; i < ov.hotspots.Length; i++)
			{
				VinomaHotspot hs = ov.hotspots[i];

				GameObject go = new GameObject("Hotspot " + (i+1).ToString());
				go.transform.parent = nfo.obj.transform;
				VinomaHotspotObj obj = go.AddComponent<VinomaHotspotObj>();
				obj.overlayIdent = ac.overlayIdent;
				obj.hs = hs;
				obj.onClick = OnHotspotClick;

				BoxCollider2D coll = go.AddComponent<BoxCollider2D>();
				coll.size = new Vector2(hs.position.width / pixelsPerUnit * xRatio, hs.position.height / pixelsPerUnit * yRatio);
				go.transform.position = new Vector3(
					(hs.position.x / pixelsPerUnit * xRatio) - xRef + (coll.size.x / 2f),
					(hs.position.y / pixelsPerUnit * yRatio) - yRef + (coll.size.y / 2f), 
					0f);

				if (hs.hoverSprite != null)
				{
					SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
					sr.sprite = hs.hoverSprite;
					sr.enabled = false;
					sr.sortingLayerName = VinomaGameGlobal.SortLayer.Background;
					sr.sortingOrder = 3;
				}
			}
		}

		private void OnHotspotClick(int overlayIdent, VinomaHotspot hs)
		{
			if (hs == null)
			{
				Debug.LogError("The Hotspot data is null.");
				return;
			}

			HotspotOverlayInfo nfo = hotspots[overlayIdent];
			if (nfo.autoDisable && nfo.obj != null)
			{
				Destroy(nfo.obj);
				hotspots.Remove(overlayIdent);
			}

			//List<VinomaActionOptDef> gotoActs = new List<VinomaActionOptDef>();
			//for (int i = 0; i < hs.Actions.Length; i++)
			//{
			//	if (hs.Actions[i].act == VinomaActionOptDef.Action.Goto)
			//	{	// goto actions should be performed last so collect and perform later
			//		gotoActs.Add(hs.Actions[i]);
			//	}
			//	else
			//	{
			//		if (hs.Actions[i].act == VinomaActionOptDef.Action.Variable)
			//		{
			//			VinomaSceneController.Instance.PerformOperationOnVariable(hs.Actions[i].s_opt1, hs.Actions[i].s_opt2, hs.Actions[i].varOpt);
			//		}
			//		else if (hs.Actions[i].act == VinomaActionOptDef.Action.Variable)
			//		{
			//			VinomaSceneController.Instance.PerformOperationOnSwitch(hs.Actions[i].s_opt1, hs.Actions[i].swOpt);
			//		}
			//	}
			//}

			//if (gotoActs.Count > 0)
			//{
			//	if (gotoActs.Count > 1) Debug.LogWarning("There can be only one goto action in a hotspot. The first one will now be performed and the rest ignored.");
			//	VinomaSceneController.Instance.Goto(gotoActs[0].goOpt, gotoActs[0].s_opt1, gotoActs[0].s_opt2);
			//}
			//else if (nfo.waiting && nfo.callback != null) nfo.callback();

			if (PerformActions(hs.actions) == false)
			{
				if (nfo.waiting && nfo.callback != null) nfo.callback();
			}
		}

		public bool PerformActions(VinomaActionOptDef[] actions)
		{
			List<VinomaActionOptDef> gotoActs = new List<VinomaActionOptDef>();
			for (int i = 0; i < actions.Length; i++)
			{
				if (actions[i].act == VinomaActionOptDef.Action.Goto)
				{   // goto actions should be performed last so collect and perform later
					gotoActs.Add(actions[i]);
				}
				else
				{
					if (actions[i].act == VinomaActionOptDef.Action.Variable)
					{
						VinomaSceneController.Instance.PerformOperationOnVariable(actions[i].s_opt1, actions[i].s_opt2, actions[i].s_opt3, actions[i].varOpt);
					}
					else if (actions[i].act == VinomaActionOptDef.Action.Variable)
					{
						VinomaSceneController.Instance.PerformOperationOnSwitch(actions[i].s_opt1, actions[i].swOpt);
					}
				}
			}

			if (gotoActs.Count > 0)
			{
				if (gotoActs.Count > 1) Debug.LogWarning("There can be only one goto action in a hotspot. The first one will now be performed and the rest ignored.");
				VinomaSceneController.Instance.Goto(gotoActs[0].goOpt, gotoActs[0].s_opt1, gotoActs[0].s_opt2);
			}
			else
			{
				return false;
			}

			return true;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public void CallFunction(string functionName)
		{
			if (customScriptsObject == null)
			{
				Debug.LogError("There is no 'CustomScripts' object in the scene. All custom scripts must be attached to the game object named, CustomScript.");
				return;
			}

			if (functionName.StartsWith("@"))
			{
				string vn = functionName.Substring(1);
				if (variables.ContainsKey(vn)) functionName = variables[vn];
				else Debug.LogError("Could not find Variable: " + vn);
			}

			customScriptsObject.SendMessage(functionName);
		}

		public string ParseTextForVariables(string text)
		{
			if (string.IsNullOrEmpty(text)) return "";

			int start = text[0] == '_' ? 0 : text.IndexOf(VarInTextHelper[0]); // " _"
			int end;
			while (start >= 0)
			{
				end = text.IndexOf(VarInTextHelper[2], start + 2); //  // "_\n" check if followed by new-line
				if (end < 0)
				{
					end = text.IndexOf(VarInTextHelper[1], start + 2); // "_ "
					if (end < 0)
					{
						end = text.IndexOf(VarInTextHelper[3], start + 2);	// "_" check if at end of text
						if (end != (text.Length - 1)) end = -1; // if not then make this _xxx_ invalid
					}
				}

				if (end > start)
				{
					string varName = (start == 0 ? text.Substring(start + 1, end - start - 1) : text.Substring(start + 2, end - start - 2));
					string val = "";
					if (variables.TryGetValue(varName, out val))
					{
						if (start == 0) text = val + text.Substring(end + 1);
						else text = text.Substring(0, start + 1) + val + text.Substring(end + 1);
						end = start + 1 + val.Length;
					}
					else Debug.LogError("The variable is not defined: " + varName);
					if (end >= text.Length) break;
					start = text.IndexOf(VarInTextHelper[0], end); // " _"
				}
				else
				{
					start = text.IndexOf(VarInTextHelper[0], start + 2); // " _"
				}
			}
			
			return text;
		}

		public void SetUIText(VA_UIText ac)
		{
			if (ac.target == null)
			{
				Debug.LogError("[SetUIText] Target object is not set.");
				return;
			}

			Text tx = ac.target.GetComponent<Text>();
			if (tx != null)
			{
				tx.text = VinomaSceneController.Instance.ParseTextForVariables(ac.text);

				// record action for saving
				ObjectSaveData save = null;
				for (int i = 0; i < textActionChanges.Count; i++)
				{
					if (textActionChanges[i].target == ac.target)
					{				
						save = textActionChanges[i]; break;
					}
				}

				if (save == null)
				{
					save = new ObjectSaveData();
					textActionChanges.Add(save);
					save.target = ac.target;
				}

				if (loading)
				{
					save.sceneIdx = simSceneIdx;
					save.actionIdx = simActionIdx;
				}
				else
				{
					save.sceneIdx = activeSceneIdx;
					save.actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
				}

			}
			else Debug.LogError("The target object does not have a Text component on it: " + ac.target.name);
		}

		public void SetImage(VA_SetImage ac)
		{
			if (ac.target == null)
			{
				Debug.LogError("[SetImage] Target object not set.");
				return;
			}

			Image img = ac.target.GetComponent<Image>();
			if (img != null)
			{
				if (!loading && ac.fadeEasing.time > 0.0f)
				{
					if (ac.sp == null)
					{
						DOTween.ToAlpha(() => img.color, c => img.color = c, 0f, ac.fadeEasing.time).SetEase(ac.fadeEasing.ease);
					}
					else
					{
						img.color = new Color(img.color.r, img.color.g, img.color.b, 0f);
						img.sprite = ac.sp;
						DOTween.ToAlpha(() => img.color, c => img.color = c, 1f, ac.fadeEasing.time).SetEase(ac.fadeEasing.ease);
					}
				}
				else
				{
					img.sprite = ac.sp;
					if (img.color.a != 1f) img.color = new Color(img.color.r, img.color.g, img.color.b, 1f);
				}
			}
			else
			{
				SpriteRenderer ren = ac.target.GetComponent<SpriteRenderer>();
				if (ren != null)
				{
					if (!loading && ac.fadeEasing.time > 0.0f)
					{
						if (ac.sp == null)
						{
							DOTween.ToAlpha(() => ren.color, c => ren.color = c, 0f, ac.fadeEasing.time).SetEase(ac.fadeEasing.ease);
						}
						else
						{
							ren.color = new Color(ren.color.r, ren.color.g, ren.color.b, 0f);
							ren.sprite = ac.sp;
							DOTween.ToAlpha(() => ren.color, c => ren.color = c, 1f, ac.fadeEasing.time).SetEase(ac.fadeEasing.ease);
						}
					}
					else
					{
						ren.sprite = ac.sp;
						if (ren.color.a != 1f) ren.color = new Color(ren.color.r, ren.color.g, ren.color.b, 1f);
					}
				}
				else
				{
					Debug.LogError("[SetImage] The target object does not have an Image or SpriteRenderer component on it: " + ac.target.name);
					return;
				}
			}

			// record action for saving
			ObjectSaveData save = null;
			for (int i = 0; i < imageActionChanges.Count; i++)
			{
				if (imageActionChanges[i].target == ac.target)
				{
					save = imageActionChanges[i]; break;
				}
			}
			if (save == null)
			{
				save = new ObjectSaveData();
				imageActionChanges.Add(save);
				save.target = ac.target;
			}

			if (loading)
			{
				save.sceneIdx = simSceneIdx;
				save.actionIdx = simActionIdx;
			}
			else
			{
				save.sceneIdx = activeSceneIdx;
				save.actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			}
		}

		public void PlayAnimation(VA_Animation ac)
		{
			if (string.IsNullOrEmpty(ac.aniName))
			{
				Debug.LogError("[PlayAnimation] The Animation/ State name is not set.");
				return;
			}

			GameObject target = null;
			if (ac.opt == VinomaTargetObject.Object)
			{
				if (ac.targetObj == null)
				{
					Debug.LogError("[PlayAnimation] The target object is not set.");
					return;
				}

				target = ac.targetObj;
			}
			else
			{
				CharacterInfo chara;
				if (!characters.TryGetValue(ac.targetChara, out chara))
				{
					Debug.LogError("[PlayAnimation] The character is not present in the scene: " + ac.targetChara);
					return;
				}

				target = chara.go;
			}


			Animator ani = target.GetComponent<Animator>();
			if (ani == null)
			{
				Debug.LogError("[PlayAnimation] The target object or character does not have an Animator component on it.");
				return;
			}

			ani.Play(ac.aniName);

			// record action for saving
			ObjectSaveData save = null;
			for (int i = 0; i < animActionChanges.Count; i++)
			{
				if (ac.opt == VinomaTargetObject.Object)
				{
					if (animActionChanges[i].target == ac.targetObj)
					{
						save = animActionChanges[i]; break;
					}
				}
				else if (ac.opt == VinomaTargetObject.Character)
				{
					if (animActionChanges[i].charaName == ac.targetChara)
					{
						save = animActionChanges[i]; break;
					}
				}
			}

			if (save == null)
			{
				save = new ObjectSaveData();
				animActionChanges.Add(save);
				if (ac.opt == VinomaTargetObject.Object) save.target = ac.targetObj;
				else if (ac.opt == VinomaTargetObject.Character) save.charaName = ac.targetChara;
			}

			if (loading)
			{
				save.sceneIdx = simSceneIdx;
				save.actionIdx = simActionIdx;
			}
			else
			{
				save.sceneIdx = activeSceneIdx;
				save.actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			}
		}

		public void MoveObject(VA_MoveObj ac)
		{
			if (ac.targetObj == null)
			{
				Debug.LogError("[MoveObject] No object specified.");
				return;
			}

			if (ac.targetTr == null)
			{
				Debug.LogError("[MoveObject] No target position specified.");
				return;
			}

			if (loading)
			{   // just palce directly at target location if restoring
				ac.targetObj.transform.position = ac.targetTr.transform.position;
			}
			else
			{
				ac.targetObj.transform.DOMove(ac.targetTr.transform.position, ac.speed);
			}

			// record action for saving
			ObjectSaveData save = null;
			for (int i = 0; i < moveActionChanges.Count; i++)
			{
				if (moveActionChanges[i].target == ac.targetObj)
				{
					save = moveActionChanges[i]; break;
				}
			}

			if (save == null)
			{
				save = new ObjectSaveData();
				moveActionChanges.Add(save);
				save.target = ac.targetObj;
			}

			if (loading)
			{
				save.sceneIdx = simSceneIdx;
				save.actionIdx = simActionIdx;
			}
			else
			{
				save.sceneIdx = activeSceneIdx;
				save.actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			}
		}

		public void ShowDialogue(VA_Dialogue ac, System.Action onDone)
		{
			// record action for saving
			bool doAdd = true;
			int sceneIdx = activeSceneIdx;
			int actionIdx = asset.scenes[activeSceneIdx].GetActiveActionIdx();
			if (dialogueSeen.Count > 0)
			{
				ObjectSaveData s = dialogueSeen[dialogueSeen.Count - 1];
				if (s.sceneIdx == sceneIdx && s.actionIdx == actionIdx) doAdd = false;
			}

			if (doAdd)
			{
				ObjectSaveData save = new ObjectSaveData();
				save.sceneIdx = sceneIdx;
				save.actionIdx = actionIdx;
				dialogueSeen.Add(save);
			}

			// now show dialogue
			VinomaGUI.Instance.dialogueController.StartDialogue(
				Languages.Instance.GetString(ac.langId_characterName, ac.characterName),
				Languages.Instance.GetString(ac.langId_text, ac.text),
				ac.portrait,
				onDone);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region helpers

		private Vector3 CalculateSceneSidePosition(Vector3 pos, SpriteRenderer sprite, VinomaSceneSide sideOpt)
		{
			float h = cam.orthographicSize; // * 2.0f; - don't times 2 since I want half anyway
			float w = h / (float)Screen.height * (float)Screen.width;

			float sw = 0;
			float sh = 0;

			if (sprite != null)
			{
				sw = sprite.bounds.size.x * 0.5f;
				sh = sprite.bounds.size.y * 0.5f;
			}

			switch (sideOpt)
			{
				case VinomaSceneSide.InPlace: 
				{
				} break;
				case VinomaSceneSide.Left: 
				{
					pos.x = -w - sw;
				} break;
				case VinomaSceneSide.Right: 
				{ 
					pos.x = +w + sw;
				} break;
				case VinomaSceneSide.Top: 
				{
					pos.y = +h + sh;
				} break;
				case VinomaSceneSide.Bottom: 
				{
					pos.y = -h - sh;					
				} break;
				case VinomaSceneSide.TopLeft: 
				{
					pos.x = -w - sw;
					pos.y = +h + sh;
				} break;
				case VinomaSceneSide.TopRight: 
				{
					pos.x = +w + sw;
					pos.y = +h + sh;
				} break;
				case VinomaSceneSide.BottomLeft: 
				{
					pos.x = -w - sw;
					pos.y = -h - sh;
				} break;
				case VinomaSceneSide.BottomRight: 
				{
					pos.x = +w + sw;
					pos.y = -h - sh;
				} break;
			}

			return pos;
		}

		private VinomaAction GetAction(int sceneIdx, int actionIdx)
		{
			if (sceneIdx >= 0 && sceneIdx < asset.scenes.Length)
			{
				if (actionIdx >= 0 && actionIdx < asset.scenes[sceneIdx].actions.Length)
				{
					return asset.scenes[sceneIdx].actions[actionIdx];
				}
			}
			return null;
		}

		private void OnLanguageChanged(Languages languages)
		{
			for (int i = 0; i < asset.scenes.Length; i++)
			{
				asset.scenes[i].UpdateStrings(languages);
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
