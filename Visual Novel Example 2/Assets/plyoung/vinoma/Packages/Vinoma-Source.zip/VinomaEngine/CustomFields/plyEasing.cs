﻿using DG.Tweening;

namespace VinomaEngine
{
	[System.Serializable]
	public class plyEasing
	{
		public float time = 1f;
		public Ease ease = Ease.InOutQuad;

		public plyEasing Copy()
		{
			return new plyEasing()
			{
				time = time,
				ease = ease
			};
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
