﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_StopMusic : VinomaAction
	{
		public plyEasing fadeEasing;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_StopMusic ac = CreateInstance(typeof(VA_StopMusic)) as VA_StopMusic;
			ac.fadeEasing = fadeEasing.Copy();
			return ac;
		}

		public override string ToString()
		{
			return "Stop music";
		}

		protected override void Run()
		{
			VinomaGameGlobal.Instance.StopMusic(fadeEasing);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
