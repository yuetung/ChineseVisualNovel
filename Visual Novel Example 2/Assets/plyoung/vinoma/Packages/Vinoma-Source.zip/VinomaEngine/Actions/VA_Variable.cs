﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Variable : VinomaAction
	{
		public string varName;
		public string value;
		public string value2;
		public VinomaVarOperation opt = VinomaVarOperation.Set;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Variable ac = CreateInstance(typeof(VA_Variable)) as VA_Variable;
			ac.varName = varName;
			ac.value = value;
			ac.value2 = value2;
			ac.opt = opt;
			return ac;
		}

		public override string ToString()
		{
			switch (opt)
			{
				case VinomaVarOperation.Set: return varName + " = " + "\"" + value + "\"";
				case VinomaVarOperation.Append:
				case VinomaVarOperation.Add: return varName + " = " + varName + " + " + "\"" + value + "\"";
				case VinomaVarOperation.Subtract: return varName + " = " + varName + " - " + "\"" + value + "\"";
				case VinomaVarOperation.Multiply: return varName + " = " + varName + " * " + "\"" + value + "\"";
				case VinomaVarOperation.Divide: return varName + " = " + varName + " / " + "\"" + value + "\"";
				case VinomaVarOperation.Random: return varName + " = Random(" + value + " <-> " + value2 + ")";
			}
			return "";
		}

		protected override void Run()
		{			
			VinomaSceneController.Instance.PerformOperationOnVariable(varName, value, value2, opt);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
