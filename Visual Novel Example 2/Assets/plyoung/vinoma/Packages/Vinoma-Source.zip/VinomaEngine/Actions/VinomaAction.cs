﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VinomaAction : ScriptableObject
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties

		public int id;					// if of this action; unique among actions in a scene
		
		// -----

		public VinomaScene owner;
		public VinomaAction next;	// the action that follows on this one
		public VinomaAction prev;	// if null then this is first action in scene
		public bool active = true;	// if false then this action will not do anything and simply move directly to next

		public bool _expanded = true; // editor helper

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime


		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		private bool timerActive = false;
		private float timer = 0.0f;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public virtual VinomaAction Copy()
		{
			return null;
		}

		public void CopyBaseDataTo(VinomaAction ac, VinomaScene withOwner)
		{
			ac.name = name;
			ac.owner = withOwner;
			ac.active = active;
			ac._expanded = _expanded;
		}

		// called when this action should init. triggered from GameGlobal.Start()
		public virtual void Init()
		{
		}

		public void RunAction()
		{
			//Debug.Log("Run: " + name);
			owner.activeAction = this;
			if (active) Run();
			else Done();
		}

		// called when this action should start
		protected virtual void Run()
		{
		}

		// force stop this action
		public virtual void Stop()
		{
			timerActive = false;
			owner.activeAction = null;
		}

		// called each frame
		public virtual void Update()
		{
			if (timerActive)
			{
				timer -= Time.deltaTime;
				if (timer <= 0.0f)
				{
					timerActive = false;
					OnTimeout();
				}
			}
		}

		/// <summary> Provides language editor with strings used in this action. Must get an id from 
		/// languagesAsset.GetStringId and set an internal id to this id to keep track of what ID
		/// the string was assigned. Do not generate your own IDs as it will conflict with IDs
		/// created for other strings. You may have an ID generated for null or empty strings
		/// but they are ignored and not added to the list. </summary>
		public virtual List<LanguageString> GetStrings(LanguagesAsset languagesAsset)
		{
			return null;
		}

		/// <summary> Called when the active languages was changed. The action can now use
		/// Languages.Instance.GetString(string_id) to get and update its strings(s) </summary>
		public virtual void UpdateStrings(Languages languages)
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region internal

		// must be called by action when it is done. so the next action in list will execute
		protected void Done()
		{
			//Debug.LogWarning("Done: " + name);
			timerActive = false;
			owner.activeAction = null;
			if (next != null)
			{	// run next action
				next.RunAction();
			}
			else
			{	// no more actions, go to next scene
				VinomaSceneController.Instance.RunNextScene();
			}
		}

		// start a timer which will make OnTimeout() trigger when it runs out
		protected void StartTimer(float timeout)
		{
			if (timeout > 0.0f)
			{
				timer = timeout;
				timerActive = true;
			}
			else
			{
				timerActive = false;
			}
		}

		// called if a timer was initiated
		protected virtual void OnTimeout()
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
