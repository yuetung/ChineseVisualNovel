﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Hotspots : VinomaAction
	{
		public VinomaEnableOption opt;
		public bool autoDisable = true;
		public bool wait = true;
		public int overlayIdent = 0;
		public VinomaWidthAdapt refScale = VinomaWidthAdapt.Background;

		// ------------------------------------------------------------------------------------------------------------

		public int _cachedIdx = -1;
		public string _cachedName = "-none-";

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Hotspots ac = CreateInstance(typeof(VA_Hotspots)) as VA_Hotspots;
			ac.opt = opt;
			ac.autoDisable = autoDisable;
			ac.wait = wait;
			ac.overlayIdent = overlayIdent;
			ac.refScale = refScale;
			return ac;
		}

		public override string ToString()
		{
			return opt + ": " + _cachedName;
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.SetHotspotsOverlay(this, OnHotspot);
			if (!wait) Done();
		}

		private void OnHotspot()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
