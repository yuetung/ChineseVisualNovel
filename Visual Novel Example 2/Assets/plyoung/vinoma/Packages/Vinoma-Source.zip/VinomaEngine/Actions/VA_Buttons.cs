﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Buttons : VinomaAction
	{
		public VinomaButtonDef[] buttons = new VinomaButtonDef[0];
		public int timeoutOpt = -1;
		public float timeoutTime = 2f;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Buttons ac = CreateInstance(typeof(VA_Buttons)) as VA_Buttons;
			ac.buttons = new VinomaButtonDef[buttons.Length];
			for (int i = 0; i < buttons.Length; i++) ac.buttons[i] = buttons[i].Copy();
			ac.timeoutOpt = timeoutOpt;
			ac.timeoutTime = timeoutTime;
			return ac;
		}

		public override string ToString()
		{
			return "Show Buttons";
		}

		protected override void Run()
		{
			VinomaGUI.Instance.ShowButtons(buttons, timeoutOpt, timeoutTime, OnButton);
		}

		private void OnButton()
		{
			Done();
		}

		public override List<LanguageString> GetStrings(LanguagesAsset languagesAsset)
		{
			List<LanguageString> strings = new List<LanguageString>();
			
			for (int i = 0; i < buttons.Length; i++)
			{
				buttons[i].langId_text = languagesAsset.GetStringId(buttons[i].langId_text);
				strings.Add(new LanguageString() { id = buttons[i].langId_text, str = buttons[i].text, context = owner.name +  ": Button " + (i+1).ToString() });
			}

			return strings;
		}

		public override void UpdateStrings(Languages languages)
		{
			// I can't update the strings here since this will persist the changes
			// to the asset since I do not make an instance of it at runtime
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
