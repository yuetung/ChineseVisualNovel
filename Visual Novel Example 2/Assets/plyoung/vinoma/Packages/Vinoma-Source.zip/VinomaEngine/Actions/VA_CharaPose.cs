﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_CharaPose : VinomaAction
	{
		public string characterName;
		public string poseName;
		public plyEasing fadeEasing;
		public bool waitComplete = false;

		// ------------------------------------------------------------------------------------------------------------

		[System.NonSerialized] public GUIContent[] _poseNames;				// used by editor
		[System.NonSerialized] public int _poseIdx = -1;					// used by editor
		[System.NonSerialized] public List<_SpriteCacheEntry> _spriteCache;	// used by editor
		[System.NonSerialized] public GameObject _characterFab;				// used by editor

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_CharaPose ac = CreateInstance(typeof(VA_CharaPose)) as VA_CharaPose;
			ac.characterName = characterName;
			ac.poseName = poseName;
			ac.fadeEasing = fadeEasing.Copy();
			ac.waitComplete = waitComplete;
			return ac;
		}

		public override string ToString()
		{
			return "Change: " + characterName + " pose to " + poseName;
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.SetCharacterPose(this);

			if (waitComplete && fadeEasing.time > 0.0f)
			{
				StartTimer(fadeEasing.time);
				return;
			}

			Done();
		}

		protected override void OnTimeout()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
