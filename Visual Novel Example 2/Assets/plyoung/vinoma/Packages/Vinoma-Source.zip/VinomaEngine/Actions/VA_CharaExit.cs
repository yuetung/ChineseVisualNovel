﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_CharaExit : VinomaAction
	{
		public string characterName;
		public VinomaSceneSide exitTo = VinomaSceneSide.InPlace;
		public plyEasing moveEasing;
		public plyEasing fadeEasing;
		public bool waitComplete = false;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_CharaExit ac = CreateInstance(typeof(VA_CharaExit)) as VA_CharaExit;
			ac.characterName = characterName;
			ac.exitTo = exitTo;
			ac.moveEasing = moveEasing.Copy();
			ac.fadeEasing = fadeEasing.Copy();
			ac.waitComplete = waitComplete;
			return ac;
		}

		public override string ToString()
		{
			return "Exit: " + characterName;
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.ExitCharacter(characterName, exitTo, moveEasing, fadeEasing);

			if (waitComplete)
			{
				float t = 0.0f;
				if (exitTo != VinomaSceneSide.InPlace && moveEasing.time > 0.0f) t = moveEasing.time;
				if (fadeEasing.time > t) t = fadeEasing.time;
				if (t > 0.0f)
				{
					StartTimer(t);
					return;
				}
			}

			Done();
		}

		protected override void OnTimeout()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
