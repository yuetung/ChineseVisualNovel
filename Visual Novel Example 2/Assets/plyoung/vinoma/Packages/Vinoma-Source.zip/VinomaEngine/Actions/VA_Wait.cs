﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Wait : VinomaAction
	{
		public enum WaitOption { Seconds, MouseClick, AnyButton, Forever }

		public WaitOption opt = WaitOption.Seconds;
		public float waitTime = 1f;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Wait ac = CreateInstance(typeof(VA_Wait)) as VA_Wait;
			ac.opt = opt;
			ac.waitTime = waitTime;
			return ac;
		}

		public override string ToString()
		{
			if (opt == WaitOption.Seconds) return "Wait for " + waitTime + " second(s)";
			else if (opt == WaitOption.MouseClick) return "Wait for Mouse Click";
			else if (opt == WaitOption.AnyButton) return "Wait for Any Button";
			else return "Wait Forever";
		}

		protected override void Run()
		{
			if (opt == WaitOption.Seconds)
			{
				StartTimer(waitTime);
			}
		}

		public override void Update()
		{
			if (opt == WaitOption.MouseClick)
			{
				if (VinomaInputManager.MouseHandled == false && Input.GetMouseButtonUp(0) && EventSystem.current.IsPointerOverGameObject() == false)
				{					
					VinomaInputManager.MouseHandled = true;
					Done();
				}
			}
			if (opt == WaitOption.AnyButton)
			{
				if (VinomaInputManager.MouseHandled == false && (Input.GetMouseButtonUp(0) || Input.anyKey))
				{
					VinomaInputManager.MouseHandled = true;
					Done();
				}
			}
			else if (opt == WaitOption.Seconds)
			{
				base.Update();
			}
		}

		protected override void OnTimeout()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
