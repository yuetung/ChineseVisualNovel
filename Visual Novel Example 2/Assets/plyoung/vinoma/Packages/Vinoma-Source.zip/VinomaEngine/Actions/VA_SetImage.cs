﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_SetImage : VinomaAction
	{		
		public GameObject target;
		public Sprite sp;
		public plyEasing fadeEasing = new plyEasing() { time = 0 };
		public bool waitComplete = false;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_SetImage ac = CreateInstance(typeof(VA_SetImage)) as VA_SetImage;
			ac.target = target;
			ac.sp = sp;
			ac.fadeEasing = fadeEasing.Copy();
			ac.waitComplete = waitComplete;
			return ac;
		}

		public override string ToString()
		{
			return string.Format("{0} = {1}", (target == null ? "-invalid-" : target.name), sp == null ? "" : sp.name);
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.SetImage(this);

			if (waitComplete && fadeEasing.time > 0.0f)
			{
				StartTimer(fadeEasing.time);
			}
			else
			{
				Done();
			}
		}

		protected override void OnTimeout()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
