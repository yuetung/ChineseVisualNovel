﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Label : VinomaAction
	{
		public string labelName;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Label ac = CreateInstance(typeof(VA_Label)) as VA_Label;
			ac.labelName = labelName;
			return ac;
		}

		public override string ToString()
		{
			return "[ " + labelName + " ]";
		}

		protected override void Run()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
