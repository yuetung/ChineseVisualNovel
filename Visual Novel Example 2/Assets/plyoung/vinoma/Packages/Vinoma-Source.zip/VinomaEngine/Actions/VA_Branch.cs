﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Branch : VinomaAction
	{
		public VinomaBranchDef[] branches = new VinomaBranchDef[0];

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Branch ac = CreateInstance(typeof(VA_Branch)) as VA_Branch;
			ac.branches = new VinomaBranchDef[branches.Length];
			for (int i = 0; i < branches.Length; i++) ac.branches[i] = branches[i].Copy();
			return ac;
		}

		public override string ToString()
		{
			return "Branch";
		}

		protected override void Run()
		{
			if (false == VinomaSceneController.Instance.DoBranch(branches))
			{	// none of the branches where executed, simply go to the next action
				Done();
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
