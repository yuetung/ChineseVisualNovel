﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Switch : VinomaAction
	{
		public string varName;
		public VinomaSwitchOperation opt = VinomaSwitchOperation.On;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Switch ac = CreateInstance(typeof(VA_Switch)) as VA_Switch;
			ac.varName = varName;
			ac.opt = opt;
			return ac;
		}

		public override string ToString()
		{
			if (opt == VinomaSwitchOperation.Toggle) return "Toggle " + varName + " On/ Off";
			else return varName + " = " + opt;
		}

		protected override void Run()
		{			
			VinomaSceneController.Instance.PerformOperationOnSwitch(varName, opt);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
