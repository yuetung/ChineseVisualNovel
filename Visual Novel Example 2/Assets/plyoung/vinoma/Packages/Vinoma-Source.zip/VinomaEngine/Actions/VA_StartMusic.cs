﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_StartMusic : VinomaAction
	{
		public AudioClip clip;
		public plyEasing fadeEasing;
		public bool loop = true;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_StartMusic ac = CreateInstance(typeof(VA_StartMusic)) as VA_StartMusic;
			ac.clip = clip;
			ac.fadeEasing = fadeEasing.Copy();
			ac.loop = loop;
			return ac;
		}

		public override string ToString()
		{
			return "Start music: " + (clip == null ? "" : clip.name);
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.StartMusic(this);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
