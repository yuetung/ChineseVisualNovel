﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_CharaEnter : VinomaAction
	{
		public GameObject characterFab;
		public string characterName;
		public string poseName;

		public VinomaSceneSortOrder sortOrder = VinomaSceneSortOrder.Front;
		public int customSortOrder = 0;

		public VinomaSceneLocation sceneLocation = VinomaSceneLocation.Middle;
		public VinomaSceneSide enterFrom = VinomaSceneSide.InPlace;

		public plyEasing moveEasing;
		public plyEasing fadeEasing;

		public Vector2Optional customLocation;
		public Vector2Optional offset;
		public bool mirror;
		public bool waitComplete = true;

		// ------------------------------------------------------------------------------------------------------------

		[System.NonSerialized] public GUIContent[] _poseNames;				// used by editor
		[System.NonSerialized] public int _poseIdx = -1;					// used by editor
		[System.NonSerialized] public List<_SpriteCacheEntry> _spriteCache;	// used by editor

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_CharaEnter ac = CreateInstance(typeof(VA_CharaEnter)) as VA_CharaEnter;
			ac.characterFab = characterFab;
			ac.characterName = characterName;
			ac.poseName = poseName;
			ac.sortOrder = sortOrder;
			ac.customSortOrder = customSortOrder;
			ac.sceneLocation = sceneLocation;
			ac.enterFrom = enterFrom;
			ac.moveEasing = moveEasing.Copy();
			ac.fadeEasing = fadeEasing.Copy();
			ac.customLocation = customLocation.Copy();
			ac.offset = offset.Copy();
			ac.mirror = mirror;
			ac.waitComplete = waitComplete;			
			return ac;
		}

		public override string ToString()
		{
			return "Enter: " + characterName;
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.EnterCharacter(this);

			if (waitComplete)
			{
				float t = 0.0f;
				if (enterFrom != VinomaSceneSide.InPlace && moveEasing.time > 0.0f) t = moveEasing.time;
				if (fadeEasing.time > t) t = fadeEasing.time;
				if (t > 0.0f)
				{
					StartTimer(t);
					return;
				}
			}
			
			Done();
		}

		protected override void OnTimeout()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
