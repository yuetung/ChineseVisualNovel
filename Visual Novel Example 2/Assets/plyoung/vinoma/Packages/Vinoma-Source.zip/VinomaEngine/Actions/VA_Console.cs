﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Console : VinomaAction
	{
		public enum ConsoleVarOpt
		{
			None, Variable, Switch
		}

		public string message;
		public string varName;
		public ConsoleVarOpt opt = ConsoleVarOpt.None;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Console ac = CreateInstance(typeof(VA_Console)) as VA_Console;
			ac.message = message;
			ac.varName = varName;
			ac.opt = opt;
			return ac;
		}

		public override string ToString()
		{
			if (opt == ConsoleVarOpt.None) return "Log: " + message;
			else return "Log: " + message + " [" + varName + "]";
		}

		protected override void Run()
		{
			if (opt == ConsoleVarOpt.None) Debug.Log(message);
			else if (opt == ConsoleVarOpt.Variable)
			{
				string val;
				if (VinomaSceneController.Instance.TryGetVariableValue(varName, out val))
				{
					Debug.Log(message + " [ " + varName + " = " + val + " ]");
				}
				else
				{
					Debug.Log(message + " [ " + varName + " = variable-not-found ]");
				}
			}
			else if (opt == ConsoleVarOpt.Switch)
			{
				bool val;
				if (VinomaSceneController.Instance.TryGetSwitchState(varName, out val))
				{
					Debug.Log(message + " [ " + varName + " = " + val + " ]");
				}
				else
				{
					Debug.Log(message + " [ " + varName + " = switch-not-found ]");
				}
			}

			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
