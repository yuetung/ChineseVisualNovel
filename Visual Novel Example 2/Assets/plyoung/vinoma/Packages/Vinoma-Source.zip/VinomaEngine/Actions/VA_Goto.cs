﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Goto : VinomaAction
	{
		public string labelName;
		public string sceneName;
		public VinomaGotoOption gotoOpt = VinomaGotoOption.Label;
		public bool gotoSceneLabel = false;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Goto ac = CreateInstance(typeof(VA_Goto)) as VA_Goto;
			ac.labelName = labelName;
			ac.sceneName = sceneName;
			ac.gotoOpt = gotoOpt;
			ac.gotoSceneLabel = gotoSceneLabel;
			return ac;
		}

		public override string ToString()
		{
			if (gotoOpt == VinomaGotoOption.SceneTop)
			{
				return "Goto: Scene Top";
			}
			else if (gotoOpt == VinomaGotoOption.SceneEnd)
			{
				return "Goto: Scene End";
			}
			else if (gotoOpt == VinomaGotoOption.Label)
			{
				return "Goto: [ " + labelName + " ]";
			}
			else if (gotoOpt == VinomaGotoOption.Scene)
			{
				if (gotoSceneLabel) return "Goto: " + sceneName + " [ " + labelName + " ]";
				else return "Goto: " + sceneName;
			}
			return "";
		}

		protected override void Run()
		{
			if (gotoOpt == VinomaGotoOption.Scene) VinomaSceneController.Instance.Goto(gotoOpt, sceneName, gotoSceneLabel ? labelName : null);
			else VinomaSceneController.Instance.Goto(gotoOpt, sceneName, labelName);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
