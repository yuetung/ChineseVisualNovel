﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_StopSound : VinomaAction
	{
		public string soundName;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_StopSound ac = CreateInstance(typeof(VA_StopSound)) as VA_StopSound;
			ac.soundName = soundName;
			return ac;
		}

		public override string ToString()
		{
			return "Stop sound: " + soundName;
		}

		protected override void Run()
		{
			VinomaGameGlobal.Instance.StopSound(soundName);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
