﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_ChangeBackground : VinomaAction
	{
		public Sprite image;
		public ply2D.ScaleType scaleType = ply2D.ScaleType.FitToHeight;
		public plyEasing fadeEasing;
		public bool waitComplete = false;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_ChangeBackground ac = CreateInstance(typeof(VA_ChangeBackground)) as VA_ChangeBackground;
			ac.image = image;
			ac.scaleType = scaleType;
			ac.fadeEasing = fadeEasing;
			ac.waitComplete = waitComplete;
			return ac;
		}

		public override string ToString()
		{
			return "Show: " + (image == null ? "" : image.name);
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.SetBackground(this);

			if (waitComplete && fadeEasing.time > 0.0f)
			{
				StartTimer(fadeEasing.time);
			}
			else
			{
				Done();
			}
		}

		protected override void OnTimeout()
		{
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
