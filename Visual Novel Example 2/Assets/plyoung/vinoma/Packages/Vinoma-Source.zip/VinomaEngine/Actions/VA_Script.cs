﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Script : VinomaAction
	{
		public string functionName;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Script ac = CreateInstance(typeof(VA_Script)) as VA_Script;
			ac.functionName = functionName;
			return ac;
		}

		public override string ToString()
		{
			return "Call: " + functionName + "( )";
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.CallFunction(functionName);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
