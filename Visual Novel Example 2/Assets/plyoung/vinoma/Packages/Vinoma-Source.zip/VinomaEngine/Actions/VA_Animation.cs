﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Animation : VinomaAction
	{

		public VinomaTargetObject opt = VinomaTargetObject.Object;
		public GameObject targetObj;
		public string targetChara;
		public string aniName;
		//public int aniLayer = 0;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Animation ac = CreateInstance(typeof(VA_Animation)) as VA_Animation;
			ac.opt = opt;
			ac.targetObj = targetObj;
			ac.targetChara = targetChara;
			ac.aniName = aniName;
			return ac;
		}

		public override string ToString()
		{
			return opt + " Animation";
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.PlayAnimation(this);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
