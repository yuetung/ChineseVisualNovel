﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_MoveObj : VinomaAction
	{

		public GameObject targetObj;
		public GameObject targetTr;
		public float speed = 1f;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_MoveObj ac = CreateInstance(typeof(VA_MoveObj)) as VA_MoveObj;
			ac.targetObj = targetObj;
			ac.targetTr = targetTr;
			ac.speed = speed;
			return ac;
		}

		public override string ToString()
		{
			return "Move Object";
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.MoveObject(this);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
