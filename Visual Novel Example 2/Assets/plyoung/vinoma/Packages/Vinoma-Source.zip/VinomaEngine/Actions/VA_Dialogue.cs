﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_Dialogue : VinomaAction
	{

		public string characterName;
		public string text;
		public AudioClip clip;
		public float balance;

		public Sprite portrait;

		public int langId_characterName;
		public int langId_text;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_Dialogue ac = CreateInstance(typeof(VA_Dialogue)) as VA_Dialogue;
			ac.characterName = characterName;
			ac.text = text;
			ac.clip = clip;
			ac.balance = balance;
			ac.portrait = portrait;
			ac.langId_characterName = langId_characterName;
			ac.langId_text = langId_text;
			return ac;
		}

		public override string ToString()
		{
			if (text != null && text.Length > 35) return ":: " + text.Substring(0, 35);
			return ":: " + text;
		}

		protected override void Run()
		{
			VinomaGameGlobal.Instance.PlaySound(clip, "Dialogue", balance, false);
			VinomaSceneController.Instance.ShowDialogue(this, OnDialogueDone);

			//VinomaGUI.Instance.dialogueController.StartDialogue(
			//	Languages.Instance.GetString(langId_characterName, characterName),
			//	Languages.Instance.GetString(langId_text, text),
			//	portrait,
			//	OnDialogueDone);
		}

		private void OnDialogueDone()
		{
			Done();
		}

		public override List<LanguageString> GetStrings(LanguagesAsset languagesAsset)
		{
			List<LanguageString> strings = new List<LanguageString>();

			// make sure the IDs are correct
			langId_characterName = languagesAsset.GetStringId(langId_characterName);
			langId_text = languagesAsset.GetStringId(langId_text);

			// add strings
			strings.Add(new LanguageString() { id = langId_characterName, str = characterName, context = owner.name +  ": Character Name" });
			strings.Add(new LanguageString() { id = langId_text, str = text, context = owner.name +  ": Dialogue Text" });

			return strings;
		}

		public override void UpdateStrings(Languages languages)
		{
			// I can't update the strings here since this will persist the changes
			// to the asset since I do not make an instance of it at runtime
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
