﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_GameObject : VinomaAction
	{
		public GameObject target;
		public VinomaEnableOption opt = VinomaEnableOption.Enable;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_GameObject ac = CreateInstance(typeof(VA_GameObject)) as VA_GameObject;
			ac.target = target;
			ac.opt = opt;
			return ac;
		}

		public override string ToString()
		{
			return opt + ": " + (target == null ? "" : target.name);
		}

		protected override void Run()
		{
			//VinomaSceneController.Instance.SetObjectActive(target, opt == VinomaEnableOption.Enable);
			if (target != null) target.SetActive(opt == VinomaEnableOption.Enable);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
