﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_PlaySound : VinomaAction
	{
		public AudioClip clip;
		public string soundName;
		public float balance = 0f;
		public bool loop = false;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_PlaySound ac = CreateInstance(typeof(VA_PlaySound)) as VA_PlaySound;
			ac.clip = clip;
			ac.soundName = soundName;
			ac.balance = balance;
			ac.loop = loop;
			return ac;
		}

		public override string ToString()
		{
			return "Play sound: " + (clip == null ? "" : clip.name) + (string.IsNullOrEmpty(soundName) ? "" : (" as " + soundName));
		}

		protected override void Run()
		{
			VinomaGameGlobal.Instance.PlaySound(clip, soundName, balance, loop);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
