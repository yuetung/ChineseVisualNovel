﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_UIPanel : VinomaAction
	{
		public string panelName;
		public VinomaViewOption viewOpt = VinomaViewOption.Show;
		public bool additive = true;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_UIPanel ac = CreateInstance(typeof(VA_UIPanel)) as VA_UIPanel;
			ac.panelName = panelName;
			ac.viewOpt = viewOpt;
			ac.additive = additive;
			return ac;
		}

		public override string ToString()
		{
			return viewOpt + " panel: " + panelName;
		}

		protected override void Run()
		{
			if (viewOpt == VinomaViewOption.Show)
			{
				if (additive) VinomaGUI.Instance.ShowPanelAdditive(panelName);
				else VinomaGUI.Instance.ShowPanel(panelName);
			}
			else
			{
				VinomaGUI.Instance.HidePanel(panelName);
			}
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
