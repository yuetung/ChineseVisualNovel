﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[System.Serializable]
	public class VA_UIText : VinomaAction
	{
		public GameObject target;
		public string text;

		// ------------------------------------------------------------------------------------------------------------

		public override VinomaAction Copy()
		{
			VA_UIText ac = CreateInstance(typeof(VA_UIText)) as VA_UIText;
			ac.target = target;
			ac.text = text;
			return ac;
		}

		public override string ToString()
		{
			if (text != null && text.Length > 35) string.Format("{0} = {1}", (target == null ? "-invalid-" : target.name), text.Substring(0, 35));
			return string.Format("{0} = {1}", (target == null ? "-invalid-" : target.name), text);
		}

		protected override void Run()
		{
			VinomaSceneController.Instance.SetUIText(this);
			Done();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
