﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class VinomaDialogueController : MonoBehaviour
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public struct DialoguePart
		{
			public string name;
			public string text;
		}

		private static readonly char[] TagSplitter = new char[] { '<' };

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		private GameObject portraitGo;
		private System.Action callback;
		private int curr = -1;
		private List<DialoguePart> parts = new List<DialoguePart>();
		private string _name = null; // only set after request to show dialogue, will be cleared after dialogue parts where calculated
		private string _text = null; // only set after request to show dialogue, will be cleared after dialogue parts where calculated
		private bool autoOn = false;
		private float timer = 0.0f;
		private MouseOverDetect pointerOverDetect;
		private CanvasGroup canvasGroup;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void Start()
		{
			Transform tr = plyUtil.FindFirstChildRecursive(VinomaGUI.Instance.dialoguePanel.transform, "Portrait");
			if (tr != null)
			{
				portraitGo = tr.gameObject;
				portraitGo.SetActive(false);
			}

			canvasGroup = VinomaGUI.Instance.dialoguePanel.GetComponent<CanvasGroup>();

			if (canvasGroup != null)
			{
				canvasGroup.blocksRaycasts = true;
				canvasGroup.interactable = true;
				pointerOverDetect = VinomaGUI.Instance.dialoguePanel.GetComponent<MouseOverDetect>() ?? VinomaGUI.Instance.dialoguePanel.AddComponent<MouseOverDetect>();
			}

			pointerOverDetect.PointerOver = false;
			pointerOverDetect.controller = this;
		}

		public void TriggerClick()
		{
			if (curr >= 0)
			{
				VinomaInputManager.MouseHandled = true;
				UpdateDialogue();
			}
		}

		protected void Update()
		{
			if (curr >= 0)
			{
				if (autoOn)
				{
					timer -= Time.deltaTime;
					if (timer <= 0.0f)
					{
						VinomaInputManager.MouseHandled = true;
						UpdateDialogue();
						return;
					}
				}

				if (Input.GetKeyUp(KeyCode.Space))
				{
					VinomaInputManager.MouseHandled = true;
					UpdateDialogue();
					return;
				}
			}
		}

		protected void LateUpdate()
		{
			if (_text != null)
			{
				_StartDialogue();
			}
		}

		private void UpdateDialogue()
		{
			timer = VinomaGameGlobal.Instance.asset.autoDialogueSpeed;
			curr++;

			if (curr >= parts.Count)
			{
				curr = -1;
				parts.Clear();
				VinomaGUI.Instance.dialoguePanel.SetActive(false);
				if (callback != null) callback();
			}
			else
			{
				VinomaGUI.Instance.dialoguePanel.SetActive(true);
				if (VinomaGUI.Instance.dialogueTextHandler != null) VinomaGUI.Instance.dialogueTextHandler.SetText(parts[curr].text);
				else VinomaGUI.Instance.conversationText.text = parts[curr].text;
				if (VinomaGUI.Instance.conversationName != null) VinomaGUI.Instance.conversationName.text = parts[curr].name;
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public void ClearAll()
		{   // normally called after a load from save data
			if (portraitGo != null) portraitGo.SetActive(false);
			curr = -1;
			_name = null;
			_text = null;
			callback = null;
			parts.Clear();
			pointerOverDetect.PointerOver = false;
		}

		public void SetDialogueAuto(bool on)
		{
			autoOn = on;
		}

		public void StartDialogue(string name, string text, Sprite portrait, System.Action onDone)
		{
			timer = VinomaGameGlobal.Instance.asset.autoDialogueSpeed;

			if (VinomaGUI.Instance.dialoguePanel == null)
			{
				Debug.LogError("The Dialogue Panel is not set in the VinomaGUI component.");
				return;
			}

			if (VinomaGUI.Instance.conversationText == null)
			{
				Debug.LogError("The Conversation Text is not set in the VinomaGUI component.");
				return;
			}

			if (portraitGo != null)
			{
				portraitGo.SetActive(false);
			}

			if (portrait != null)
			{
				if (portraitGo == null)
				{
					Debug.LogWarning("You specified a portrait to show but the Dialogue Panel has no Image object named 'Portrait' in it. The portrait can't be shown.");
				}
				else
				{
					Image img = portraitGo.GetComponent<Image>();
					if (img != null)
					{
						img.sprite = portrait;
						portraitGo.SetActive(true);
					}
					else Debug.LogWarning("You specified a portrait to show but the Dialogue Panel's Portrait object has no Image component on it. The portrait can't be shown.");
				}
			}

			_name = name == null ? "" : VinomaSceneController.Instance.ParseTextForVariables(name).Trim();
			_text = VinomaSceneController.Instance.ParseTextForVariables(text);
			curr = -1;
			callback = onDone;
			parts.Clear();

			// make conversationText visible now so that it's size is ready when _StartDialogue() called in next frame
			VinomaGUI.Instance.dialoguePanel.SetActive(true);
			if (VinomaGUI.Instance.dialogueTextHandler != null) VinomaGUI.Instance.dialogueTextHandler.Clear();
			else VinomaGUI.Instance.conversationText.text = "";
			if (VinomaGUI.Instance.conversationName != null) VinomaGUI.Instance.conversationName.text = "";
		}

		private void _StartDialogue()
		{
			//List<string> lines = new List<string>();
			//List<string> openTags = new List<string>();
			//List<string> newOpenedTags = new List<string>();
			//TextGenerator gen = VinomaGUI.Instance.conversationText.cachedTextGenerator;
			//TextGenerationSettings settings = VinomaGUI.Instance.conversationText.GetGenerationSettings(VinomaGUI.Instance.conversationText.rectTransform.rect.size);

			//// break the text up in parts using double new-line as separator
			//string[] split_text = _text.Split(new string[] { "\n\n" }, System.StringSplitOptions.RemoveEmptyEntries);
			
			//_text = null; // done with it. must set to null to prevent continued calls to _StartDialogue()

			//for (int i = 0; i < split_text.Length; i++)
			//{
			//	string paragraph = split_text[i];
			//	paragraph = paragraph.Trim();

			//	// extract name change
			//	if (paragraph.StartsWith("{"))
			//	{
			//		int p = paragraph.IndexOf("}");
			//		if (p > 0)
			//		{
			//			_name = paragraph.Substring(1, p - 1).Trim();
			//			if (p + 1 < paragraph.Length) paragraph = paragraph.Substring(p + 1);
			//			paragraph = paragraph.Trim();
			//		}
			//	}

			//	// check if the paragraph of text will fit and break it up further if not
			//	lines.Clear();
			//	gen.Populate(paragraph, settings);
			//	if (gen.characterCountVisible != paragraph.Length && paragraph.Length > 0)
			//	{
			//		do 
			//		{
			//			// copy only what will fit then step back to last space to remove possibly broken word
			//			string ds = paragraph.Substring(0, gen.characterCountVisible);
			//			int pos = ds.LastIndexOf(" ");
			//			if (pos > 0) ds = ds.Substring(0, pos);
			//			else pos = gen.characterCountVisible;

			//			// add text to lines and truncate paragraph
			//			lines.Add(ds);
			//			paragraph = paragraph.Substring(pos).Trim();

			//			// check if what is left will fit, else create a new line
			//			gen.Populate(paragraph, settings);
			//		}
			//		while (gen.characterCountVisible != paragraph.Length && paragraph.Length > 0);

			//		if (paragraph.Length > 0) lines.Add(paragraph);
			//	}
			//	else
			//	{
			//		lines.Add(paragraph);
			//	}

			//	for (int j = 0; j < lines.Count; j++)
			//	{
			//		string line = lines[j];

			//		// add missing opening tags
			//		for (int k = openTags.Count - 1; k >= 0; k--)
			//		{
			//			line = "<" + openTags[k] + ">" + line;
			//		}

			//		// check usage of tags and insert opening/ closing tags as needed
			//		newOpenedTags.Clear();
			//		string[] line_parts = lines[j].Split(TagSplitter, System.StringSplitOptions.RemoveEmptyEntries);
			//		for (int k = 0; k < line_parts.Length; k++)
			//		{
			//			if (k == 0 && !lines[j].StartsWith("<")) continue;

			//			int tagEnd = line_parts[k].IndexOf(">");
			//			if (tagEnd < 0)
			//			{
			//				Debug.LogError("Text formating invalid in line: " + lines[j]);
			//				parts.Clear();
			//				return;
			//			}

			//			string tag = line_parts[k].Substring(0, tagEnd).ToLower();

			//			if (tag.StartsWith("color=")) newOpenedTags.Add(tag);
			//			else if (tag.Equals("/color"))
			//			{
			//				if (!RemoveTagFromBehind(newOpenedTags, 'c')) RemoveTagFromBehind(openTags, 'c');
			//			}
			//			else if (tag.Equals("b")) newOpenedTags.Add(tag);
			//			else if (tag.Equals("/b"))
			//			{
			//				if (!RemoveTagFromBehind(newOpenedTags, 'b')) RemoveTagFromBehind(openTags, 'b');
			//			}
			//			else if (tag.Equals("i")) newOpenedTags.Add(tag);
			//			else if (tag.Equals("/i"))
			//			{
			//				if (!RemoveTagFromBehind(newOpenedTags, 'i')) RemoveTagFromBehind(openTags, 'i');
			//			}
			//			else if (tag.StartsWith("size=")) newOpenedTags.Add(tag);
			//			else if (tag.Equals("/size"))
			//			{
			//				if (!RemoveTagFromBehind(newOpenedTags, 's')) RemoveTagFromBehind(openTags, 's');
			//			}
			//			else
			//			{
			//				Debug.LogError("Text formating invalid in line: " + lines[j]);
			//				parts.Clear();
			//				return;
			//			}
			//		}

			//		// close missing opening tags
			//		for (int k = 0; k < openTags.Count; k++)
			//		{
			//			if (openTags[k][0] == 'c') line += "</color>";
			//			else if (openTags[k][0] == 'b') line += "</b>";
			//			else if (openTags[k][0] == 'i') line += "</i>";
			//			else if (openTags[k][0] == 's') line += "</size>";
			//		}

			//		// close the tags that stayed open in this line
			//		// and add them to open set for next line
			//		for (int k = 0; k < newOpenedTags.Count; k++)
			//		{
			//			openTags.Add(newOpenedTags[k]);
			//			if (newOpenedTags[k][0] == 'c') line += "</color>";
			//			else if (newOpenedTags[k][0] == 'b') line += "</b>";
			//			else if (newOpenedTags[k][0] == 'i') line += "</i>";
			//			else if (newOpenedTags[k][0] == 's') line += "</size>";
			//		}

			//		// create the dialogue part
			//		parts.Add(new DialoguePart()
			//		{
			//			name = _name,
			//			text = line
			//		});
			//	}
			//}

			parts = GenerateDialogueParts(_name, _text, true);
			_text = null; // done with it. must set to null to prevent continued calls to _StartDialogue()
			UpdateDialogue();
		}

		public List<DialoguePart> GenerateDialogueParts(string name, string text, bool update_name = false)
		{
			List<DialoguePart> parts = new List<DialoguePart>();
			List<string> lines = new List<string>();
			List<string> openTags = new List<string>();
			List<string> newOpenedTags = new List<string>();
			TextGenerator gen = VinomaGUI.Instance.conversationText.cachedTextGenerator;
			TextGenerationSettings settings = VinomaGUI.Instance.conversationText.GetGenerationSettings(VinomaGUI.Instance.conversationText.rectTransform.rect.size);

			// break the text up in parts using double new-line as separator
			string[] split_text = text.Split(new string[] { "\n\n" }, System.StringSplitOptions.RemoveEmptyEntries);
			text = null; // done with it
			string nm = name;
			
			for (int i = 0; i < split_text.Length; i++)
			{
				string paragraph = split_text[i];
				paragraph = paragraph.Trim();

				// extract name change
				if (paragraph.StartsWith("{"))
				{
					int p = paragraph.IndexOf("}");
					if (p > 0)
					{
						nm = paragraph.Substring(1, p - 1).Trim();
						if (update_name) _name = nm;
						if (p + 1 < paragraph.Length) paragraph = paragraph.Substring(p + 1);
						paragraph = paragraph.Trim();
					}
				}

				// check if the paragraph of text will fit and break it up further if not
				lines.Clear();
				gen.Populate(paragraph, settings);
				if (gen.characterCountVisible != paragraph.Length && paragraph.Length > 0)
				{
					do
					{
						// copy only what will fit then step back to last space to remove possibly broken word
						string ds = paragraph.Substring(0, gen.characterCountVisible);
						int pos = ds.LastIndexOf(" ");
						if (pos > 0) ds = ds.Substring(0, pos);
						else pos = gen.characterCountVisible;

						// add text to lines and truncate paragraph
						lines.Add(ds);
						paragraph = paragraph.Substring(pos).Trim();

						// check if what is left will fit, else create a new line
						gen.Populate(paragraph, settings);
					}
					while (gen.characterCountVisible != paragraph.Length && paragraph.Length > 0);

					if (paragraph.Length > 0) lines.Add(paragraph);
				}
				else
				{
					lines.Add(paragraph);
				}

				for (int j = 0; j < lines.Count; j++)
				{
					string line = lines[j];

					// add missing opening tags
					for (int k = openTags.Count - 1; k >= 0; k--)
					{
						line = "<" + openTags[k] + ">" + line;
					}

					// check usage of tags and insert opening/ closing tags as needed
					newOpenedTags.Clear();
					string[] line_parts = lines[j].Split(TagSplitter, System.StringSplitOptions.RemoveEmptyEntries);
					for (int k = 0; k < line_parts.Length; k++)
					{
						if (k == 0 && !lines[j].StartsWith("<")) continue;

						int tagEnd = line_parts[k].IndexOf(">");
						if (tagEnd < 0)
						{
							Debug.LogError("Text formating invalid in line: " + lines[j]);
							parts.Clear();
							return parts;
						}

						string tag = line_parts[k].Substring(0, tagEnd).ToLower();

						if (tag.StartsWith("color=")) newOpenedTags.Add(tag);
						else if (tag.Equals("/color"))
						{
							if (!RemoveTagFromBehind(newOpenedTags, 'c')) RemoveTagFromBehind(openTags, 'c');
						}
						else if (tag.Equals("b")) newOpenedTags.Add(tag);
						else if (tag.Equals("/b"))
						{
							if (!RemoveTagFromBehind(newOpenedTags, 'b')) RemoveTagFromBehind(openTags, 'b');
						}
						else if (tag.Equals("i")) newOpenedTags.Add(tag);
						else if (tag.Equals("/i"))
						{
							if (!RemoveTagFromBehind(newOpenedTags, 'i')) RemoveTagFromBehind(openTags, 'i');
						}
						else if (tag.StartsWith("size=")) newOpenedTags.Add(tag);
						else if (tag.Equals("/size"))
						{
							if (!RemoveTagFromBehind(newOpenedTags, 's')) RemoveTagFromBehind(openTags, 's');
						}
						else
						{
							Debug.LogError("Text formating invalid in line: " + lines[j]);
							parts.Clear();
							return parts;
						}
					}

					// close missing opening tags
					for (int k = 0; k < openTags.Count; k++)
					{
						if (openTags[k][0] == 'c') line += "</color>";
						else if (openTags[k][0] == 'b') line += "</b>";
						else if (openTags[k][0] == 'i') line += "</i>";
						else if (openTags[k][0] == 's') line += "</size>";
					}

					// close the tags that stayed open in this line
					// and add them to open set for next line
					for (int k = 0; k < newOpenedTags.Count; k++)
					{
						openTags.Add(newOpenedTags[k]);
						if (newOpenedTags[k][0] == 'c') line += "</color>";
						else if (newOpenedTags[k][0] == 'b') line += "</b>";
						else if (newOpenedTags[k][0] == 'i') line += "</i>";
						else if (newOpenedTags[k][0] == 's') line += "</size>";
					}

					// create the dialogue part
					parts.Add(new DialoguePart()
					{
						name = nm,
						text = line
					});
				}
			}

			return parts;
		}

		private bool RemoveTagFromBehind(List<string> tags, char t)
		{
			for (int i = tags.Count - 1; i >= 0; i--)
			{
				if (tags[i][0] == t) { tags.RemoveAt(i); return true; }
			}
			return false;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
