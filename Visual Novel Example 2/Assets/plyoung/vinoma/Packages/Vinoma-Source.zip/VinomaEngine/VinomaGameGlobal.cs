﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;
using DG.Tweening;

namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class VinomaGameGlobal : MonoBehaviour
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public static class SortLayer
		{
			public const string Background = "Background";
			public const string Character = "Character";
		}

		private class CounterNfo
		{
			public float timer;
			public System.Action callback;
		}

		private class SoundInfo
		{
			public string name;
			public AudioSource audio;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region properties

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		public static VinomaGameGlobal Instance { get; private set; }
		public VinomaDataAsset asset { get; private set; }

		public static float setting_mainVolume { get; set; }
		public static float setting_sfxVolume { get; set; }
		public static float setting_musicVolume { get; set; }
		public static bool setting_fullscreen { get; set; }
		public static int setting_width { get; set; }
		public static int setting_height { get; set; }
		public static int setting_quality { get; set; }

		private List<CounterNfo> timers = new List<CounterNfo>(5);
		private int counterIdx;

		private AudioSource[] musicSources = new AudioSource[2]; // there are two so that I can cross-fade them
		private Tweener[] musicTweener = new Tweener[2];
		private int musicSourceIdx = 0;

		private List<SoundInfo> soundSources = new List<SoundInfo>(); // list of audio sources that are either playing sounds or that can be used to start new sounds on

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		public void PlayTestScene(int idx)
		{
			VinomaGUI.Instance.ResetPanels(true);
			VinomaSceneController.Instance.ClearScenes(true);
			VinomaSceneController.Instance.RunScene(idx);
		}

		protected void Awake()
		{
			asset = GetComponent<VinomaDataAsset>();
			if (asset == null)
			{
				Debug.LogError("The Vinoma Data is not present.");
				Application.Quit();
				return;
			}

			DOTween.Init();

			Instance = this;
			GameObject.DontDestroyOnLoad(gameObject);

			LoadSettings();

			// LoadSave provider
			LoadSaveController.Create(new LoadSave_PlayerPrefs());

			// add input manager
			gameObject.AddComponent<VinomaInputManager>();

			// create game scene's object
			new GameObject("VinomaSceneController", typeof(VinomaSceneController));

			// setup camera
			Camera.main.orthographic = true;
			Camera.main.orthographicSize = asset.designHeight / 2f / asset.pixelsPerUnit;

			// setup music components
			for (int i = 0; i < 2; i++)
			{
				musicSources[i] = gameObject.AddComponent<AudioSource>();
				musicSources[i].bypassEffects = true;
				musicSources[i].bypassListenerEffects = true;
				musicSources[i].bypassReverbZones = true;
				musicSources[i].playOnAwake = false;
#if !UNITY_4
				musicSources[i].spatialBlend = 0f; // 2D
#endif
			}

			SoundVolumeHandler vol = gameObject.AddComponent<SoundVolumeHandler>();
			vol.targetAudioSources = new AudioSource[] { musicSources[0], musicSources[1] };
			vol.soundType = SoundVolumeHandler.SoundType.Music;			
		}

		protected void Start()
		{
			for (int i = 0; i < asset.scenes.Length; i++)
			{
				asset.scenes[i].Init();
			}

			ApplySettings();

			StartMenuMusic();
		}

		protected void OnDestroy()
		{
			Instance = null;
		}

		protected void Update()
		{
			if (timers.Count > 0)
			{
				for (counterIdx = timers.Count - 1; counterIdx > 0; counterIdx--)
				{
					timers[counterIdx].timer -= Time.deltaTime;
					if (timers[counterIdx].timer <= 0.0f)
					{
						if (timers[counterIdx].callback != null) timers[counterIdx].callback();
						RemoveTimer(counterIdx);
					}
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region settings

		private void ApplySettings()
		{
			if (!VinomaGameGlobal.Instance.asset.manageGameSettings) return;

			AudioListener.volume = setting_mainVolume;
			SoundVolumeHandler[] objs = GameObject.FindObjectsOfType<SoundVolumeHandler>();
			for (int i = 0; i < objs.Length; i++) objs[i].UpdateVolume();
			QualitySettings.SetQualityLevel(setting_quality);

			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				Screen.SetResolution(setting_width, setting_height, setting_fullscreen);
			}
		}

		private void LoadSettings()
		{
			if (!VinomaGameGlobal.Instance.asset.manageGameSettings) return;

			setting_mainVolume = PlayerPrefs.GetFloat("MainVolume", 1f);
			setting_sfxVolume = PlayerPrefs.GetFloat("SFXVolume", 1f);
			setting_musicVolume = PlayerPrefs.GetFloat("MusicVolume", 1f);
			setting_quality = PlayerPrefs.GetInt("Quality", QualitySettings.GetQualityLevel());

			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				setting_fullscreen = PlayerPrefs.GetInt("Fullscreen", 0) == 1;
				setting_width = PlayerPrefs.GetInt("ScreenWidth", Screen.width);
				setting_height = PlayerPrefs.GetInt("ScreenHeight", Screen.height);
			}
		}

		public static void SaveSettings()
		{
			if (!VinomaGameGlobal.Instance.asset.manageGameSettings) return;

			PlayerPrefs.SetFloat("MainVolume", setting_mainVolume);
			PlayerPrefs.SetFloat("SFXVolume", setting_sfxVolume);
			PlayerPrefs.SetFloat("MusicVolume", setting_musicVolume);

			if (VinomaGameGlobal.Instance.asset.resolutionSettingsActive)
			{
				PlayerPrefs.SetInt("Fullscreen", setting_fullscreen ? 1 : 0);
				PlayerPrefs.SetInt("ScreenWidth", setting_width);
				PlayerPrefs.SetInt("ScreenHeight", setting_height);
			}

			Instance.ApplySettings();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region counters

		public void CreateTimer(float timer, System.Action callback)
		{
			timers.Add(new CounterNfo() { timer = timer, callback = callback});
		}

		public void DestroyTimer(System.Action callback)
		{
			for (counterIdx = 0; counterIdx < timers.Count; counterIdx++)
			{
				if (timers[counterIdx].callback == callback)
				{
					RemoveTimer(counterIdx);
					return;
				}
			}
		}

		private void RemoveTimer(int idx)
		{
			if (idx >= 0 && idx < timers.Count)
			{
				timers[idx].callback = null;
				timers.RemoveAt(idx);
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region music and sound

		public void StartMenuMusic()
		{
			plyEasing fade = new plyEasing();
			if (asset.menuMusic != null) StartMusic(asset.menuMusic, true, fade);
			else StopMusic(fade);
		}

		public void StartMusic(AudioClip music, bool loop, plyEasing fade)
		{
			StopMusic(fade);
			if (music != null)
			{
				if (musicTweener[musicSourceIdx] != null) { musicTweener[musicSourceIdx].Kill(); musicTweener[musicSourceIdx] = null; }
				if (fade.time > 0.0f)
				{
					int a = musicSourceIdx;
					musicSources[musicSourceIdx].volume = 0f;
					musicTweener[musicSourceIdx] = DOTween.To(() => musicSources[a].volume, v => musicSources[a].volume = v, VinomaGameGlobal.setting_musicVolume, fade.time).SetEase(fade.ease);
				}
				else
				{
					musicSources[musicSourceIdx].volume = VinomaGameGlobal.setting_musicVolume;
				}

				musicSources[musicSourceIdx].mute = (VinomaGameGlobal.setting_musicVolume <= 0.0f);
				musicSources[musicSourceIdx].loop = loop;
				musicSources[musicSourceIdx].clip = music;
				musicSources[musicSourceIdx].Play();
			}
		}

		public void StopMusic(plyEasing fade)
		{
			// stop and set the "next" idx to be used
			if (musicTweener[musicSourceIdx] != null) { musicTweener[musicSourceIdx].Kill(); musicTweener[musicSourceIdx] = null; }
			if (fade.time > 0.0f && musicSources[musicSourceIdx].isPlaying)
			{
				int a = musicSourceIdx;
				musicTweener[musicSourceIdx] = DOTween.To(() => musicSources[a].volume, v => musicSources[a].volume = v, 0f, fade.time).SetEase(fade.ease).OnComplete(() => _StopMusic(a));
			}
			else
			{
				_StopMusic(musicSourceIdx);
			}

			musicSourceIdx = musicSourceIdx == 0 ? 1 : 0;
		}

		private void _StopMusic(int idx)
		{
			musicSources[idx].Stop();
			musicSources[idx].clip = null;
		}

		public void PlaySound(AudioClip clip, string name, float balance, bool loop)
		{
			if (clip == null) return;

			SoundInfo snd = null;
			for (int i = 0; i < soundSources.Count; i++)
			{
				if (soundSources[i].audio.isPlaying == false)
				{
					snd = soundSources[i];
					break;
				}
			}

			if (snd == null)
			{
				snd = new SoundInfo();
				snd.audio = gameObject.AddComponent<AudioSource>();
				snd.audio.bypassEffects = true;
				snd.audio.bypassListenerEffects = true;
				snd.audio.bypassReverbZones = true;
				snd.audio.playOnAwake = false;
#if !UNITY_4
				snd.audio.spatialBlend = 0f; // 2D
#endif
				soundSources.Add(snd);
			}

			snd.name = name;
			snd.audio.clip = clip;
#if !UNITY_4
			snd.audio.panStereo = balance;
#else
			snd.audio.pan = balance;
#endif
			snd.audio.loop = loop;
			snd.audio.volume = VinomaGameGlobal.setting_sfxVolume;
			snd.audio.Play();
		}

		public void StopSound(string name)
		{
			if (string.IsNullOrEmpty(name)) return;
			for (int i = 0; i < soundSources.Count; i++)
			{
				if (name.Equals(soundSources[i].name))
				{
					soundSources[i].audio.Stop();
					return;
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region misc



		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
