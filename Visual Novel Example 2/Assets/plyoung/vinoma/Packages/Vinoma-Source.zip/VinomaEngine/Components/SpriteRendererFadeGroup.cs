﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;

namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class SpriteRendererFadeGroup: MonoBehaviour
    {
		private List<Tweener> tweens = new List<Tweener>();

		public void Fade(float targetAlpha, float fadeTime, Ease ease, bool doResetAlpha = false, float startAlpha = 0)
		{
			Stop(); // first stop any active fades
			SpriteRenderer[] rens = gameObject.GetComponentsInChildren<SpriteRenderer>(false);
			for (int i = 0; i < rens.Length; i++)
			{
				int j = i;
				if (doResetAlpha) rens[j].color = new Color(rens[j].color.r, rens[j].color.g, rens[j].color.b, startAlpha);
				Tweener t = DOTween.ToAlpha(() => rens[j].color, a => rens[j].color = a, targetAlpha, fadeTime).SetEase(ease);
				if (targetAlpha == 0f) t.OnComplete(() => rens[j].gameObject.SetActive(false));
				tweens.Add(t);
			}
		}

		public void Stop()
		{
			for (int i = 0; i < tweens.Count; i++) tweens[i].Kill(true);
			tweens.Clear();
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}