﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[RequireComponent(typeof(SpriteRenderer))]
	[AddComponentMenu("")]
	public class SpriteToScreenScaler : MonoBehaviour
	{
		private SpriteRenderer ren;

		protected void Awake()
		{
			ren = GetComponent<SpriteRenderer>();
		}

		protected void Start()
		{
			Rescale(ply2D.ScaleType.None);
		}

		public void Rescale(ply2D.ScaleType scaleType, Camera cam = null)
		{
			transform.localScale = ply2D.SpriteScale(ren, cam == null ? Camera.main : cam, scaleType);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
