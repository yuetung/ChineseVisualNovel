﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("Vinoma/Auto Panel Visibility")]
	[DisallowMultipleComponent]
	public class AutoPanelVisibility : MonoBehaviour
	{
		public enum Option
		{
			AlwaysVisible, VisibleDuringGameScenes, VisibleDuringNotGameScenes, RememberState
		}

		public Option option = Option.VisibleDuringGameScenes;

		// ------------------------------------------------------------------------------------------------------------
		
		//protected void OnEnable()
		//{
		//	Debug.LogError("ENABLED", gameObject);
		//}

		//protected void OnDisable()
		//{
		//	Debug.LogError("DISABLED", gameObject);
		//}

		// ------------------------------------------------------------------------------------------------------------
	}
}
