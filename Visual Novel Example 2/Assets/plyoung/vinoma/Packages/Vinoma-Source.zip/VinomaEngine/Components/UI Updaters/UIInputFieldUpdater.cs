﻿
using UnityEngine;
using UnityEngine.UI;


namespace VinomaEngine
{
	[RequireComponent(typeof(InputField)), AddComponentMenu("Vinoma/GUI/InputField Updater"), HelpURL("https://plyoung.github.io/vinoma-ui-updaters.html")]
	public class UIInputUpdater : MonoBehaviour
	{
		[SerializeField] private InputField target=null;
		[SerializeField] private string variableName=null;
		[SerializeField] private bool twoWayLink=false;
		private bool _lock = false;

		private void Reset()
		{
			target = GetComponent<InputField>();
		}

		private void Awake()
		{
			if (target == null)
			{
				target = GetComponent<InputField>();
				if (target == null) Debug.Log("[UIInputUpdater] Could not find any InputField component on the GameObject.", gameObject);
			}
		}

		private void Start()
		{
			if (VinomaSceneController.Instance == null)
			{
				Debug.LogError("The Vinoma Scene Controller is not active. You should not use this component outside of a Vinoma main scene.");
				return;
			}

			VinomaSceneController.Instance.LinkToVariable(variableName, OnValueChanged);

			if (twoWayLink)
			{
				target.onValueChanged.AddListener(OnInputValueChanged);
			}
		}

		private void OnDestroy()
		{
			if (VinomaSceneController.Instance != null)
			{
				VinomaSceneController.Instance.UnlinkFromVariable(variableName, OnValueChanged);
			}
		}

		private void OnEnable()
		{
			if (VinomaSceneController.Instance != null)
			{
				string v = null;
				if (VinomaSceneController.Instance.TryGetVariableValue(variableName, out v))
				{
					OnValueChanged(v);
				}
			}
		}

		private void OnValueChanged(string value)
		{
			if (_lock) return;
			_lock = true;
			target.text = value;
			_lock = false;
		}

		private void OnInputValueChanged(string v)
		{
			if (_lock || VinomaSceneController.Instance == null) return;
			_lock = true;
			VinomaSceneController.Instance.PerformOperationOnVariable(variableName, v, null, VinomaVarOperation.Set);
			_lock = false;
		}

		// ------------------------------------------------------------------------------------------------------------
	}

}
