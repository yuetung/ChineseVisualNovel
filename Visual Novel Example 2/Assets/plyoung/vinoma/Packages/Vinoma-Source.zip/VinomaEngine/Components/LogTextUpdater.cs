﻿using System.Text;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[RequireComponent(typeof(Text))]
	[AddComponentMenu("Vinoma/Log Text Updater")]
	public class LogTextUpdater : MonoBehaviour
	{
		public int MaxCharacters = 5000;

		private Text t;
		private int idx = -1;

		protected void Start()
		{
			t = GetComponent<Text>();
			t.text = "";
			LoadSaveController.Instance.RegisterLoadSaveListener(OnSave, OnLoad);

			if (MaxCharacters < 1) MaxCharacters = 5000;
		}

		private void OnSave(int slot)
		{
			// none
		}

		private void OnLoad(int slot)
		{
			t.text = "";
		}

		protected void LateUpdate()
		{
			if (idx < VinomaSceneController.Instance.dialogueSeen.Count - 1)
			{
				StringBuilder s = new StringBuilder();
				s.Append(t.text);

				while (idx < VinomaSceneController.Instance.dialogueSeen.Count - 1)
				{
					idx++;
					VinomaScene scene = VinomaGameGlobal.Instance.asset.scenes[VinomaSceneController.Instance.dialogueSeen[idx].sceneIdx];
					VA_Dialogue ac = scene.actions[VinomaSceneController.Instance.dialogueSeen[idx].actionIdx] as VA_Dialogue;
					if (ac != null)
					{
						List<VinomaDialogueController.DialoguePart> parts = VinomaGUI.Instance.dialogueController.GenerateDialogueParts
							(
								Languages.Instance.GetString(ac.langId_characterName, ac.characterName),
								Languages.Instance.GetString(ac.langId_text, ac.text)
							);

						for (int i = 0; i < parts.Count; i++)
						{
							string _name = string.IsNullOrEmpty(parts[i].name) ? null : VinomaSceneController.Instance.ParseTextForVariables(parts[i].name).Trim();
							string _text = VinomaSceneController.Instance.ParseTextForVariables(parts[i].text);

							if (_name != null) s.Append("<b>" + _name + "</b>\n\n");
							s.Append(_text + "\n\n");
						}
					}
				}

				string ts = s.ToString();
				if (ts.Length > MaxCharacters)
				{
					t.text = ts.Substring(ts.Length - MaxCharacters);
				}
				else
				{
					t.text = ts;
				}

			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
