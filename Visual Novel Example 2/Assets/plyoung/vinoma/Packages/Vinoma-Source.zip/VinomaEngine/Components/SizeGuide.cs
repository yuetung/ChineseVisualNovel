﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[RequireComponent(typeof(SpriteRenderer))]
	[AddComponentMenu("")]
	public class SizeGuide : MonoBehaviour
	{
		public ply2D.ScaleType scaleType = ply2D.ScaleType.FitToHeight;

		protected void Awake()
		{
			gameObject.SetActive(false);
		}

		public void UpdateSize(int width, int height)
		{
			SpriteRenderer ren = gameObject.GetComponent<SpriteRenderer>();
			if (ren != null) transform.localScale = ply2D.SpriteScale(ren, Camera.main, scaleType, width, height);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
