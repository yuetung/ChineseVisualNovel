﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("Vinoma/Clickable Object")]
	public class VinomaClickObj : MonoBehaviour
	{
		public VinomaActionOptDef[] actions;

		// ------------------------------------------------------------------------------------------------------------

		protected void OnMouseUpAsButton()
		{
			if (actions.Length > 0 && VinomaInputManager.MouseHandled == false && UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject() == false)
			{
				VinomaSceneController.Instance.PerformActions(actions);
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
