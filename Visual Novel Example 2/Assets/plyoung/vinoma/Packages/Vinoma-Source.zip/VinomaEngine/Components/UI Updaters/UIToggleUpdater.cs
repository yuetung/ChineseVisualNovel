﻿
using UnityEngine;
using UnityEngine.UI;


namespace VinomaEngine
{
	[RequireComponent(typeof(Toggle)), AddComponentMenu("Vinoma/GUI/Toggle Updater"), HelpURL("https://plyoung.github.io/vinoma-ui-updaters.html")]
	public class UIToggleUpdater : MonoBehaviour
	{
		[SerializeField] private Toggle target=null;
		[SerializeField] private string switchName=null;
		[SerializeField] private bool twoWayLink=false;
		private bool _lock = false;

		private void Reset()
		{
			target = GetComponent<Toggle>();
		}

		private void Awake()
		{
			if (target == null)
			{
				target = GetComponent<Toggle>();
				if (target == null) Debug.Log("[UIToggleUpdater] Could not find any Toggle component on the GameObject.", gameObject);
			}
		}

		private void Start()
		{
			if (VinomaSceneController.Instance == null)
			{
				Debug.LogError("The Vinoma Scene Controller is not active. You should not use this component outside of a Vinoma main scene.");
				return;
			}

			VinomaSceneController.Instance.LinkToSwitch(switchName, OnValueChanged);

			if (twoWayLink)
			{
				target.onValueChanged.AddListener(OnToggleValueChanged);
			}
		}

		private void OnDestroy()
		{
			if (VinomaSceneController.Instance != null)
			{
				VinomaSceneController.Instance.UnlinkFromSwitch(switchName, OnValueChanged);
			}
		}

		private void OnEnable()
		{
			if (VinomaSceneController.Instance != null)
			{
				bool v = false;
				if (VinomaSceneController.Instance.TryGetSwitchState(switchName, out v))
				{
					OnValueChanged(v);
				}
			}
		}

		private void OnValueChanged(bool value)
		{
			if (_lock) return;
			_lock = true;
			target.isOn = value;
			_lock = false;
		}

		private void OnToggleValueChanged(bool v)
		{
			if (_lock || VinomaSceneController.Instance == null) return;
			_lock = true;
			VinomaSceneController.Instance.PerformOperationOnSwitch(switchName, (v ? VinomaSwitchOperation.On : VinomaSwitchOperation.Off));
			_lock = false;
		}

		// ------------------------------------------------------------------------------------------------------------
	}

}
