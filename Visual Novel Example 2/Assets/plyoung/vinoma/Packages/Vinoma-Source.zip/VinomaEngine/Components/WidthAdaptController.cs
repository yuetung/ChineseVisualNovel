﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("Vinoma/Width Adapt Controller")]
	public class WidthAdaptController : MonoBehaviour
	{
		public VinomaWidthAdapt widthAdap = VinomaWidthAdapt.Design;
		private RectTransform tr;

		public void UpdateWidth(float imgOffs, float designOffs)
		{
			if (tr == null)
			{
				tr = GetComponent<RectTransform>();
			}

			if (tr != null)
			{
				if (widthAdap == VinomaWidthAdapt.Background)
				{
					tr.offsetMin = new Vector2(imgOffs, tr.offsetMin.y);
					tr.offsetMax = new Vector2(-imgOffs, tr.offsetMax.y);
				}
				else if (widthAdap == VinomaWidthAdapt.Design)
				{
					tr.offsetMin = new Vector2(designOffs, tr.offsetMin.y);
					tr.offsetMax = new Vector2(-designOffs, tr.offsetMax.y);
				}
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
