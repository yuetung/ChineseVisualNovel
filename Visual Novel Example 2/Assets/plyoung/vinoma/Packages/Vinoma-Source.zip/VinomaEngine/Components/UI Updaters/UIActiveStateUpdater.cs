﻿
using UnityEngine;
using UnityEngine.UI;


namespace VinomaEngine
{
	[RequireComponent(typeof(Toggle)), AddComponentMenu("Vinoma/GUI/State Updater"), HelpURL("https://plyoung.github.io/vinoma-ui-updaters.html")]
	public class UIActiveStateUpdater : MonoBehaviour
	{
		[SerializeField] private GameObject target=null;
		[SerializeField] private string switchName=null;

		private void Reset()
		{
			target = gameObject;
		}

		private void Awake()
		{
			if (target == null) target = gameObject;
		}

		private void Start()
		{
			if (VinomaSceneController.Instance == null)
			{
				Debug.LogError("The Vinoma Scene Controller is not active. You should not use this component outside of a Vinoma main scene.");
				return;
			}

			VinomaSceneController.Instance.LinkToSwitch(switchName, OnValueChanged);
		}

		private void OnDestroy()
		{
			if (VinomaSceneController.Instance != null)
			{
				VinomaSceneController.Instance.UnlinkFromSwitch(switchName, OnValueChanged);
			}
		}

		private void OnEnable()
		{
			if (VinomaSceneController.Instance != null)
			{
				bool v = false;
				if (VinomaSceneController.Instance.TryGetSwitchState(switchName, out v))
				{
					OnValueChanged(v);
				}
			}
		}

		private void OnValueChanged(bool value)
		{
			target.SetActive(value);
		}

		// ------------------------------------------------------------------------------------------------------------
	}

}
