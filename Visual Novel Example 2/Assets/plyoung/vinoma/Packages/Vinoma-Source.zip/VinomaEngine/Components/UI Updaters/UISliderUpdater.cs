﻿
using UnityEngine;
using UnityEngine.UI;


namespace VinomaEngine
{
	[RequireComponent(typeof(Slider)), AddComponentMenu("Vinoma/GUI/Slider Updater"), HelpURL("https://plyoung.github.io/vinoma-ui-updaters.html")]
	public class UISliderUpdater : MonoBehaviour
	{
		[SerializeField] private Slider target=null;
		[SerializeField] private string variableName=null;
		[SerializeField] private bool twoWayLink=false;
		private bool _lock = false;

		private void Reset()
		{
			target = GetComponent<Slider>();
		}

		private void Awake()
		{
			if (target == null)
			{
				target = GetComponent<Slider>();
				if (target == null) Debug.Log("[UISliderUpdater] Could not find any Slider component on the GameObject.", gameObject);
			}
		}

		private void Start()
		{
			if (VinomaSceneController.Instance == null)
			{
				Debug.LogError("The Vinoma Scene Controller is not active. You should not use this component outside of a Vinoma main scene.");
				return;
			}

			VinomaSceneController.Instance.LinkToVariable(variableName, OnValueChanged);

			if (twoWayLink)
			{
				target.onValueChanged.AddListener(OnSliderValueChanged);
			}
		}

		private void OnDestroy()
		{
			if (VinomaSceneController.Instance != null)
			{
				VinomaSceneController.Instance.UnlinkFromVariable(variableName, OnValueChanged);
			}
		}

		private void OnEnable()
		{
			if (VinomaSceneController.Instance != null)
			{
				string v = null;
				if (VinomaSceneController.Instance.TryGetVariableValue(variableName, out v))
				{
					OnValueChanged(v);
				}
			}
		}

		private void OnValueChanged(string value)
		{
			if (_lock) return;
			_lock = true;
			if (target.wholeNumbers)
			{
				int i = 0;
				if (int.TryParse(value, out i))
				{
					target.value = i;
				}
				else
				{
					Debug.LogFormat("Could not convert the variable [{0}] value [{1}] to a number.", variableName, value);
				}
			}
			else
			{
				float f = 0;
				if (float.TryParse(value, out f))
				{
					target.value = f;
				}
				else
				{
					Debug.LogFormat("Could not convert the variable [{0}] value [{1}] to a number.", variableName, value);
				}				
			}
			_lock = false;
		}

		private void OnSliderValueChanged(float v)
		{
			if (_lock || VinomaSceneController.Instance == null) return;
			_lock = true;
			string value = v.ToString();
			VinomaSceneController.Instance.PerformOperationOnVariable(variableName, value, null, VinomaVarOperation.Set);
			_lock = false;
		}

		// ------------------------------------------------------------------------------------------------------------
	}

}
