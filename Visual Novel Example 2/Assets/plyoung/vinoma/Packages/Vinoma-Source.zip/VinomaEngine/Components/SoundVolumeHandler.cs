﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class SoundVolumeHandler : MonoBehaviour
	{
		// ------------------------------------------------------------------------------------------------------------
		#region properties

		public enum SoundType { Effects, Music }
		public SoundType soundType = SoundType.Effects;
		public AudioSource[] targetAudioSources;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region runtime

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void Reset()
		{
			targetAudioSources = gameObject.GetComponents<AudioSource>();
		}

		protected void Awake()
		{
		}

		protected void Start()
		{
			UpdateVolume();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public void UpdateVolume()
		{
			if (targetAudioSources != null)
			{
				for (int i = 0; i < targetAudioSources.Length; i++)
				{
					targetAudioSources[i].volume = (soundType == SoundType.Effects ? VinomaGameGlobal.setting_sfxVolume : VinomaGameGlobal.setting_musicVolume);
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
