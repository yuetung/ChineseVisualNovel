﻿using UnityEngine;
using UnityEngine.EventSystems;


namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class MouseOverDetect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
	{
		public bool PointerOver { get; set; }
		public VinomaDialogueController controller;

		private void Start()
		{
			PointerOver = false;

		}

		public void OnPointerEnter(PointerEventData eventData)
		{
			PointerOver = true;
		}

		public void OnPointerExit(PointerEventData eventData)
		{
			PointerOver = false;
		}

		public void OnPointerClick(PointerEventData eventData)
		{
			controller.TriggerClick();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
