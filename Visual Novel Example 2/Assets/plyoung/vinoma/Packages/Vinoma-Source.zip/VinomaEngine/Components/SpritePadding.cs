﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[RequireComponent(typeof(SpriteRenderer))]
	[AddComponentMenu("Vinoma/Sprite Padding")]
	[DisallowMultipleComponent]
	public class SpritePadding : MonoBehaviour
	{
		public FloatRectOffset padding;

		// ------------------------------------------------------------------------------------------------------------
	}
}
