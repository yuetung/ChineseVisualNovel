﻿
using UnityEngine;
using UnityEngine.UI;


namespace VinomaEngine
{
	[RequireComponent(typeof(Text)), AddComponentMenu("Vinoma/GUI/Text Updater"), HelpURL("https://plyoung.github.io/vinoma-ui-updaters.html")]
	public class UITextUpdater : MonoBehaviour
	{
		[SerializeField] private Text target=null;
		[SerializeField] private string variableName=null;

		private void Reset()
		{
			target = GetComponent<Text>();
		}

		private void Awake()
		{
			if (target == null)
			{
				target = GetComponent<Text>();
				if (target == null) Debug.Log("[UITextUpdater] Could not find any Text component on the GameObject.", gameObject);
			}
		}

		private void Start()
		{
			if (VinomaSceneController.Instance == null)
			{
				Debug.LogError("The Vinoma Scene Controller is not active. You should not use this component outside of a Vinoma main scene.");
				return;
			}

			VinomaSceneController.Instance.LinkToVariable(variableName, OnValueChanged);
		}

		private void OnDestroy()
		{
			if (VinomaSceneController.Instance != null)
			{
				VinomaSceneController.Instance.UnlinkFromVariable(variableName, OnValueChanged);
			}
		}

		private void OnEnable()
		{
			if (VinomaSceneController.Instance != null)
			{
				string v = null;
				if (VinomaSceneController.Instance.TryGetVariableValue(variableName, out v))
				{
					OnValueChanged(v);
				}
			}
		}

		private void OnValueChanged(string value)
		{
			target.text = value;
		}

		// ------------------------------------------------------------------------------------------------------------
	}

}
