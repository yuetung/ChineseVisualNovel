﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon2;

namespace VinomaEngine
{
	[AddComponentMenu("")]
	public class VinomaHotspotObj : MonoBehaviour
	{

		public int overlayIdent;
		public VinomaHotspot hs;
		public System.Action<int, VinomaHotspot> onClick;
		private SpriteRenderer sr;

		// ------------------------------------------------------------------------------------------------------------

		protected void Start()
		{
			sr = GetComponent<SpriteRenderer>();
		}

		protected void OnMouseEnter()
		{
			if (sr != null)
			{
				sr.enabled = true;
			}
		}

		protected void OnMouseExit()
		{
			if (sr != null)
			{
				sr.enabled = false;
			}
		}

		protected void OnMouseUpAsButton()
		{
			if (onClick != null && VinomaInputManager.MouseHandled == false && UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject() == false)
			{
				onClick(overlayIdent, hs);
			}
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
